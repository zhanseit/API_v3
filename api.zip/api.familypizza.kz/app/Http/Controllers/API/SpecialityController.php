<?php

namespace App\Http\Controllers\API;
use App\Http\Helpers;
use App\Models\Push;
use App\Models\Speciality;
use Illuminate\Support\Facades\Input;
use Illuminate\Http\Request;
use App\Models\Users;
use App\Http\Controllers\Controller;
use Mockery\CountValidator\Exception;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use App;

class SpecialityController extends Controller
{
    public $lang = 'ru';

    public function __construct()
    {
        $this->lang = App::getLocale();
        if($this->lang == '') $this->lang = 'ru';
    }
    
    public function getSpecialityList(Request $request){
        $speciality = Speciality::orderBy('sort_num', 'asc')
                                ->orderBy('speciality_name_'.$this->lang,'asc')
                                ->where('is_show',1)
                                ->where('speciality_name_'.$this->lang,'like','%'.$request->search.'%')
                                ->paginate($request->per_page);

        $row = array();
        foreach ($speciality as $key => $val)
        {
            $row[$key]['speciality_id'] = $val['speciality_id'];
            $row[$key]['speciality_name'] = $val['speciality_name_'.$this->lang];
        }

        $result['data'] = $row;
        $result['total_item'] = $speciality->total();
        $result['total_page'] = $speciality->lastPage();
        $result['status'] = true;
        return response()->json($result);
    }
}
