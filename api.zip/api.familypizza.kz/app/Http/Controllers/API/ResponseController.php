<?php

namespace App\Http\Controllers\API;

use App\Models\Push;
use App\Models\Response;
use App\Models\Users;
use App\Models\Vacancy;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Mockery\CountValidator\Exception;
use Illuminate\Support\Facades\Validator;
use DB;
use App;

class ResponseController extends Controller
{
    public $lang = 'ru';

    public function __construct()
    {
        $this->lang = App::getLocale();
        if($this->lang == '') $this->lang = 'ru';
    }

    public function addResponse(Request $request){
        $user = Users::where('mobile_token','=',$request->token)->first();
        if($user == null){
            $result['error'] = 'Пользователь с указанным token не существует';
            $result['error_code'] = 401;
            $result['status'] = false;
            return response()->json($result);
        }

        $validator = Validator::make($request->all(), [
            'vacancy_id' => 'required',
        ]);

        if ($validator->fails()) {
            $messages = $validator->errors();
            $error = $messages->all();
            $result['error'] = $error[0];
            $result['error_code'] = 500;
            $result['status'] = false;
            return response()->json($result);
        }

        $vacancy = Vacancy::where('vacancy_id',$request->vacancy_id)->first();

        if($vacancy == null){
            $result['error'] = 'Не существует такой вакансии';
            $result['error_code'] = 500;
            $result['status'] = false;
            return response()->json($result);
        }

        if($vacancy->user_id == $user->user_id){
            $result['error'] = 'Вы не можете отправить отклик на свою вакансию';
            $result['error_code'] = 500;
            $result['status'] = false;
            return response()->json($result);
        }

        $response = Response::where('user_id',$user->user_id)->where('vacancy_id',$request->vacancy_id)->first();

        if($response != null){
            $result['error'] = 'Вы уже отравили отклик';
            $result['error_code'] = 500;
            $result['status'] = false;
            return response()->json($result);
        }

        $response = new Response();
        $response->user_id = $user->user_id;
        $response->vacancy_id = $request->vacancy_id;
        $response->status_id = 1;
        $response->save();

        $device = Push::where('user_id','=',$response->user_id)->get();

        $push = new Push();

        foreach($device as $val){
            $param['message'] = $user->user_name ." отправил отклик на вакансию";
            $param['id'] = $request->vacancy_id;
            $param['type'] = 'response';

            if($val->os == 'Android'){
                $registration_id = array($val->registration_id);
                $message = array("m" => json_encode($param));
                $result1 = $push->sendMessageToAndroid($registration_id,$message);
            }
            else if($val->os == 'iOS'){
                $registration_id = $val->registration_id;
                $message = $param;
                $result1 = $push->sendMessageToIOS($registration_id,$message);
            }
        }

        $result['message'] = 'Успешно отправлен';
        $result['response_id'] = $response->response_id;
        $result['status'] = true;
        return response()->json($result);
    }

    public function cancelResponse(Request $request,$response_id){
        $user = Users::where('mobile_token','=',$request->token)->first();
        if($user == null){
            $result['error'] = 'Пользователь с указанным token не существует';
            $result['error_code'] = 401;
            $result['status'] = false;
            return response()->json($result);
        }

        $response = Response::where('user_id',$user->user_id)->where('response_id',$response_id)->first();

        if($response == null){
            $result['error'] = 'У вас нету такого отклика';
            $result['error_code'] = 500;
            $result['status'] = false;
            return response()->json($result);
        }

        $response->status_id = 5;
        $response->save();

        $vacancy = Vacancy::where('vacancy_id',$response->vacancy_id)->first();

        $device = Push::where('user_id','=',$vacancy->user_id)->get();
        $push = new Push();

        foreach($device as $val){
            $param['message'] = $user->user_name ." отменил свой отклик на вакансию";
            $param['id'] = $request->vacancy_id;
            $param['type'] = 'response';

            if($val->os == 'Android'){
                $registration_id = array($val->registration_id);
                $message = array("m" => json_encode($param));
                $result1 = $push->sendMessageToAndroid($registration_id,$message);
            }
            else if($val->os == 'iOS'){
                $registration_id = $val->registration_id;
                $message = $param;
                $result1 = $push->sendMessageToIOS($registration_id,$message);
            }
        }

        $result['message'] = 'Успешно отменен';
        $result['status'] = true;
        return response()->json($result);
    }

    public function acceptResponse(Request $request,$response_id){
        $user = Users::where('mobile_token','=',$request->token)->first();
        if($user == null){
            $result['error'] = 'Пользователь с указанным token не существует';
            $result['error_code'] = 401;
            $result['status'] = false;
            return response()->json($result);
        }

        $user_id = $user->user_id;

        $response = Response::where('response_id',$response_id)->first();

        if($response == null){
            $result['error'] = 'Не существует такого отлика';
            $result['error_code'] = 500;
            $result['status'] = false;
            return response()->json($result);
        }

        $vacancy = Vacancy::where('vacancy_id',$response->vacancy_id)->first();

        if($vacancy->user_id != $user_id){
            $result['error'] = 'Вы не автор вакансии';
            $result['error_code'] = 500;
            $result['status'] = false;
            return response()->json($result);
        }

        $response->status_id = 2;
        $response->save();
        
        $device = Push::where('user_id','=',$response->user_id)->get();

        $push = new Push();

        foreach($device as $val){
            $param['message'] = $user->user_name ." принял отклик";
            $param['id'] = $vacancy->vacancy_id;
            $param['type'] = 'response';
            
            if($val->os == 'Android'){
                $registration_id = array($val->registration_id);
                $message = array("m" => json_encode($param));
                $result1 = $push->sendMessageToAndroid($registration_id,$message);
            }
            else if($val->os == 'iOS'){
                $registration_id = $val->registration_id;
                $message = $param;
                $result1 = $push->sendMessageToIOS($registration_id,$message);
            }
        }

        $result['message'] = 'Успешно принят';
        $result['status'] = true;
        return response()->json($result);
    }

    public function rejectResponse(Request $request,$response_id){
        $user = Users::where('mobile_token','=',$request->token)->first();
        if($user == null){
            $result['error'] = 'Пользователь с указанным token не существует';
            $result['error_code'] = 401;
            $result['status'] = false;
            return response()->json($result);
        }

        $user_id = $user->user_id;

        $response = Response::where('response_id',$response_id)->first();

        if($response == null){
            $result['error'] = 'Не существует такого отлика';
            $result['error_code'] = 500;
            $result['status'] = false;
            return response()->json($result);
        }

        $vacancy = Vacancy::where('vacancy_id',$response->vacancy_id)->first();

        if($vacancy->user_id != $user_id){
            $result['error'] = 'Вы не автор вакансии';
            $result['error_code'] = 500;
            $result['status'] = false;
            return response()->json($result);
        }

        $response->status_id = 3;
        $response->save();

        $device = Push::where('user_id','=',$response->user_id)->get();

        $push = new Push();

        foreach($device as $val){
            $param['message'] = $user->user_name ." отклонил отклик";
            $param['id'] = $vacancy->vacancy_id;
            $param['type'] = 'response';

            if($val->os == 'Android'){
                $registration_id = array($val->registration_id);
                $message = array("m" => json_encode($param));
                $result1 = $push->sendMessageToAndroid($registration_id,$message);
            }
            else if($val->os == 'iOS'){
                $registration_id = $val->registration_id;
                $message = $param;
                $result1 = $push->sendMessageToIOS($registration_id,$message);
            }
        }

        $result['message'] = 'Успешно отказан';
        $result['status'] = true;
        return response()->json($result);
    }

    public function successResponse(Request $request,$response_id){
        $user = Users::where('mobile_token','=',$request->token)->first();
        if($user == null){
            $result['error'] = 'Пользователь с указанным token не существует';
            $result['error_code'] = 401;
            $result['status'] = false;
            return response()->json($result);
        }

        $user_id = $user->user_id;

        $response = Response::where('response_id',$response_id)->first();

        if($response == null){
            $result['error'] = 'Не существует такого отлика';
            $result['error_code'] = 500;
            $result['status'] = false;
            return response()->json($result);
        }

        $vacancy = Vacancy::where('vacancy_id',$response->vacancy_id)->first();

        if($vacancy->user_id != $user_id){
            $result['error'] = 'Вы не автор вакансии';
            $result['error_code'] = 500;
            $result['status'] = false;
            return response()->json($result);
        }

        $response->status_id = 4;
        $response->save();

        $device = Push::where('user_id','=',$response->user_id)->get();

        $push = new Push();

        foreach($device as $val){
            $param['message'] = $user->user_name ." успешно завершил заявку";
            $param['id'] = $vacancy->vacancy_id;
            $param['type'] = 'response';

            if($val->os == 'Android'){
                $registration_id = array($val->registration_id);
                $message = array("m" => json_encode($param));
                $result1 = $push->sendMessageToAndroid($registration_id,$message);
            }
            else if($val->os == 'iOS'){
                $registration_id = $val->registration_id;
                $message = $param;
                $result1 = $push->sendMessageToIOS($registration_id,$message);
            }
        }

        $result['message'] = 'Успешно изменен';
        $result['status'] = true;
        return response()->json($result);
    }
    
    public function getIncomingResponseList(Request $request){
        $user = Users::where('mobile_token','=',$request->token)->first();
        if($user == null){
            $result['error'] = 'Пользователь с указанным token не существует';
            $result['error_code'] = 401;
            $result['status'] = false;
            return response()->json($result);
        }

        $response = Response::leftJoin('vacancy','vacancy.vacancy_id','=','response.vacancy_id')
                            ->leftJoin('speciality','speciality.speciality_id','=','vacancy.speciality_id')
                            ->leftJoin('users','users.user_id','=','response.user_id')
                            ->leftJoin('status','response.status_id','=','status.status_id')
                            ->orderBy('response.created_at', 'desc')
                            ->where('vacancy.user_id',$user->user_id)
                            ->select('*',
                                DB::raw('DATE_FORMAT(response.created_at,"%d.%m.%Y") as datetime'),
                                DB::raw('DATE_FORMAT(vacancy.deadline,"%d.%m.%Y") as deadline')
                            );

        if(isset($request->vacancy_id)) $response->where('response.vacancy_id',$request->vacancy_id);
        
        $response = $response->paginate($request->per_page);

        $row = array();
        foreach ($response as $key => $val)
        {
            $row[$key]['response_id'] = $val['response_id'];
            $row[$key]['response_datetime'] = $val['datetime'];
            $row[$key]['status_id'] = $val['status_id'];
            $row[$key]['status_name'] = $val['status_name_'.$this->lang];
            
            $row[$key]['author_response']['user_id'] = $val->user_id;
            $row[$key]['author_response']['user_name'] = $val->user_name;

            $row[$key]['vacancy']['vacancy_id'] = $val['vacancy_id'];
            $row[$key]['vacancy']['vacancy_desc'] = $val['vacancy_desc'];
            $row[$key]['vacancy']['salary'] = $val['salary'];
            $row[$key]['vacancy']['salary'] = $val['salary'];
            $row[$key]['vacancy']['speciality_id'] = $val['speciality_id'];
            $row[$key]['vacancy']['speciality_name'] = $val['speciality_name_'.$this->lang];
            

        }

        $result['data'] = $row;
        $result['total_item'] = $response->total();
        $result['total_page'] = $response->lastPage();
        $result['status'] = true;
        return response()->json($result);
    }

    public function getOutcomingResponseList(Request $request){
        $user = Users::where('mobile_token','=',$request->token)->first();
        if($user == null){
            $result['error'] = 'Пользователь с указанным token не существует';
            $result['error_code'] = 401;
            $result['status'] = false;
            return response()->json($result);
        }

        $response = Response::leftJoin('vacancy','vacancy.vacancy_id','=','response.vacancy_id')
            ->leftJoin('speciality','speciality.speciality_id','=','vacancy.speciality_id')
            ->leftJoin('users','users.user_id','=','vacancy.user_id')
            ->leftJoin('status','response.status_id','=','status.status_id')
            ->orderBy('response.created_at', 'desc')
            ->where('response.user_id',$user->user_id)
            ->select('*',
                DB::raw('DATE_FORMAT(response.created_at,"%d.%m.%Y") as datetime')
            );
        
        $response = $response->paginate($request->per_page);

        $row = array();
        foreach ($response as $key => $val)
        {
            $row[$key]['response_id'] = $val['response_id'];
            $row[$key]['response_datetime'] = $val['datetime'];
            $row[$key]['status_id'] = $val['status_id'];
            $row[$key]['status_name'] = $val['status_name_'.$this->lang];

            $row[$key]['author_request']['user_id'] = $val->user_id;
            $row[$key]['author_request']['user_name'] = $val->user_name;

            $row[$key]['vacancy']['vacancy_id'] = $val['vacancy_id'];
            $row[$key]['vacancy']['vacancy_desc'] = $val['vacancy_desc'];
            $row[$key]['vacancy']['salary'] = $val['salary'];
            $row[$key]['vacancy']['salary'] = $val['salary'];
            $row[$key]['vacancy']['speciality_id'] = $val['speciality_id'];
            $row[$key]['vacancy']['speciality_name'] = $val['speciality_name_'.$this->lang];


        }

        $result['data'] = $row;
        $result['total_item'] = $response->total();
        $result['total_page'] = $response->lastPage();
        $result['status'] = true;
        return response()->json($result);
    }
   
}
