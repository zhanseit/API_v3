<?php

namespace App\Http\Controllers\API;
use App\Http\Helpers;
use App\Models\Push;
use App;
use Illuminate\Support\Facades\Input;
use Illuminate\Http\Request;
use App\Models\Users;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Mail;
use Mockery\CountValidator\Exception;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{
    public $lang = 'ru';

    public function __construct()
    {
        $this->lang = App::getLocale();
    }

    public function register(Request $request){
        $data = $request->all();
        $data['phone'] = Helpers::changePhoneFormat($request->phone);
        
        $validator = Validator::make($data, [
            'phone' => 'required|unique:users,phone,NULL,user_id,deleted_at,NULL',
            'role_id' => 'required',
            'password' => 'required|min:6',
            'confirm_password' => 'required|same:password',
        ]);

        if ($validator->fails()) {
            $messages = $validator->errors();
            $error = $messages->all();
            $result['error'] = $error[0];
            $result['error_code'] = 500;
            $result['status'] = false;
            return response()->json($result);
        }

        $user = new Users();
        $user->user_name = ' ';
        $user->phone = Helpers::changePhoneFormat($request->phone);
        $user->password = Hash::make($request->password);
        $token = md5(uniqid(time(), true));
        $user->mobile_token = $token;
        $user->role_id = $request->role_id;
        $sms_code = rand(100000,999999);
        $user->sms_code = $sms_code;
        $user->save();

        $phone = '7'.Helpers::changePhoneFormat($request->phone);
        $message = "Ваш код подтверждения: ".$sms_code;
        //Helpers::sendSMS($phone,$message);

        $result['token'] = $token;
        $result['message'] = "Смс с кодом авторизации было отправлено на Ваш номер";
        $result['status'] = true;
        return response()->json($result);
    }

    public function login(Request $request){
        $data = $request->all();
        $data['phone'] = Helpers::changePhoneFormat($request->phone);

        $validator = Validator::make($data, [
            'phone' => 'required',
            'password' => 'required|min:6',
        ]);

        if ($validator->fails()) {
            $messages = $validator->errors();
            $error = $messages->all();
            $result['error'] = $error[0];
            $result['error_code'] = 500;
            $result['status'] = false;
            return response()->json($result);
        }

        $login = Helpers::changePhoneFormat($request->phone);
        $user = Users::where('phone','=',$login)->first();

        if(isset($user->password)){
            $count = Hash::check($request->password, $user->password);
            if($count == true){
                $token = md5(uniqid(time(), true));
                $user->mobile_token = $token;
                $user->save();

                $result['token'] = $user->mobile_token;
                $result['sms_activate'] = $user->sms_activate;
                $result['user_id'] = $user->user_id;
                $result['role_id'] = $user->role_id;
                $result['user_name'] = $user->user_name;
                $result['phone'] = $user->phone;
                $result['status'] = true;
                return response()->json($result);
            }
        }

        $result['error'] = "Неправильный логин или пароль!";
        $result['error_code'] = 500;
        $result['status'] = false;
        return response()->json($result);
    }

    public function logout(Request $request){
        $user = Users::where('mobile_token','=',$request->token)->first();
        if($user == null){
            $result['error'] = 'Пользователь с указанным token не существует';
            $result['error_code'] = 401;
            $result['status'] = false;
            return response()->json($result);
        }

        $token = md5(uniqid(time(), true));
        $user->mobile_token = $token;
        $user->save();

        $push = Push::where('user_id','=',$user->user_id)->delete();

        $result['message'] = "Успешно вышел";
        $result['status'] = true;
        return response()->json($result);
    }

    public function confirmPhone(Request $request){
        $user = Users::where('mobile_token','=',$request->token)->first();
        if($user == null){
            $result['error'] = 'Пользователь с указанным token не существует';
            $result['error_code'] = 401;
            $result['status'] = false;
            return response()->json($result);
        }

        $validator = Validator::make($request->all(), [
            'sms_code' => 'required|min:6',
        ]);

        if ($validator->fails()) {
            $messages = $validator->errors();
            $error = $messages->all();
            $result['error'] = $error[0];
            $result['error_code'] = 500;
            $result['status'] = false;
            return response()->json($result);
        }

        if($user->sms_activate == 1){
            $result['message'] = "Вы уже подтвердили номер телефона!";
            $result['status'] = true;
            return response()->json($result);
        }

        if($user->sms_code != $request->sms_code){
            $result['error'] = "Вы ввели неправильный код подтверждения!";
            $result['error_code'] = 500;
            $result['status'] = false;
            return response()->json($result);
        }

        $user->sms_activate = 1;
        $user->save();

        $result['message'] = "Ваш номер телефона успешно подтвержден.";
        $result['status'] = true;
        return response()->json($result);
    }

    public function sendSmsActivate(Request $request){
        $user = Users::where('mobile_token','=',$request->token)->first();
        if($user == null){
            $result['error'] = 'Пользователь с указанным token не существует';
            $result['error_code'] = 401;
            $result['status'] = false;
            return response()->json($result);
        }

        if(isset($request->phone)){
            $user->phone = Helpers::changePhoneFormat($request->phone);
            $user->sms_activate = 0;
            $phone = '7'.Helpers::changePhoneFormat($request->phone);
        }
        else {
            $phone = '7' .$user->phone;
        }

        $sms_code = rand(100000,999999);
        $user->sms_code = $sms_code;

        $user->save();


        $message = "Ваш код подтверждения: ".$sms_code;
        Helpers::sendSMS($phone,$message);

        $result['message'] = "Успешно отправлен";
        $result['status'] = true;
        return response()->json($result);
    }

    public function forgetPassword(Request $request){
        $validator = Validator::make(['phone' => Helpers::changePhoneFormat($request->phone)], [
            'phone' => 'required|exists:users,phone',
        ]);

        if($validator->fails()) {
            $messages = $validator->errors();
            $error = $messages->all();
            $result['error'] = "Пользователь с таким номером не найден";
            $result['status_code'] = 500;
            $result['status'] = false;
            return response()->json($result);
        }

        $sms_code = rand(100000,999999);
        $user = Users::where('phone',Helpers::changePhoneFormat($request->phone))->update([
            'sms_code' => $sms_code,
        ]);

        try {
            $phone = '7'.Helpers::changePhoneFormat($request->phone);
            $message = "Ваш код подтверждения: ".$sms_code;
            Helpers::sendSMS($phone,$message);
        }
        catch (Exception $ex){
            $result['error'] = "Ошибка";
            $result['status_code'] = 500;
            $result['status'] = false;
            return response()->json($result);
        }

        $result['message'] = "На ваш номер отправлен смс";
        $result['phone'] = $request->phone;
        $result['status'] = true;
        return response()->json($result);
    }

    public function confirmForgetPassword(Request $request){
        $user = Users::where('phone','=',Helpers::changePhoneFormat($request->phone))->first();
        if($user == null){
            $result['error'] = "Пользователь с таким номером не найден";
            $result['error_code'] = 500;
            $result['status'] = false;
            return response()->json($result);
        }

        $validator = Validator::make($request->all(), [
            'sms_code' => 'required|min:6',
        ]);

        if ($validator->fails()) {
            $messages = $validator->errors();
            $error = $messages->all();
            $result['error'] = $error[0];
            $result['error_code'] = 500;
            $result['status'] = false;
            return response()->json($result);
        }

        if($user->sms_code != $request->sms_code){
            $result['error'] = "Вы ввели неправильный код подтверждения!";
            $result['error_code'] = 500;
            $result['status'] = false;
            return response()->json($result);
        }

        $token = md5(uniqid(time(), true));
        $user->mobile_token = $token;
        $user->save();

        $result['message'] = "Код успешно подтвержден.";
        $result['token'] = $user->mobile_token;
        $result['status'] = true;
        return response()->json($result);
    }

    public function test(Request $request){
        $email = 'arman.abdiyev@gmail.com';
        $hash = 'dasdasdasdfd';

        $mail = Helpers::send_mime_mail('info@bfc.kz',
            'info@bfc.kz',
            $email,
            $email,
            'windows-1251',
            'UTF-8',
            'Новая заявка',
            view('welcome',['hash' => $hash,'email' => $email]),
            true);
        echo var_dump($mail);
    }
}
