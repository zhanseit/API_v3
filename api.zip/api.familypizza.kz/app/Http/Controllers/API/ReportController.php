<?php

namespace App\Http\Controllers\API;


use App\Models\Push;
use App\Models\Report;
use App\Models\Users;
use App\Models\Vacancy;
use Illuminate\Http\Request;

use App\Http\Controllers\Controller;
use Mockery\CountValidator\Exception;
use Illuminate\Support\Facades\Validator;
use DB;
use App;

class ReportController extends Controller
{
    public $lang = 'ru';

    public function __construct()
    {
        $this->lang = App::getLocale();
    }

    public function addReport(Request $request){
        $user = Users::where('mobile_token','=',$request->token)->first();
        if($user == null){
            $result['error'] = 'Пользователь с указанным token не существует';
            $result['error_code'] = 401;
            $result['status'] = false;
            return response()->json($result);
        }

        $validator = Validator::make($request->all(), [
            'report_type_id' => 'required'
        ]);

        if ($validator->fails()) {
            $messages = $validator->errors();
            $error = $messages->all();
            $result['error'] = $error[0];
            $result['error_code'] = 500;
            $result['status'] = false;
            return response()->json($result);
        }

        $report = new Report();
        $report->author_id = $user->user_id;
        $report->report_type_id = $request->report_type_id;

        if(isset($request->user_id)){
            if($user->user_id == $request->user_id){
                $result['error'] = 'Вы не можете оставить себе жалобу';
                $result['error_code'] = 500;
                $result['status'] = false;
                return response()->json($result);
            }
            $report_row = Report::where('author_id',$user->user_id)->where('user_id',$request->user_id)->first();
            if($report_row != null){
                $result['error'] = 'Вы уже оставили жалобу';
                $result['error_code'] = 500;
                $result['status'] = false;
                return response()->json($result);
            }
            $report->user_id = $request->user_id;
        }
        else if(isset($request->vacancy_id)){
            $vacancy = Vacancy::find($request->vacancy_id);
            if($vacancy == null){
                $result['error'] = 'Такой заявки не существует';
                $result['error_code'] = 500;
                $result['status'] = false;
                return response()->json($result);
            }

            if($user->user_id == $vacancy->user_id){
                $result['error'] = 'Вы не можете оставить жалобу на свою вакансию';
                $result['error_code'] = 500;
                $result['status'] = false;
                return response()->json($result);
            }

            $report_row = Report::where('author_id',$user->user_id)->where('vacancy_id',$request->vacancy_id)->first();
            if($report_row != null){
                $result['error'] = 'Вы уже оставили жалобу';
                $result['error_code'] = 500;
                $result['status'] = false;
                return response()->json($result);
            }

            $report->vacancy_id = $request->vacancy_id;
        }
        else {
            $result['error'] = 'Укажите все данные';
            $result['error_code'] = 500;
            $result['status'] = false;
            return response()->json($result);
        }

        try {
            $report->save();
        } catch(\Exception $ex){
            $result['error'] = 'Ошибка базы данных';
            $result['error_code'] = 500;
            $result['status'] = false;
            return response()->json($result);
        }

        $result['message'] = 'Успешно добавлена';
        $result['report_id'] = $report->report_id;
        $result['status'] = true;
        return response()->json($result);
    }
}
