<?php

namespace App\Http\Controllers\API;
use App\Http\Helpers;
use App\Models\News;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Mockery\CountValidator\Exception;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use DB;
use App;

class NewsController extends Controller
{
    public $lang = 'ru';

    public function __construct()
    {
        $this->lang = App::getLocale();
        if($this->lang == '') $this->lang = 'ru';
    }
    
    public function getNewsList(Request $request){
        $news = News::orderBy('news_id', 'desc')
                    ->where('is_show',1)
                    ->where('news_name_'.$this->lang,'like','%'.$request->search.'%')
                    ->select('*',
                        DB::raw('DATE_FORMAT(created_at,"%d.%m.%Y") as news_date')
                    )
                    ->paginate($request->per_page);

        $row = array();
        foreach ($news as $key => $val)
        {
            $row[$key]['news_id'] = $val['news_id'];
            $row[$key]['news_name'] = $val['news_name_'.$this->lang];
            $row[$key]['news_date'] = $val['news_date'];
            $row[$key]['news_text'] = $val['news_text_'.$this->lang];
        }

        $result['data'] = $row;
        $result['total_item'] = $news->total();
        $result['total_page'] = $news->lastPage();
        $result['status'] = true;
        return response()->json($result);
    }

    public function getNewsById($id){
        $news = News::where('news_id',$id)
                    ->select('*',
                        DB::raw('DATE_FORMAT(created_at,"%d.%m.%Y") as news_date')
                    )->first();

        $row['news_id'] = $news['news_id'];
        $row['news_name'] = $news['news_name_'.$this->lang];
        $row['news_text'] = $news['news_text_'.$this->lang];
        $row['news_date'] = $news['news_date'];

        $result['data'] = $row;
        $result['status'] = true;
        return response()->json($result);
    }
}
