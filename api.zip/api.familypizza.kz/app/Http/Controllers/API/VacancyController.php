<?php

namespace App\Http\Controllers\API;
use App\Http\Helpers;
use App\Models\Push;
use App\Models\Response;
use App\Models\Speciality;
use App\Models\Vacancy;
use Illuminate\Support\Facades\Input;
use Illuminate\Http\Request;
use App\Models\Users;
use App\Http\Controllers\Controller;
use Mockery\CountValidator\Exception;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use DB;
use App;

class VacancyController extends Controller
{
    public $lang = 'ru';

    public function __construct()
    {
        $this->lang = App::getLocale();
        if($this->lang == '') $this->lang = 'ru';
    }
    
    public function getVacancyList(Request $request){
        $vacancy = Vacancy::leftJoin('users','vacancy.user_id','=','users.user_id')
                            ->leftJoin('speciality','speciality.speciality_id','=','vacancy.speciality_id')
                            ->orderBy('vacancy_id', 'desc')
                            ->where('vacancy.is_show',1)
                            ->select('*',
                                DB::raw('DATE_FORMAT(vacancy.created_at,"%d.%m.%Y") as date'),
                                DB::raw('DATE_FORMAT(vacancy.deadline,"%d.%m.%Y") as deadline')
                            );

        if(isset($request->speciality_id) && $request->speciality_id > 0)
            $vacancy->where('vacancy.speciality_id',$request->speciality_id);

        if(isset($request->token)){
            $user = Users::where('mobile_token','=',$request->token)->first();

            if($user == null){
                $result['error'] = 'Пользователь с указанным token не существует';
                $result['error_code'] = 401;
                $result['status'] = false;
                return response()->json($result);
            }
            $vacancy->where('vacancy.user_id',$user->user_id);
        }

        $vacancy = $vacancy->paginate($request->per_page);

        $row = array();
        foreach ($vacancy as $key => $val)
        {
            $row[$key]['vacancy_id'] = $val['vacancy_id'];
            $row[$key]['vacancy_desc'] = $val['vacancy_desc'];
            $row[$key]['salary'] = $val['salary'];
            $row[$key]['pay_duration'] = $val['pay_duration'];
            $row[$key]['vacancy_date'] = $val['date'];
            $row[$key]['address'] = $val['address'];
            $row[$key]['work_count'] = $val['work_count'];
            $row[$key]['deadline'] = $val['deadline'];
            $row[$key]['response_count'] = Response::where('vacancy_id',$val->vacancy_id)->count();
            $row[$key]['speciality']['speciality_id'] = $val['speciality_id'];
            $row[$key]['speciality']['speciality_name'] = $val['speciality_name_'.$this->lang];
            $row[$key]['author']['user_id'] = $val['user_id'];
            $row[$key]['author']['user_name'] = $val['user_name'];
        }

        $result['data'] = $row;
        $result['total_item'] = $vacancy->total();
        $result['total_page'] = $vacancy->lastPage();
        $result['status'] = true;
        return response()->json($result);
    }

    public function getVacancyById($id){
        $val = Vacancy::leftJoin('users','vacancy.user_id','=','users.user_id')
            ->leftJoin('speciality','speciality.speciality_id','=','vacancy.speciality_id')
            ->where('vacancy.is_show',1)
            ->where('vacancy.vacancy_id',$id)
            ->select('*',
                DB::raw('DATE_FORMAT(vacancy.created_at,"%d.%m.%Y") as date'),
                DB::raw('DATE_FORMAT(vacancy.deadline,"%d.%m.%Y") as deadline')
            )->first();

        $vacancy['vacancy_id'] = $val['vacancy_id'];
        $vacancy['vacancy_desc'] = $val['vacancy_desc'];
        $vacancy['salary'] = $val['salary'];
        $vacancy['pay_duration'] = $val['pay_duration'];
        $vacancy['vacancy_date'] = $val['date'];
        $vacancy['address'] = $val['address']?:'';
        $vacancy['work_count'] = $val['work_count'];
        $vacancy['deadline'] = $val['deadline'];
        $vacancy['response_count'] = Response::where('vacancy_id',$val->vacancy_id)->count();
        $vacancy['speciality']['speciality_id'] = $val['speciality_id'];
        $vacancy['speciality']['speciality_name'] = $val['speciality_name_'.$this->lang];
        $vacancy['author']['user_id'] = $val['user_id'];
        $vacancy['author']['user_name'] = $val['user_name']?:'';
        $vacancy['author']['phone'] = $val['phone']?:'';

        $result['data'] = $vacancy;
        $result['status'] = true;
        return response()->json($result);
    }

    public function addVacancy(Request $request){
        $user = Users::where('mobile_token','=',$request->token)->first();
        if($user == null){
            $result['error'] = 'Пользователь с указанным token не существует';
            $result['error_code'] = 401;
            $result['status'] = false;
            return response()->json($result);
        }

        $validator = Validator::make($request->all(), [
            'vacancy_desc' => 'required',
            'speciality_id' => 'required',
            'salary' => 'required|integer|min:0|max:1000000',
            'pay_duration' => 'required',
            'work_count' => 'required',
            'deadline' => 'required|date|after:yesterday',
        ]);

        if ($validator->fails()) {
            $messages = $validator->errors();
            $error = $messages->all();
            $result['error'] = $error[0];
            $result['error_code'] = 500;
            $result['status'] = false;
            return response()->json($result);
        }

        $vacancy = new Vacancy();
        
        $timestamp = strtotime($request->deadline);
        $date = date("Y-m-d H:i", $timestamp);
        $vacancy->deadline = $date;

        $vacancy->vacancy_desc = $request->vacancy_desc;
        $vacancy->speciality_id = $request->speciality_id;
        $vacancy->user_id = $user->user_id;
        $vacancy->salary = $request->salary;
        $vacancy->work_count = $request->work_count;
        $vacancy->pay_duration = $request->pay_duration;
        $vacancy->address = $request->address;

        try {
            $vacancy->save();

        } catch(\Exception $ex){
            $result['error'] = 'Ошибка база данных' .$ex;
            $result['error_code'] = 500;
            $result['status'] = false;
            return response()->json($result);
        }

        $result['message'] = 'Успешно добавлена';
        $result['vacancy_id'] = $vacancy->vacancy_id;
        $result['status'] = true;
        return response()->json($result);
    }

    public function editVacancy(Request $request,$id){
        $user = Users::where('mobile_token','=',$request->token)->first();
        if($user == null){
            $result['error'] = 'Пользователь с указанным token не существует';
            $result['error_code'] = 401;
            $result['status'] = false;
            return response()->json($result);
        }

        $vacancy = Vacancy::where('vacancy_id',$id)->where('user_id',$user->user_id)->first();
        if($vacancy == null){
            $result['error'] = 'Такая вакансия не существует';
            $result['error_code'] = 500;
            $result['status'] = false;
            return response()->json($result);
        }

        if(isset($request->deadline)){
            $validator = Validator::make($request->all(), [
                'deadline' => 'required|date|after:yesterday'
            ]);

            if ($validator->fails()) {
                $messages = $validator->errors();
                $error = $messages->all();
                $result['error'] = $error[0];
                $result['error_code'] = 500;
                $result['status'] = false;
                return response()->json($result);
            }
            $timestamp = strtotime($request->deadline);
            $date = date("Y-m-d H:i", $timestamp);
            $vacancy->deadline = $date;
        }

        if(isset($request->salary)){
            $validator = Validator::make($request->all(), [
                'salary' => 'required|integer|min:0|max:1000000',
            ]);

            if ($validator->fails()) {
                $messages = $validator->errors();
                $error = $messages->all();
                $result['error'] = $error[0];
                $result['error_code'] = 500;
                $result['status'] = false;
                return response()->json($result);
            }
            $vacancy->salary = $request->salary;
        }

        if(isset($request->vacancy_desc)) $vacancy->vacancy_desc = $request->vacancy_desc;
        if(isset($request->speciality_id))  $vacancy->speciality_id = $request->speciality_id;
        if(isset($request->work_count)) $vacancy->work_count = $request->work_count;
        if(isset($request->pay_duration)) $vacancy->pay_duration = $request->pay_duration;
        if(isset($request->address))  $vacancy->address = $request->address;

        try {
            $vacancy->save();

        } catch(\Exception $ex){
            $result['error'] = 'Ошибка база данных' .$ex;
            $result['error_code'] = 500;
            $result['status'] = false;
            return response()->json($result);
        }

        $result['message'] = 'Успешно изменена';
        $result['vacancy_id'] = $vacancy->vacancy_id;
        $result['status'] = true;
        return response()->json($result);
    }

    public function deleteVacancy(Request $request, $id){
        $user = Users::where('mobile_token','=',$request->token)->first();
        if($user == null){
            $result['error'] = 'Пользователь с указанным token не существует';
            $result['error_code'] = 401;
            $result['status'] = false;
            return response()->json($result);
        }

        $vacancy = Vacancy::where('vacancy_id',$id)->where('user_id',$user->user_id)->first();
        if($vacancy == null){
            $result['error'] = 'Такая вакансия не существует';
            $result['error_code'] = 500;
            $result['status'] = false;
            return response()->json($result);
        }
        
        $vacancy->delete();

        $result['message'] = 'Успешно удалена';
        $result['status'] = true;
        return response()->json($result);
    }
}
