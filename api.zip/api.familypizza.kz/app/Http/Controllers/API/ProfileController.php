<?php

namespace App\Http\Controllers\API;
use App\Http\Helpers;
use App\Models\Review;
use Illuminate\Support\Facades\Input;
use Illuminate\Http\Request;
use App\Models\Users;
use App\Http\Controllers\Controller;
use Mockery\CountValidator\Exception;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\File;
use App;

class ProfileController extends Controller
{
    public $lang = 'ru';

    public function __construct()
    {
        $this->lang = App::getLocale();
        if($this->lang == '') $this->lang = 'ru';
    }

    public function getUserList(Request $request){
        $user = Users::get();

        $row = array();
        foreach ($user as $key => $val)
        {
            $row[$key]['point'] = $val['user_id'];
            $row[$key]['name'] = $val['user_name'];
        }

        $result['data'] = $row;
        $result['status'] = true;
        return response()->json($result);
    }
	
	public function getUserById(Request $request,$id){
        $user = Users::where('user_id',$id)->first();
		
		if($user == null){
			$result['message'] = "This user doesn't exist";
			$result['status'] = false;
			return response()->json($result);
		}
		
		$row['point'] = $user['user_id'];
		$row['name'] = $user['user_name'];

        $result['data'] = $row;
        $result['status'] = true;
        return response()->json($result);
    }
	
	public function checkUser(Request $request){
		if(!isset($request->point) || !isset($request->name)){
			$result['message'] = "Write 'name' and 'point'";
			$result['status'] = false;
			return response()->json($result);
		}
		
        $user = Users::where('user_id',$request->point)
						->where('user_name',$request->name)
						->first();
		
		if($user == null){
			$result['message'] = "This user doesn't exist";
			$result['status'] = false;
			return response()->json($result);
		}
		
		$row['point'] = $user['user_id'];
		$row['name'] = $user['user_name'];

        $result['message'] = "This user exists";
        $result['status'] = true;
        return response()->json($result);
    }
	
    public function addUser(Request $request){
		if(!isset($request->name) || $request->name == ''){
			$result['message'] = "Write 'name'";
			$result['status'] = false;
			return response()->json($result);
		}
		
        $user = new Users();
		$user->user_name = $request->name;
		$user->password = $request->name;
		$user->role_id = 1;
        $user->save();

        try {
            $user->save();
        } catch(\Exception $ex){
            $result['error'] = 'Error';
            $result['error_code'] = 500;
            $result['status'] = false;
            return response()->json($result);
        }

        $result['message'] = "Successfully added";
        $result['status'] = true;
        return response()->json($result);
    }

   
}
