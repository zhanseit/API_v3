<?php

namespace App\Http\Controllers\API;


use App\Models\Push;
use App\Models\Review;
use App\Models\Users;
use Illuminate\Http\Request;

use App\Http\Controllers\Controller;
use Mockery\CountValidator\Exception;
use Illuminate\Support\Facades\Validator;
use DB;
use App;

class ReviewController extends Controller
{
    public $lang = 'ru';

    public function __construct()
    {
        $this->lang = App::getLocale();
        if($this->lang == '') $this->lang = 'ru';
    }
    
    public function getReviewListByUser(Request $request){
        $user = Users::where('user_id','=',$request->user_id)->first();
        if($user == null){
            $result['error'] = 'Пользователь с указанным id не существует';
            $result['error_code'] = 500;
            $result['status'] = false;
            return response()->json($result);
        }

        $review = Review::leftJoin('users','review.user_id','=','users.user_id')
                        ->where('review.master_id','=',$request->user_id)
                        ->orderBy('review.review_id','asc')
                        ->select('review.*',
                                 'users.*',
                                 DB::raw('DATE_FORMAT(review.created_at,"%d.%m.%Y") as review_date')
                                 )
                        ->paginate($request->per_page);

        $row = array();
        foreach ($review as $key => $val)
        {
            $row[$key]['review_id'] = $val['review_id'];
            $row[$key]['review_text'] = $val['review_text'];
            $row[$key]['review_rating'] = $val['rating'];
            $row[$key]['review_date'] = $val['review_date'];
            $row[$key]['user_id'] = $val->user_id;
            $row[$key]['user_name'] = $val->user_name;
        }

        $result['data'] = $row;
        $result['total_item'] = $review->total();
        $result['total_page'] = $review->lastPage();
        $result['status'] = true;
        return response()->json($result);
    }


    public function addReview(Request $request){
        $user = Users::where('mobile_token','=',$request->token)->first();
        if($user == null){
            $result['error'] = 'Пользователь с указанным token не существует';
            $result['error_code'] = 401;
            $result['status'] = false;
            return response()->json($result);
        }

        $validator = Validator::make($request->all(), [
            'review_text' => 'required',
            'review_rating' => 'required|numeric',
            'user_id' => 'required',
        ]);

        if ($validator->fails()) {
            $messages = $validator->errors();
            $error = $messages->all();
            $result['error'] = $error[0];
            $result['error_code'] = 500;
            $result['status'] = false;
            return response()->json($result);
        }

        if($user->user_id == $request->user_id){
            $result['error'] = 'Вы не можете оставить себе отзыв';
            $result['error_code'] = 500;
            $result['status'] = false;
            return response()->json($result);
        }

        $review = new Review();
        $review->review_text = $request->review_text;
        $review->user_id = $user->user_id;
        $review->master_id = $request->user_id;
        $review->rating = $request->review_rating;

        try {
            $review->save();
        } catch(\Exception $ex){
            $result['error'] = 'Ошибка базы данных';
            $result['error_code'] = 500;
            $result['status'] = false;
            return response()->json($result);
        }

        $device = Push::where('user_id','=',$request->user_id)->get();

        $push = new Push();

        foreach($device as $val){
            $param['message'] = $user->user_name ." оставил отзыв";
            $param['id'] = $user->user_id;
            $param['type'] = 'review';

            if($val->os == 'Android'){
                $registration_id = array($val->registration_id);
                $message = array("m" => json_encode($param));
                $result1 = $push->sendMessageToAndroid($registration_id,$message);
            }
            else if($val->os == 'iOS'){
                $registration_id = $val->registration_id;
                $message = $param;
                $result1 = $push->sendMessageToIOS($registration_id,$message);
            }
        }
        
        $result['message'] = 'Успешно добавлен';
        $result['review_id'] = $review->review_id;
        $result['status'] = true;
        return response()->json($result);
    }
}
