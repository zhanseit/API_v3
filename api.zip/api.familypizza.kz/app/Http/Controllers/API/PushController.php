<?php

namespace App\Http\Controllers\API;


use App\Models\Push;
use App\Models\Users;
use Illuminate\Http\Request;

use App\Http\Controllers\Controller;


class PushController extends Controller
{
    public $lang = 'ru';

    public function __construct()
    {

    }

    public function addDevice(Request $request){
        $user = Users::where('mobile_token','=',$request->token)->first();
        if($user === null){
            $result['error'] = 'Пользователь с указанным token не существует';
            $result['error_code'] = 401;
            $result['status'] = false;
            return response()->json($result);
        }

        $push = Push::where('registration_id','=',$request->registration_id)->delete();

        $push = new Push();
        $push->user_id = $user->user_id;
        $push->registration_id = $request->registration_id;
        $push->os = $request->os;
        $push->save();

        $result['message'] = 'Успешно добавлен';
        $result['status'] = true;
        return response()->json($result);
    }

    public function deleteDevice(Request $request){
        $user = Users::where('mobile_token','=',$request->token)->first();
        if($user === null){
            $result['error'] = 'Пользователь с указанным token не существует';
            $result['error_code'] = 401;
            $result['status'] = false;
            return response()->json($result);
        }

        $push = Push::where('user_id','=',$user->user_id)
            ->where('registration_id','=',$request->registration_id)
            ->count();

        if($push == 0){
            $result['status'] = false;
            return response()->json($result);
        }

        Push::where('user_id','=',$user->user_id)
            ->where('registration_id','=',$request->registration_id)
            ->delete();

        $result['status'] = true;
        return response()->json($result);
    }
}
