<?php

namespace App\Http\Controllers\API;


use App\Models\ReportType;
use Illuminate\Http\Request;

use App\Http\Controllers\Controller;
use App;

class ReportTypeController extends Controller
{
    public $lang = 'ru';

    public function __construct()
    {
        $this->lang = App::getLocale();
        if($this->lang == '') $this->lang = 'ru';
    }
    
    public function getReportTypeList(Request $request){
        $report = ReportType::orderBy('sort_num', 'asc')->paginate($request->per_page);

        $row = array();
        foreach ($report as $key => $val)
        {
            $row[$key]['report_type_id'] = $val['report_type_id'];
            $row[$key]['report_type_name'] = $val['report_type_name_'.$this->lang];
        }
        $result['data'] = $row;
        $result['status'] = true;
        return response()->json($result);
    }
}
