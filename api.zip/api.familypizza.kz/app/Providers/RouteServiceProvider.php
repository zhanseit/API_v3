<?php

namespace App\Providers;

use Illuminate\Support\Facades\Route;
use Illuminate\Foundation\Support\Providers\RouteServiceProvider as ServiceProvider;
use App;
use Illuminate\Http\Request;
use Cookie;
use Illuminate\Support\Facades\URL;
use View;


class RouteServiceProvider extends ServiceProvider
{
    /**
     * This namespace is applied to your controller routes.
     *
     * In addition, it is set as the URL generator's root namespace.
     *
     * @var string
     */
    protected $namespace = 'App\Http\Controllers';

    /**
     * Define your route model bindings, pattern filters, etc.
     *
     * @return void
     */
    public function boot()
    {
        //

        parent::boot();
    }

    /**
     * Define the routes for the application.
     *
     * @return void
     */
    public function map(Request $request)
    {
        if ($request->isMethod('get')) {
            $locale = $request->segment(1);
            $lang_list = ['ru', 'kz', 'en'];

            if (in_array($locale, $lang_list)) {
                $this->app->setLocale($locale);
                View::share('lang', $locale);
                setcookie("site_lang", $locale, time() + (86400 * 30), "/");
            } else {
                if (Cookie::has('site_lang') && Cookie::get('site_lang') != 'ru') {
                    $locale = Cookie::get('site_lang');
                    $url = str_replace(URL::to('/') ,""."/".$locale,$request->fullUrl());
                    header('Location: ' . $url);
                    exit();
                } else $locale = null;
            }
            Route::group([
                'middleware' => 'web',
                'namespace' => $this->namespace,
                'prefix' => $locale
            ], function ($router) {
                require base_path('routes/web.php');
            });
        }
        $this->mapApiRoutes();
        $this->mapWebRoutes();
    }

    /**
     * Define the "web" routes for the application.
     *
     * These routes all receive session state, CSRF protection, etc.
     *
     * @return void
     */
    protected function mapWebRoutes()
    {
        Route::group([
            'middleware' => 'web',
            'namespace' => $this->namespace,
        ], function ($router) {
            require base_path('routes/web.php');
        });
    }

    /**
     * Define the "api" routes for the application.
     *
     * These routes are typically stateless.
     *
     * @return void
     */
    protected function mapApiRoutes()
    {
        Route::group([
            'middleware' => 'api',
            'namespace' => $this->namespace,
            'prefix' => 'api',
        ], function ($router) {
            require base_path('routes/api.php');
        });
    }
}
