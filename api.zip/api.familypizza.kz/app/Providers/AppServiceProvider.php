<?php

namespace App\Providers;

use Illuminate\Http\Request;
use Illuminate\Support\ServiceProvider;
use App;
use View;
use Cookie;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot(Request $request)
    {
        if($request->header('Lang') == 'kz')
             $this->app->setLocale($request->header('Lang'),'ru');
        else $this->app->setLocale(Cookie::get('site_lang'),'ru');

        $locale = App::getLocale();

        View::share('lang', $locale);

        View::share('request', $request);
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }
}
