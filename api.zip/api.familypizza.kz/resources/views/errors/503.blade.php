@extends('index.layout.layout')

@section('content')

    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="container page-vacancy not-found-page">
                    <h2>
                        503
                    </h2>
                    <h3>К сожалению, по Вашему запросу ничего не найдено</h3>
                    <a href="/">
                        <span class="mkd-btn-text">Перейти на главную страницу</span>
                    </a>
                </div>
            </div>
        </div>
    </div>

@endsection