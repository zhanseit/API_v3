<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::group([
    'namespace' => 'API',
], function() {
    Route::get('users', 'ProfileController@getUserList');
    Route::post('users', 'ProfileController@addUser');
	Route::get('users/{user_id}', 'ProfileController@getUserById');
	Route::post('users/setPoints', 'ProfileController@checkUser');
});


