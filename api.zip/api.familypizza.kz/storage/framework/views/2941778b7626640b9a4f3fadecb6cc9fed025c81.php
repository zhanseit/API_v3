<!Doctype html>
<html lang="en">

<?php echo $__env->make('index.layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<body>
<i class="ajax-loader"></i>

<?php echo $__env->make('index.layout.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->yieldContent('content'); ?>

<?php echo $__env->make('index.layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<script src="/js/jquery-1.11.0.js"></script>
<script src="/js/bootstrap.min.js"></script>
<script src="/custom/js/moment.js"></script>
<script src="/custom/js/bootstrap-datetimepicker.min.js"></script>
<script src="/js/bootstrap-select.js"></script>
<script src="/custom/js/jquery.gritter.js"></script>
<script src="/custom/js/ajax.js?v=1"></script>
<script src="/custom/js/custom.js"></script>
<script src="/custom/js/jquery.maskedinput.js"></script>

<input type="hidden" value="<?php echo e(isset($_GET['redirect_url'])?$_GET['redirect_url']:''); ?>" id="redirect_url"/>


</body>
</html>

