<ul class="sidebar-menu">
  <li class="header">МЕНЮ</li>
  <li class="treeview">
    <a href="/admin/news">
      <i class="fa fa-file-text"></i>
      <span>Новости</span>
    </a>
  </li>
  <li class="treeview">
    <a href="/admin/vacancy">
      <i class="fa fa-file-text"></i>
      <span>Вакансии</span>
    </a>
  </li>
  <li class="treeview">
    <a href="/admin/response">
      <i class="fa fa-file-text"></i>
      <span>Отклики</span>
    </a>
  </li>
  <li class="treeview">
    <a href="/admin/review">
      <i class="fa fa-file-text"></i>
      <span>Отзывы</span>
    </a>
  </li>
  <li class="treeview">
    <a href="/admin/master">
      <i class="fa fa-user"></i>
      <span>Соискатели</span>
    </a>
  </li>
  <li class="treeview">
    <a href="/admin/company">
      <i class="fa fa-user"></i>
      <span>Работодатели</span>
    </a>
  </li>
  <li class="treeview">
    <a href="/admin/speciality">
      <i class="fa fa-file-text"></i>
      <span>Специальность</span>
    </a>
  </li>
  <li class="treeview">
    <a href="/admin/user">
      <i class="fa fa-user"></i>
      <span>Администраторы</span>
    </a>
  </li>
  <li class="treeview">
    <a href="/admin/password">
      <i class="fa fa-user"></i>
      <span>Сменить пароль</span>
    </a>
  </li>
</ul>