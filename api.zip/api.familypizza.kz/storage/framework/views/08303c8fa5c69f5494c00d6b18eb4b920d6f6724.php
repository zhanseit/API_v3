<?php $__env->startSection('content'); ?>

        <section class="content-header">
            <h1>
              <?php echo e($title); ?>

            </h1>
        </section>
        <section class="content">
            <div class="row">
                <div class="col-md-12">
                   <div class="col-md-8" style="padding-left: 0px">
                       <div class="box box-primary">
                           <?php if(isset($error)): ?>
                               <div class="alert alert-danger">
                                   <?php echo e($error); ?>

                               </div>
                           <?php endif; ?>
                           <?php if($row->price_id > 0): ?>
                               <form action="/admin/price/<?php echo e($row->price_id); ?>" method="POST">
                                   <input type="hidden" name="_method" value="PUT">
                           <?php else: ?>
                               <form action="/admin/price" method="POST">
                           <?php endif; ?>
                                   <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                   <input type="hidden" name="price_id" value="<?php echo e($row->price_id); ?>">
                                   <input type="hidden" value="<?php if(isset($_GET['parent_id'])): ?><?php echo e($_GET['parent_id']); ?><?php endif; ?>" name="parent_id">
                                   <input type="hidden" value="<?php echo e($row->price_image); ?>" name="price_image" class="image-name">

                                   <div class="box-body">
                                       <div class="form-group">
                                           <label>Название</label>
                                           <input value="<?php echo e($row->price_name_ru); ?>" type="text" class="form-control" name="price_name_ru" placeholder="Введите">
                                       </div>
                                       <div class="form-group">
                                           <label>Цена</label>
                                           <input value="<?php echo e($row->price); ?>" type="text" class="form-control" name="price" placeholder="Введите">
                                       </div>
                                       <div class="form-group">
                                           <label>Услуга</label>
                                           <select name="service_id" data-placeholder="Выберите услугу" class="form-control">

                                               <?php $__currentLoopData = $service_row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                   <option <?if($row->category_id == $item->service_id) echo 'selected '; ?> value="<?php echo e($item->service_id); ?>"><?php echo e($item['service_name_ru']); ?></option>
                                               <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                                           </select>
                                       </div>
                                       <div class="form-group">
                                           <label>Категория</label>
                                           <select name="category_id" data-placeholder="Выберите категорию" class="form-control">

                                               <?php $__currentLoopData = $category_row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                   <option <?if($row->category_id == $item->category_id) echo 'selected '; ?> value="<?php echo e($item->category_id); ?>"><?php echo e($item['category_name_ru']); ?></option>
                                               <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                                           </select>
                                       </div>
                                       <div class="form-group">
                                           <label>Порядковый номер сортировки</label>
                                           <input value="<?php echo e($row->sort_num); ?>" type="text" class="form-control" name="sort_num" placeholder="Введите">
                                       </div>
                                   </div>
                                   <div class="box-footer">
                                       <button type="submit" class="btn btn-primary">Сохранить</button>
                                   </div>
                                </form>
                       </div>
                   </div>
                </div>
            </div>
        </section>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>