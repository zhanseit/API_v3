<?php $__env->startSection('content'); ?>

    <div class="mkd-content" style="margin-bottom: 529px;">
        <div class="mkd-content-inner">
            <div class="mkd-full-width">
                <div class="mkd-full-width-inner">
                    <div data-mkd-parallax-speed="1"
                         class="vc_row wpb_row vc_row-fluid mkd-section mkd-content-aligment-left" style="">
                        <div class="clearfix mkd-full-section-inner">
                            <div class="wpb_column vc_column_container vc_col-sm-12">
                                <div class="wpb_wrapper">
                                    <div class="mkd-google-map-holder">
                                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2905.6823598933374!2d76.93377718208536!3d43.258078522950015!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x38836ebc81feac05%3A0xb96f31bbeb7c5b6b!2z0YPQu9C40YbQsCDQndCw0YPRgNGL0LfQsdCw0Lkg0JHQsNGC0YvRgNCwIDQ3LCDQkNC70LzQsNGC0Ys!5e0!3m2!1sru!2skz!4v1483713624877" width="100%" height="430" frameborder="0" style="border:0" allowfullscreen></iframe>
                                        <div class="mkd-google-map-overlay"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div data-mkd-parallax-speed="1"
                         class="vc_row wpb_row vc_row-fluid mkd-section vc_custom_1450198118362 mkd-content-aligment-center mkd-parallax-section-holder mkd-parallax-section-holder-touch-disabled mkd-grid-section"
                         style="background-image: url('/image/h6-parallax.jpg'); min-height: 200px; height: auto; opacity: 1; background-position: 50% -25px; padding-top: 30px; padding-bottom: 30px">
                        <div class="clearfix mkd-section-inner">
                            <div class="mkd-section-inner-margin clearfix">
                                <div class="wpb_column vc_column_container vc_col-sm-12">
                                    <div class="wpb_wrapper">
                                        <div class="mkd-separator-holder clearfix  mkd-separator-center mkd-separator-with-icon" style="margin-top: 20px; margin-bottom: 25px">
                                            <div class="mkd-separator" style="border-color: #c18f59;border-style: solid;width: 97.5px"></div>
                                            <div class="mkd-separator-icon">
                                                <img src="/image/h1-separator-custom-icon-1.png" class="attachment-full" alt="a" width="34" height="23"></div>
                                            <div class="mkd-separator"
                                                 style="border-color: #c18f59;border-style: solid;width: 97.5px"></div>
                                        </div>
                                        <div class="wpb_text_column wpb_content_element ">
                                            <div class="wpb_wrapper">
                                                <h1><span style="color: #ffffff;">Консалтинговая компания ТОО «М-Консалт»</span></h1>
                                            </div>
                                        </div>
                                        <div class="vc_empty_space" style="height: 15px">
                                            <span class="vc_empty_space_inner"></span>
                                        </div>
                                        <div data-mkd-parallax-speed="1"
                                             class="vc_row wpb_row vc_inner vc_row-fluid mkd-section vc_custom_1447344698782 mkd-content-aligment-left"
                                             style="">
                                            <div class="mkd-full-section-inner">
                                                <div class="wpb_column vc_column_container vc_col-sm-12 vc_col-lg-6 vc_col-md-12">
                                                    <div class="wpb_wrapper">
                                                        <div class="vc_empty_space" style="height: 16px">
                                                            <span class="vc_empty_space_inner"></span>
                                                        </div>
                                                        <div class="mkd-iwt clearfix mkd-iwt-icon-left mkd-iwt-icon-circle mkd-iwt-icon-small">
                                                            <div class="mkd-iwt-icon-holder">
                                                                <span class="mkd-icon-shortcode circle mkd-icon-linked" style="width: 57px;height: 57px;line-height: 57px"
                                                                      data-hover-background-color="#c18f59" data-hover-color="#ffffff" data-color="#ffffff">
                                                                        <a href="#" >
                                                                            <i class="mkd-icon-simple-line-icon icon-info mkd-icon-element"
                                                                               style="color: rgb(255, 255, 255); font-size: 33px;"></i>
                                                                        </a>
                                                                        <span style="background-color: rgb(53, 60, 78);" class="mkd-background"></span>
                                                                </span>
                                                            </div>
                                                            <div class="mkd-iwt-content-holder"  style="padding-left: 72px">
                                                                <div class="mkd-iwt-title-holder">
                                                                    <h2 style="color: #ffffff">
                                                                        <a href="#">Предлагаемая помощь</a>
                                                                    </h2>
                                                                </div>
                                                                <div class="mkd-iwt-text-holder">
                                                                    <p style="color: #ffffff">Многоканальный телефон обеспечит вам срочный доступ к компетентной скорой «юридической помощи». Это возможность получать экстренные консультации и рекомендации при чрезвычайных происшествиях, таких, как ДТП или иные конфликты с участием третьей стороны, при острых административных конфликтах, требующих срочного вмешательства, при происшествиях с участием правоохранительных органов, а также экстренную помощь при уголовном преследовании, при необходимости дачи показаний или объяснений.</p>
                                                                    <p style="color: #ffffff">В случае необходимости мы обеспечим вам возможность личной встречи с юристом или адвокатом, специализирующимся на требуемой области права, который сможет изучить ваши документы, представить ваши интересы в инстанциях или суде.</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="wpb_column vc_column_container vc_col-sm-12 vc_col-lg-6 vc_col-md-12">
                                                    <div class="wpb_wrapper">
                                                        <div class="vc_empty_space" style="height: 16px">
                                                            <span class="vc_empty_space_inner"></span>
                                                        </div>
                                                        <div class="mkd-iwt clearfix mkd-iwt-icon-left mkd-iwt-icon-circle mkd-iwt-icon-small">
                                                            <div class="mkd-iwt-icon-holder">
                                                                <span class="mkd-icon-shortcode circle mkd-icon-linked" style="width: 57px;height: 57px;line-height: 57px"
                                                                      data-hover-background-color="#c18f59" data-hover-color="#ffffff" data-color="#ffffff">
                                                                        <a href="#" >
                                                                            <i class="mkd-icon-simple-line-icon icon-map mkd-icon-element"
                                                                               style="color: rgb(255, 255, 255); font-size: 33px;"></i>
                                                                        </a>
                                                                        <span style="background-color: rgb(53, 60, 78);" class="mkd-background"></span>
                                                                </span>
                                                            </div>
                                                            <div class="mkd-iwt-content-holder"  style="padding-left: 72px">
                                                                <div class="mkd-iwt-title-holder">
                                                                    <h2 style="color: #ffffff">
                                                                        <a href="#">Наш адрес</a>
                                                                    </h2>
                                                                </div>
                                                                <div class="mkd-iwt-text-holder">
                                                                    <p style="color: #ffffff">город Алматы, улица Наурызбай батыра (Дзержинский) 47, офис 19, угол улицы Айтеки би</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="vc_empty_space" style="height: 40px">
                                                            <span class="vc_empty_space_inner"></span>
                                                        </div>
                                                        <div class="mkd-iwt clearfix mkd-iwt-icon-left mkd-iwt-icon-circle mkd-iwt-icon-small">
                                                            <div class="mkd-iwt-icon-holder">
                                                                <span class="mkd-icon-shortcode circle mkd-icon-linked" style="width: 57px;height: 57px;line-height: 57px"
                                                                      data-hover-background-color="#c18f59" data-hover-color="#ffffff" data-color="#ffffff">
                                                                                <a href="#" >
                                                                                    <i class="mkd-icon-simple-line-icon icon-phone mkd-icon-element" style="color: #ffffff;font-size:33px"></i>
                                                                                </a>
                                                                                <span style="background-color: #353c4e" class="mkd-background"></span>
                                                                </span>
                                                            </div>
                                                            <div class="mkd-iwt-content-holder"
                                                                 style="padding-left: 72px">
                                                                <div class="mkd-iwt-title-holder">
                                                                    <h2 style="color: #ffffff">
                                                                        <a href="#">Номер телефона</a>
                                                                    </h2>
                                                                </div>
                                                                <div class="mkd-iwt-text-holder">
                                                                    <p style="color: #ffffff">
                                                                        <a href="tel:+77026684468" style="color: #ffffff"><i class="fa fa-phone" style="margin-right: 10px"></i>+7(702)668-44-68</a></br>
                                                                        <a href="tel:+77474973126" style="color: #ffffff"><i class="fa fa-phone" style="margin-right: 10px"></i>+7(747)497-31-26</a></br>
                                                                        <a href="tel:+77272792648" style="color: #ffffff"><i class="fa fa-phone" style="margin-right: 10px"></i>+7(727)279-26-48</a>
                                                                    </p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="vc_empty_space" style="height: 40px"><span class="vc_empty_space_inner"></span></div>
                                                        <div class="mkd-iwt clearfix mkd-iwt-icon-left mkd-iwt-icon-circle mkd-iwt-icon-small">
                                                            <div class="mkd-iwt-icon-holder">
                                                                <span class="mkd-icon-shortcode circle mkd-icon-linked" style="width: 57px;height: 57px;line-height: 57px"
                                                                      data-hover-background-color="#c18f59" data-hover-color="#ffffff" data-color="#ffffff">
                                                                    <a href="">
                                                                        <i class="mkd-icon-simple-line-icon icon-envelope mkd-icon-element" style="color: #ffffff;font-size:33px"></i>
                                                                    </a>
                                                                    <span style="background-color: #353c4e" class="mkd-background"></span>
                                                                </span>
                                                            </div>
                                                            <div class="mkd-iwt-content-holder"
                                                                 style="padding-left: 72px">
                                                                <div class="mkd-iwt-title-holder">
                                                                    <h2 style="color: #ffffff">
                                                                        <a href="#">
                                                                            Мы в социальных сетях</a>
                                                                    </h2>
                                                                </div>
                                                                <div class="mkd-iwt-text-holder">
                                                                    <p style="color: #ffffff">
                                                                        <a href="mailto::m-consult.kz@mail.ru" style="color: #ffffff"><i class="fa fa-envelope-o" style="margin-right: 10px"></i>m-consult.kz@mail.ru</a></br>
                                                                        <a target="_blank" href="https://facebook.com/mconsalt.kz" style="color: #ffffff;"><i class="fa fa-facebook" style="margin-right: 10px"></i>Facebook</a></br>
                                                                        <a target="_blank" href="https://www.instagram.com/mconsult.kz/" style="color: #ffffff;"><i class="fa fa-instagram" style="margin-right: 10px"></i>Instagram</a></br>
                                                                    </p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="vc_empty_space" style="height: 40px"><span class="vc_empty_space_inner"></span></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('index.layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>