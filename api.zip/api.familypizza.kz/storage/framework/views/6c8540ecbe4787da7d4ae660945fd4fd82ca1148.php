<?php if(isset($row->vacancy_desc)): ?>

    <title>Вакансия. <?php echo e($row['speciality_name_'.$lang]); ?> - <?php echo e(strip_tags(substr($row['vacancy_desc'],0,50))); ?></title>
    <meta property="og:title" content="Вакансия. <?php echo e($row['speciality_name_'.$lang]); ?> - <?php echo e(strip_tags(substr($row['vacancy_desc'],0,50))); ?>" />
    <meta name="title" content="Вакансия. <?php echo e($row['speciality_name_'.$lang]); ?> - <?php echo e(strip_tags(substr($row['vacancy_desc'],0,50))); ?>" />
    <meta property="og:description" content="Вакансия. <?php echo e($row['speciality_name_'.$lang]); ?> - <?php echo e(strip_tags(substr($row['vacancy_desc'],0,400))); ?>" />
    <meta name="description" content="Вакансия. <?php echo e($row['speciality_name_'.$lang]); ?> - <?php echo e(strip_tags(substr($row['vacancy_desc'],0,400))); ?>" />
    <meta name="keywords" content="Вакансия, <?php echo e($row['speciality_name_'.$lang]); ?>, Шымкент" />

<?php elseif(isset($user->role_id)): ?>

    <title>Профиль. <?php echo e($user['user_name']); ?></title>
    <meta property="og:title" content="Профиль. <?php echo e($user['user_name']); ?>" />
    <meta name="title" content="Профиль. <?php echo e($user['user_name']); ?>" />
    <meta property="og:description" content="Профиль. <?php echo e($user['user_name']); ?>" />
    <meta name="description" content="Профиль. <?php echo e($user['user_name']); ?>" />
    <meta name="keywords" content="Профиль, Шымкент, <?php echo e($user['user_name']); ?> <?php if($user['speciality_name_'.$lang] != ''): ?>, <?php echo e($user['speciality_name_'.$lang]); ?><?php endif; ?>" />

<?php else: ?>

    <?$meta_title = Lang::get('app.employment_road_map');?>
    <title><?php echo e(isset($title)?$title:$meta_title); ?></title>
    <meta property="og:title" content="<?php echo e(isset($title)?$title:$meta_title); ?>" />
    <meta name="title" content="<?php echo e(isset($title)?$title:$meta_title); ?>" />
    <meta property="og:description" content="" />
    <meta name="description" content="" />
    <meta name="keywords" content="" />

<?php endif; ?>


