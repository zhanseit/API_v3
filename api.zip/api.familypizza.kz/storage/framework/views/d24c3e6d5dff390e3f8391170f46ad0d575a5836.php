<?php $__env->startSection('content'); ?>

    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="container">
                    <h2 class="main-title"><?php echo e(Lang::get('app.add_vacancy')); ?></h2>

                    <div class="row ">

                        <div class="col-md-6 col-sm-6 form-regis">
                            <span><?php echo e(Lang::get('app.find_who')); ?></span>
                            <select class="selectpicker" data-live-search="true" id="speciality_id">

                                <?php $__currentLoopData = $speciality_row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

                                    <option value="<?php echo e($item->speciality_id); ?>"><?php echo e($item['speciality_name_'.$lang]); ?></option>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                            </select>
                        </div>

                        <div class="col-md-6 col-sm-6 form-regis">
                            <span><?php echo e(Lang::get('app.work_date')); ?></span>
                            <input class="date-mask" type="text" value="" id="deadline">
                        </div>

                        <div class="col-md-12">
                            <h3><b><?php echo e(Lang::get('app.pay')); ?></b></h3>
                        </div>

                        <div class="col-md-6 col-sm-6 form-regis">
                            <span><?php echo e(Lang::get('app.during')); ?></span>
                            <select id="pay_duration">
                                <option value="час"><?php echo e(Lang::get('app.hour')); ?></option>
                                <option value="неделя"><?php echo e(Lang::get('app.week')); ?></option>
                                <option value="месяц"><?php echo e(Lang::get('app.month')); ?></option>
                            </select>
                        </div>

                        <div class="col-md-6 col-sm-6 form-regis">
                            <span><?php echo e(Lang::get('app.money_tenge')); ?></span>
                            <input type="number" value="" id="salary">
                        </div>

                        <div class="col-md-6 col-sm-6 form-regis">
                            <span><?php echo e(Lang::get('app.work_count')); ?></span>
                            <input type="number" value="" id="work_count">
                        </div>

                        <div class="col-md-6 col-sm-6 form-regis">
                            <span><?php echo e(Lang::get('app.address_work')); ?></span>
                            <input type="text" value="" id="address">
                        </div>

                        <div class="col-md-12 col-sm-12 form-regis">
                            <span><?php echo e(Lang::get('app.vacancy_desc')); ?></span>
                            <textarea id="vacancy_desc"></textarea>
                        </div>

                        <div class="col-md-12">
                            <div class="btn-vacancy">
                                <button class="btns-yellow" onclick="addVacancy()"><?php echo e(Lang::get('app.publish_vacancy')); ?></button>
                                <a href="/profile/vacancy"><button class="btn-grey"><?php echo e(Lang::get('app.cancel')); ?></button></a>
                            </div>
                        </div>

                    </div>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('index.layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>