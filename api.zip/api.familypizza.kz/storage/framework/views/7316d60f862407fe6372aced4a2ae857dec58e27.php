<?php $__env->startSection('content'); ?>

    <div class="mkd-content" style="margin-bottom: 529px;">
        <div class="mkd-content-inner">
            <div class="mkd-title mkd-title-enabled-breadcrumbs mkd-standard-type mkd-has-background mkd-has-parallax-background mkd-content-left-alignment mkd-animation-no mkd-title-image-not-responsive" style="height: 130px; background-image: url('/image/title-img.jpg'); background-repeat: no-repeat; background-position: center -36.68px;" data-height="200" data-background-width="&quot;1920&quot;">
                <div class="mkd-title-image">
                    <img src="/image/title-img.jpg" alt="&nbsp;">
                </div>
                <div class="mkd-title-holder" style="height:130px;">
                    <div class="mkd-container clearfix">
                        <div class="mkd-container-inner">
                            <div class="mkd-title-subtitle-holder" style="">
                                <div class="mkd-title-subtitle-holder-inner">
                                    <h1><span>Полезные советы</span></h1>
                                    <div class="mkd-breadcrumbs-holder">
                                        <div class="mkd-breadcrumbs">
                                            <div class="mkd-breadcrumbs-inner">
                                                <a href="/">Главная</a>
                                                <span class="mkd-delimiter">&nbsp;&gt;&nbsp;</span>
                                                <span class="mkd-current">Полезные советы</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <div class="mkd-full-width">
                <div class="mkd-full-width-inner">
                    <div data-mkd-parallax-speed="1" class="vc_row wpb_row vc_row-fluid mkd-section vc_custom_1447248999330 mkd-content-aligment-left mkd-grid-section" style="">
                        <div class="clearfix mkd-section-inner">
                            <div class="mkd-section-inner-margin clearfix">
                                <div class="wpb_column vc_column_container vc_col-sm-12">
                                    <div class="wpb_wrapper">
                                        <div class="mkd-portfolio-list-holder-outer mkd-ptf-standard mkd-ptf-three-columns mkd-ptf-load-more mkd-ptf-has-filter" data-next-page="2" data-type="standard" data-columns="three" data-grid-size="three" data-order-by="menu_order" data-order="ASC" data-number="9" data-image-size="square" data-filter="yes" data-filter-order-by="name" data-show-load-more="yes" data-title-tag="h4" data-max-num-pages="3">
                                            <div class="mkd-portfolio-list-holder clearfix" id="MixItUp756486">

                                                <?php $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

                                                    <article class="mkd-portfolio-item mix portfolio_category_9 portfolio_category_12" style="visibility: visible; display: inline-block;">
                                                        <div class="mkd-item-image-holder">
                                                            <a href="/blog/<?php echo e(\App\Http\Helpers::getTranslatedSlugRu($item->news_name_ru)); ?>-u<?php echo e($item->news_id); ?>">
                                                                <img src="<?php echo e($item->news_image); ?>?width=350&height=250" class="attachment-libero_mikado_square wp-post-image" alt="a" width="645" height="445">
                                                            </a>
                                                        </div>
                                                        <div class="mkd-item-text-holder">
                                                            <h4 class="mkd-item-title">
                                                                <a href="/blog/<?php echo e(\App\Http\Helpers::getTranslatedSlugRu($item->news_name_ru)); ?>-u<?php echo e($item->news_id); ?>" style="text-transform: none">
                                                                    <?php echo e($item->news_name_ru); ?>

                                                                </a>
                                                            </h4>
                                                            <div class="mkd-ptf-category-holder">
                                                                <span><?php echo e($item->date); ?></span>
                                                            </div>
                                                        </div>
                                                    </article>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>


                                                <div class="mkd-gap"></div>
                                                <div class="mkd-gap"></div>
                                                <div class="mkd-gap"></div>
                                                <div class="mkd-gap"></div>
                                            </div>
                                            <div class="mkd-ptf-list-paging"></div>
                                            <div style="text-align: center">
                                                <?php echo e($row->links()); ?>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('index.layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>