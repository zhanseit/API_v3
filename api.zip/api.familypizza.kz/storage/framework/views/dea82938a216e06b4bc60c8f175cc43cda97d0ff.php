<?php $__env->startSection('content'); ?>

    <div class="mkd-content" style="margin-bottom: 529px;">
        <div class="mkd-content-inner">
            <div class="mkd-title mkd-title-enabled-breadcrumbs mkd-standard-type mkd-has-background mkd-has-parallax-background mkd-content-left-alignment mkd-animation-no mkd-title-image-not-responsive" style="height: 130px; background-image: url('/image/title-img.jpg'); background-repeat: no-repeat; background-position: center -36.68px;" data-height="200" data-background-width="&quot;1920&quot;">
                <div class="mkd-title-image">
                    <img src="/image/title-img.jpg" alt="&nbsp;">
                </div>
                <div class="mkd-title-holder" style="height:130px;">
                    <div class="mkd-container clearfix">
                        <div class="mkd-container-inner">
                            <div class="mkd-title-subtitle-holder" style="">
                                <div class="mkd-title-subtitle-holder-inner">
                                    <h1><span>Услуги</span></h1>
                                    <div class="mkd-breadcrumbs-holder">
                                        <div class="mkd-breadcrumbs">
                                            <div class="mkd-breadcrumbs-inner">
                                                <a href="/">Главная</a>
                                                <span class="mkd-delimiter">&nbsp;&gt;&nbsp;</span>
                                                <span class="mkd-current">Услуги</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <div class="mkd-full-width" style="padding-bottom: 40px">
                <div class="mkd-full-width-inner">
                    <div data-mkd-parallax-speed="1" class="vc_row wpb_row vc_row-fluid mkd-section vc_custom_1450198046093 mkd-content-aligment-center mkd-grid-section" style="">
                        <div class="clearfix mkd-section-inner">
                            <div class="mkd-section-inner-margin clearfix">
                                <div class="wpb_column vc_column_container vc_col-sm-12">
                                    <div class="wpb_wrapper">
                                        <div class="mkd-separator-holder clearfix  mkd-separator-center mkd-separator-with-icon" style="margin-top: 60px; margin-bottom: 35px;">
                                            <div class="mkd-separator" style="border-color: #c18f59;border-style: solid;width: 97.5px"></div>
                                            <div class="mkd-separator-icon">
                                                <img src="/image/h1-separator-custom-icon-1.png" class="attachment-full" alt="a" width="34" height="23">
                                            </div>
                                            <div class="mkd-separator" style="border-color: #c18f59;border-style: solid;width: 97.5px"></div>
                                        </div>
                                        <div class="wpb_text_column wpb_content_element ">
                                            <div class="wpb_wrapper">
                                                <h1 style="margin-bottom: 0px"><?php echo e($parent->service_name_ru); ?></h1>
                                            </div>
                                        </div>
                                        <div class="vc_empty_space" style="height: 15px"><span class="vc_empty_space_inner"></span></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div data-mkd-parallax-speed="1"
                         class="vc_row wpb_row vc_row-fluid mkd-section vc_custom_1450197453742 mkd-content-aligment-center mkd-grid-section"
                         style="">
                        <div class="clearfix mkd-section-inner">
                            <div class="mkd-section-inner-margin clearfix">
                                <div class="mkd-row-animations-holder mkd-element-from-fade">
                                    <div>

                                        <?php $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

                                            <div class="wpb_column vc_column_container vc_col-sm-6 vc_col-lg-3 vc_col-md-3">
                                                <div class="wpb_wrapper">
                                                    <div class="mkd-interactive-image mkd-animate-image mkd-linked">
                                                        <a href="/service/<?php echo e($item->getLink()); ?>"></a>
                                                        <img style="border-radius: 50%" src="<?php echo e($item->service_image); ?>" class="attachment-full" alt="a" width="200" height="200">
                                                    </div>
                                                    <div class="vc_empty_space" style="height: 22px"><span class="vc_empty_space_inner"></span></div>
                                                    <div class="wpb_text_column wpb_content_element ">
                                                        <div class="wpb_wrapper">
                                                            <a href="/service/<?php echo e($item->getLink()); ?>">
                                                                <h4 style="font-style: italic; font-size: 17px;"><?php echo e($item->service_name_ru); ?></h4>
                                                            </a>
                                                        </div>
                                                    </div>
                                                    <div class="vc_empty_space" style="height: 12px"><span class="vc_empty_space_inner"></span></div>
                                                    <div class="vc_empty_space" style="height: 40px"><span class="vc_empty_space_inner"></span></div>
                                                </div>
                                            </div>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('index.layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>