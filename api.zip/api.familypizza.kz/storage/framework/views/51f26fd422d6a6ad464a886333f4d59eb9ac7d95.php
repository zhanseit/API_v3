<?php $__env->startSection('content'); ?>

    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="container page-vacancy">
                    <h2 class="main-title"><?php echo e(Lang::get('app.cabinet')); ?></h2>
                    <table>

                        <?php if($user->is_company == 0): ?>

                            <tr>
                                <td><?php echo e(Lang::get('app.full_name')); ?></td>
                                <td><b class="price-job"><?php echo e($user->user_name); ?></b></td>
                            </tr>

                        <?php else: ?>

                            <tr>
                                <td><?php echo e(Lang::get('app.name_of_organization')); ?></td>
                                <td><b class="price-job"><?php echo e($user->user_name); ?></b></td>
                            </tr>

                        <?php endif; ?>

                        <?php if($user->role_id == 2): ?>

                            <tr>
                                <td><?php echo e(Lang::get('app.legal_entity_or_individual')); ?></td>
                                <td><b><?php echo e($user->is_company?Lang::get('app.legal_entity'):Lang::get('app.individual')); ?></b></td>
                            </tr>

                        <?php else: ?>

                            <tr>
                                <td><?php echo e(Lang::get('app.age')); ?></td>
                                <td><b><?php echo e($user->age); ?></b></td>
                            </tr>

                        <?php endif; ?>


                        <tr>
                            <td><?php echo e(Lang::get('app.rating')); ?></td>
                            <td>
                               <?php echo $__env->make('index.profile.rating-part', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            </td>
                        </tr>
                        <tr>
                            <td><?php echo e(Lang::get('app.iin')); ?></td>
                            <td><b><?php echo e($user->inn); ?></b></td>
                        </tr>

                        <?php if($user->role_id == 3): ?>

                            <tr>
                                <td><?php echo e(Lang::get('app.speciality')); ?></td>
                                <td><b><?php echo e($user['speciality_name_'.$lang]); ?></b></td>
                            </tr>

                        <?php endif; ?>

                        <tr>
                            <td><?php echo e(Lang::get('app.phone')); ?></td>
                            <td><b><?php echo e(\App\Http\Helpers::getPhoneFormat($user->phone)); ?></b></td>
                        </tr>

                    </table>

                    <?php if($user->user_desc != ''): ?>

                        <h4><?php echo e(Lang::get('app.about_me')); ?>:</h4>
                        <p><?php echo e($user->user_desc); ?></p>

                    <?php endif; ?>

                    <div class="btn-vacancy">


                        <?php if(Auth::check() && Auth::user()->user_id == $user->user_id): ?>

                            <?php if($user->role_id == 3): ?>

                                <a href="/vacancy">
                                    <button class="btns-yellow"><?php echo e(Lang::get('app.find_work')); ?></button>
                                </a>

                            <?php else: ?>

                                <a href="/profile/vacancy">
                                    <button class="btns-yellow"><?php echo e(Lang::get('app.my_vacancy')); ?></button>
                                </a>

                            <?php endif; ?>


                            <a href="/profile/edit">
                                <button class="btn-blue"><?php echo e(Lang::get('app.edit_profile')); ?></button>
                            </a>

                        <?php else: ?>

                            <a href="/vacancy">
                                <button class="btns-yellow"><?php echo e(Lang::get('app.find_work')); ?></button>
                            </a>

                        <?php endif; ?>

                    </div>

                    <div class="box-reviews">
                        <h2 class="title-2"><?php echo e(Lang::get('app.reviews')); ?> (<?php echo e($user->rating_count); ?>)
                            <?php if(Auth::check() && Auth::user()->user_id != $user->user_id): ?>

                                <a href="/review?user=<?php echo e(\App\Http\Helpers::getTranslatedSlugRu($user->user_name)); ?>-u<?php echo e($user->user_id); ?>" class="pull-right">
                                    <button class="btns-yellow"><?php echo e(Lang::get('app.write_review')); ?></button>
                                </a>

                            <?php elseif(!Auth::check()): ?>

                                <a href="/login?user=<?php echo e(\App\Http\Helpers::getTranslatedSlugRu($user->user_name)); ?>-u<?php echo e($user->user_id); ?>" class="pull-right">
                                    <button class="btns-yellow"><?php echo e(Lang::get('app.write_review')); ?></button>
                                </a>

                            <?php endif; ?>

                        </h2>

                       <?php echo $__env->make('index.profile.review-loop', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


                    </div>

                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('index.layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>