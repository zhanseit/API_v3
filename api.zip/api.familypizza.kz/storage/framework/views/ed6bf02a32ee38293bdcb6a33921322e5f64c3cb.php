<?php $__env->startSection('content'); ?>

        <section class="content-header">
            <h1>
              <?php echo e($title); ?>

            </h1>
        </section>
        <section class="content">
            <div class="row">
                <div class="col-md-12">
                   <div class="col-md-8" style="padding-left: 0px">
                       <div class="box box-primary">
                           <?php if(isset($error)): ?>
                               <div class="alert alert-danger">
                                  <?php echo e($error); ?>

                               </div>
                           <?php endif; ?>
                               <?php if($row->user_id > 0): ?>
                                   <form action="/admin/master/<?php echo e($row->user_id); ?>" method="POST">
                                   <input type="hidden" name="_method" value="PUT">
                               <?php else: ?>
                                   <form action="/admin/master" method="POST">
                               <?php endif; ?>

                                   <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                   <input id="user_id" type="hidden" name="user_id" value="<?php echo e($row->user_id); ?>">
                                   <input type="hidden" class="image-name" id="avatar" name="avatar" value="<?php echo e($row->avatar); ?>"/>

                                   <div class="box-body">
                                       <div class="form-group">
                                           <label>ФИО</label>
                                           <input value="<?php echo e($row->user_name); ?>" type="text" class="form-control" name="user_name" placeholder="Введите">
                                       </div>
                                       <div class="form-group">
                                          <label>Номер телефона</label>
                                          <input value="<?php echo e(\App\Http\Helpers::getPhoneFormat($row->phone)); ?>" type="text" class="form-control phone-mask" name="phone" placeholder="Введите">
                                       </div>
                                       <div class="form-group">
                                           <label>Профессия</label>
                                           <select name="speciality_id" data-placeholder="Выберите" class="form-control">

                                               <?php $__currentLoopData = $speciality; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                   <option <?if($row->speciality_id == $item->speciality_id) echo 'selected '; ?> value="<?php echo e($item->speciality_id); ?>"><?php echo e($item['speciality_name_ru']); ?></option>
                                               <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                                           </select>
                                       </div>
                                       <div class="form-group">
                                           <label>О себе</label>
                                           <textarea name="user_desc" class="form-control"><?=$row->user_desc?></textarea>
                                       </div>
                                       <div class="form-group">
                                           <label>Возраст</label>
                                           <input value="<?php echo e($row->age); ?>" type="text" class="form-control" name="age" placeholder="Введите">
                                       </div>
                                       <div class="form-group">
                                           <label>ИНН</label>
                                           <input value="<?php echo e($row->inn); ?>" type="text" class="form-control" name="inn" placeholder="Введите">
                                       </div>
                                    </div>

                                   <div class="box-footer">
                                       <button type="submit" class="btn btn-primary">Сохранить</button>
                                   </div>
                               </form>
                           </div>
                   </div>

                </div>
            </div>
        </section>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>