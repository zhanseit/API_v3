<section class="mkd-side-menu right" style="overflow-y: hidden;" tabindex="0">
    <div class="mkd-close-side-menu-holder">
        <div class="mkd-close-side-menu-holder-inner">
            <a href="#" target="_self" class="mkd-close-side-menu">
                <span class="ion-ios-close-empty"></span>
            </a>
        </div>
    </div>
    <div id="text-22" class="widget mkd-sidearea widget_text">
        <div class="textwidget">
            <a href="/">
                <img src="/image/logo-side-area.png" alt="a">
            </a>
        </div>
    </div>
    <div id="nav_menu-4" class="widget mkd-sidearea widget_nav_menu">
        <div class="menu-side_area_menu-container">
            <ul id="menu-side_area_menu" class="menu">
                <li id="menu-item-2271" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-388 current_page_item menu-item-2271">
                    <a href="http://libero.mikado-themes.com/">Home</a>
                </li>
                <li id="menu-item-1654" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1654">
                    <a href="http://libero.mikado-themes.com/our-services/">Our Services</a>
                </li>
                <li id="menu-item-1655" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1655">
                    <a href="http://libero.mikado-themes.com/company-history/">Company History</a>
                </li>
                <li id="menu-item-1656" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1656">
                    <a href="http://libero.mikado-themes.com/our-clients/">Clients</a>
                </li>
                <li id="menu-item-1657" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1657">
                    <a href="http://libero.mikado-themes.com/areas-of-expertise/">Areas of Expertise</a>
                </li>
                <li id="menu-item-1658" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1658">
                    <a href="http://libero.mikado-themes.com/car-accident-injuries/">Car Accidents</a>
                </li>
                <li id="menu-item-1660" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1660">
                    <a href="http://libero.mikado-themes.com/contact-with-google-map/">Contact</a>
                </li>
            </ul>
        </div>
    </div>
    <div id="text-23" class="widget mkd-sidearea widget_text">
        <div class="textwidget">
            <div class="vc_empty_space" style="height: 5px">
                <span class="vc_empty_space_inner"></span>
            </div>

            <div class="mkd-iwt clearfix mkd-iwt-icon-top mkd-iwt-icon-normal mkd-iwt-icon-small">
                <div class="mkd-iwt-icon-holder">
                    <span class="mkd-icon-shortcode normal mkd-icon-linked" data-hover-color="#c18f59" data-color="#ffffff">
                        <a href="https://www.facebook.com/" target="_blank">
                        <span aria-hidden="true" class="mkd-icon-font-elegant social_facebook mkd-icon-element" style="color: #ffffff;font-size:23px"></span>
                        </a>
                        <span class="mkd-background"></span>
                    </span>
                </div>
                <div class="mkd-iwt-content-holder">
                    <div class="mkd-iwt-title-holder">
                    </div>
                    <div class="mkd-iwt-text-holder">
                        <p style="color: #ffffff">Facebook</p>
                    </div>
                </div>
            </div>

            <span class="mkd-vertical-separator" style="border-right-color: rgba(255,255,255,0.1);height: 48px;margin-left: 7px;margin-right: 7px"></span>

            <div class="mkd-iwt clearfix mkd-iwt-icon-top mkd-iwt-icon-normal mkd-iwt-icon-small">
                <div class="mkd-iwt-icon-holder">
                    <span class="mkd-icon-shortcode normal mkd-icon-linked" data-hover-color="#c18f59" data-color="#ffffff">
                        <a href="https://twitter.com/" target="_blank">
                            <span aria-hidden="true" class="mkd-icon-font-elegant social_twitter mkd-icon-element" style="color: #ffffff;font-size:23px"></span>
                        </a>
                        <span class="mkd-background"></span>
                    </span>
                </div>
                <div class="mkd-iwt-content-holder">
                    <div class="mkd-iwt-title-holder"></div>
                    <div class="mkd-iwt-text-holder">
                        <p style="color: #ffffff">Twitter</p>
                    </div>
                </div>
            </div>

            <div class="vc_empty_space" style="height: 21px">
                <span class="vc_empty_space_inner"></span>
            </div>
            Copyright 2015 <span style="color:#c18f59">Libero Themes</span>.<br>
            All Rights Reserved.
        </div>
    </div>
</section>