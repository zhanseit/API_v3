<div class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="container">
                <p class="doc-pdf">
                    <a href="#"><img src="/images/pdf.png" alt=""> "Халықты жұмыспен қамту туралы»</a>
                </p>
                <p class="copyright">Разработка, дизайн и поддержка сайта - компания <a target="_blank" href="http://www.bugingroup.com/">Bugin Group</a></p>
            </div>
        </div>
    </div>
</div>