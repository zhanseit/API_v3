<?php $__env->startSection('content'); ?>

    <div class="mkd-content" style="margin-bottom: 529px;">
        <div class="mkd-content-inner">
            <div class="mkd-title mkd-title-enabled-breadcrumbs mkd-standard-type mkd-has-background mkd-has-parallax-background mkd-content-left-alignment mkd-animation-no mkd-title-image-not-responsive" style="height: 130px; background-image: url('/image/title-img.jpg'); background-repeat: no-repeat; background-position: center -36.68px;" data-height="200" data-background-width="&quot;1920&quot;">
                <div class="mkd-title-image">
                    <img src="/image/title-img.jpg" alt="&nbsp;">
                </div>
                <div class="mkd-title-holder" style="height:130px;">
                    <div class="mkd-container clearfix">
                        <div class="mkd-container-inner">
                            <div class="mkd-title-subtitle-holder" style="">
                                <div class="mkd-title-subtitle-holder-inner">
                                    <h1><span>Полезные советы</span></h1>
                                    <div class="mkd-breadcrumbs-holder">
                                        <div class="mkd-breadcrumbs">
                                            <div class="mkd-breadcrumbs-inner">
                                                <a href="/">Главная</a>
                                                <span class="mkd-delimiter">&nbsp;&gt;&nbsp;</span>
                                                <a href="/blog">Полезные советы</a>
                                                <span class="mkd-delimiter">&nbsp;&gt;&nbsp;</span>
                                                <span class="mkd-current"><?php echo e($row->news_name_ru); ?></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="mkd-container">
                <div class="mkd-container-inner">
                    <div class="mkd-two-columns-75-25 clearfix">
                        <div class="mkd-column1 mkd-content-left-from-sidebar">
                            <div class="mkd-column-inner">
                                <div class="mkd-blog-holder mkd-blog-single">
                                    <article id="post-5" class="post-5 post type-post status-publish format-standard has-post-thumbnail hentry category-legal-advice category-necessary-forms tag-experience tag-legal tag-professional-tips tag-strategy">
                                        <div class="mkd-post-content">
                                            <div class="mkd-post-info-column">
                                                <div class="mkd-post-info-column-inner" style="margin-top: 0px;">
                                                    <div class="mkd-post-info-date">
                                                        <span class="mkd-post-info-date-day"><?php echo e($row->news_day); ?></span>
                                                        <span class="mkd-post-info-date-month"><?php echo e(\App\Http\Helpers::getMonthName($row->news_month)); ?></span>
                                                    </div>
                                                    <div class="mkd-post-info-comments-holder">
                                                        <a class="mkd-post-info-comments" href="#" target="_self">
                                                            <span class="mkd-post-info-comments-no"><?php echo e($row->view_count); ?></span>
                                                            <span class="mkd-post-info-comments-text">Просмотры</span>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="mkd-post-content-column">
                                                <div class="mkd-post-text">
                                                    <div class="mkd-post-text-inner">
                                                        <h1 class="mkd-post-title" style="margin-bottom: 0px"><?php echo e($row->news_name_ru); ?></h1>

                                                        <div data-mkd-parallax-speed="1" class="vc_row wpb_row vc_row-fluid mkd-section mkd-content-aligment-left" style="">
                                                            <div class="clearfix mkd-full-section-inner">
                                                                <div class="wpb_column vc_column_container vc_col-sm-12">
                                                                    <div class="wpb_wrapper">
                                                                        <div class="wpb_text_column wpb_content_element ">
                                                                            <div class="wpb_wrapper">
                                                                                <p>
                                                                                    <?php echo $row->news_text_ru; ?>

                                                                                </p>
                                                                            </div>
                                                                            <div class="shareSprite">
                                                                                <script type="text/javascript">(function() {
                                                                                        if (window.pluso)if (typeof window.pluso.start == "function") return;
                                                                                        if (window.ifpluso==undefined) { window.ifpluso = 1;
                                                                                            var d = document, s = d.createElement('script'), g = 'getElementsByTagName';
                                                                                            s.type = 'text/javascript'; s.charset='UTF-8'; s.async = true;
                                                                                            s.src = ('https:' == window.location.protocol ? 'https' : 'http')  + '://share.pluso.ru/pluso-like.js';
                                                                                            var h=d[g]('body')[0];
                                                                                            h.appendChild(s);
                                                                                        }})();
                                                                                </script>

                                                                                <div class="pluso" data-background="transparent" data-options="big,square,line,horizontal,counter,theme=04" data-services="vkontakte,odnoklassniki,facebook,twitter,google,moimir,email,print"></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="vc_empty_space" style="height: 22px">
                                                                            <span class="vc_empty_space_inner"></span>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </article>
                                </div>
                            </div>
                        </div>
                        <div class="mkd-column2">
                            <div class="mkd-column-inner">
                                <aside class="mkd-sidebar">
                                    <div class="widget mkd-holder-widget mkd-holder-has-icon">
                                        <div class="mkd-holder-icon">
                                            <span class="mkd-icon-shortcode circle mkd-icon-small">
                                                <i class="mkd-icon-simple-line-icon icon-info mkd-icon-element" style=""></i>
                                                        <span class="mkd-background"></span>
                                            </span>
                                        </div>
                                        <div class="mkd-holder-content-outer">
                                            <div class="mkd-holder-titles">
                                                <h4>Другие статьи</h4>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="widget mkd-latest-posts-widget" style="margin-top: 0px">
                                        <div class="mkd-blog-list-holder mkd-image-in-box ">
                                            <ul class="mkd-blog-list">

                                                <?php $__currentLoopData = $other_blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

                                                    <li class="mkd-blog-list-item clearfix">
                                                        <div class="mkd-blog-list-item-inner">
                                                            <div class="mkd-item-image clearfix">
                                                                <a href="<?php echo e(\App\Http\Helpers::getTranslatedSlugRu($item->news_name_ru)); ?>-u<?php echo e($item->news_id); ?>">
                                                                    <img src="<?php echo e($item->news_image); ?>?width=75&height=75"
                                                                         class="attachment-libero_mikado_square wp-post-image"
                                                                         alt="a" width="650" height="650">
                                                                </a>
                                                            </div>
                                                            <div class="mkd-item-text-holder">
                                                                <h6 class="mkd-item-title ">
                                                                    <a href="<?php echo e(\App\Http\Helpers::getTranslatedSlugRu($item->news_name_ru)); ?>-u<?php echo e($item->news_id); ?>"><?php echo e($item->news_name_ru); ?></a>
                                                                </h6>
                                                                <div class="mkd-item-info-section">
                                                                    <div class="mkd-post-info-comments-holder">
                                                                        <a class="mkd-post-info-comments" href="<?php echo e(\App\Http\Helpers::getTranslatedSlugRu($item->news_name_ru)); ?>-u<?php echo e($item->news_id); ?>" target="_self">
                                                                            <span class="mkd-post-info-comments-no"><?php echo e($item->view_count); ?></span>
                                                                            <span class="mkd-post-info-comments-text">Просмотры</span>
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </li>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                                            </ul>
                                        </div>
                                    </div>

                                </aside>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('index.layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>