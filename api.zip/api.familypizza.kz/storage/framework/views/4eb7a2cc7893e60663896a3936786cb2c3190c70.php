<?php $__env->startSection('content'); ?>

        <section class="content-header">
            <h1>
              <?php echo e($title); ?>

            </h1>
        </section>
        <section class="content">
            <div class="row">
                <div class="col-md-12">
                   <div class="col-md-8" style="padding-left: 0px">
                       <div class="box box-primary">
                           <?php if(isset($error)): ?>
                               <div class="alert alert-danger">
                                   <?php echo e($error); ?>

                               </div>
                           <?php endif; ?>
                           <?php if($row->vacancy_id > 0): ?>
                               <form action="/admin/vacancy/<?php echo e($row->vacancy_id); ?>" method="POST">
                                   <input type="hidden" name="_method" value="PUT">
                           <?php else: ?>
                               <form action="/admin/vacancy" method="POST">
                           <?php endif; ?>
                                   <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                   <input type="hidden" name="vacancy_id" value="<?php echo e($row->vacancy_id); ?>">

                                   <div class="box-body">
                                       <div class="form-group">
                                           <label>Работодатель</label>
                                           <select name="user_id" data-placeholder="Выберите" class="form-control selectpicker" data-live-search="true">

                                               <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                   <option <?if($row->user_id == $item->user_id) echo 'selected '; ?> value="<?php echo e($item->user_id); ?>"><?php echo e($item['user_name']); ?>  &nbsp &nbsp &nbsp <?php echo e(\App\Http\Helpers::getPhoneFormat($item['phone'])); ?></option>
                                               <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                                           </select>
                                       </div>
                                       <div class="form-group">
                                           <label>Кто требуется</label>
                                           <select name="speciality_id" data-placeholder="Выберите" class="form-control selectpicker" data-live-search="true">

                                               <?php $__currentLoopData = $speciality; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                   <option <?if($row->speciality_id == $item->speciality_id) echo 'selected '; ?> value="<?php echo e($item->speciality_id); ?>"><?php echo e($item['speciality_name_ru']); ?></option>
                                               <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                                           </select>
                                       </div>
                                       <div class="form-group">
                                           <label>Описание</label>
                                           <textarea name="vacancy_desc" class="form-control"><?=$row->vacancy_desc?></textarea>
                                       </div>
                                       <div class="form-group">
                                           <label>Количество рабочик мест</label>
                                           <input value="<?php echo e($row->work_count); ?>" type="number" class="form-control" name="work_count" placeholder="Введите">
                                       </div>
                                       <div class="form-group">
                                           <label>Промежуток времени</label>
                                           <select name="pay_duration" data-placeholder="Выберите" class="form-control">

                                               <option <?if($row->pay_duration == 'час') echo 'selected '; ?> value="час">час</option>
                                               <option <?if($row->pay_duration == 'неделя') echo 'selected '; ?> value="час">неделя</option>
                                               <option <?if($row->pay_duration == 'месяц') echo 'selected '; ?> value="в месяц">месяц</option>


                                           </select>
                                       </div>
                                       <div class="form-group">
                                           <label>Сумма в тенге</label>
                                           <input value="<?php echo e($row->salary); ?>" type="number" class="form-control" name="salary" placeholder="Введите">
                                       </div>
                                       <div class="form-group">
                                           <label>Адрес</label>
                                           <input value="<?php echo e($row->address); ?>" type="text" class="form-control" name="address" placeholder="Введите">
                                       </div>
                                       <div class="form-group">
                                           <label>Дата выполнения работы</label>
                                           <input value="<?php echo e($row->deadline); ?>" type="text" class="form-control datetimepicker-input" name="deadline" placeholder="Введите">
                                       </div>
                                   </div>
                                   <div class="box-footer">
                                       <button type="submit" class="btn btn-primary">Сохранить</button>
                                   </div>
                                </form>

                       </div>
                   </div>
                </div>
            </div>
        </section>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>