<?php $__env->startSection('content'); ?>

        <section class="content-header">
            <h1>
              <?php echo e($title); ?>

            </h1>
        </section>
        <section class="content">
            <div class="row">
                <div class="col-md-12">
                   <div class="col-md-8" style="padding-left: 0px">
                       <div class="box box-primary">
                               <div class="alert alert-danger" id="news_error" style="display: none">

                               </div>
                               <form id="news_form" method="POST">
                                   <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                   <input class="image-name" type="hidden" id="news_image" name="news_image" value="<?php echo e($row->news_image); ?>"/>
                                   <input type="hidden" id="news_id" name="news_id" value="<?php echo e($row->news_id); ?>"/>

                                   <div class="box-body">
                                       <div class="lang-item" id="lang_ru">
                                           <div class="form-group">
                                               <label>Заголовок </label>
                                               <input id="news_name_ru" value="<?php echo e($row->news_name_ru); ?>" type="text" class="form-control" name="news_name_ru" placeholder="Введите">
                                           </div>
                                           <div class="form-group">
                                               <label>Текст </label>
                                               <textarea id="news_text_ru" name="news_text" class="form-control text_editor"><?=$row->news_text_ru?></textarea>
                                           </div>
                                       </div>
                                       <div class="lang-item" id="lang_kz" >
                                           <div class="form-group">
                                               <label>Заголовок (Каз)</label>
                                               <input id="news_name_kz" value="<?php echo e($row->news_name_kz); ?>" type="text" class="form-control " name="news_name_kz" placeholder="Введите">
                                           </div>
                                           <div class="form-group">
                                               <label>Текст (Каз)</label>
                                               <textarea id="news_text_kz" name="news_text_kz" class="form-control text_editor"><?=$row->news_text_kz?></textarea>
                                           </div>
                                       </div>
                                    </div>
                                   <div class="box-footer">
                                       <a href="javascript:void(0)" onclick="saveNews()">
                                          <button type="button" class="btn btn-primary">Сохранить</button>
                                       </a>
                                   </div>
                               </form>
                           </div>
                   </div>
                   
                </div>
            </div>
        </section>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>