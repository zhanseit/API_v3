<?php $__env->startSection('content'); ?>

    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="container">
                    <h2 class="main-title"><?php echo e(Lang::get('app.login_to_cabinet')); ?></h2>

                    <div class="row">
                        <div class="col-md-6 col-sm-6 form-regis">
                            <span><?php echo e(Lang::get('app.phone')); ?></span>
                            <input class="phone-mask" type="text" id="login" placeholder="+7 (ХХХ) ХХХ-ХХ-ХХ" value="">
                            <span><?php echo e(Lang::get('app.password')); ?></span>
                            <input type="password" value="" id="password" class="login-input">
                            <input type="button" value="<?php echo e(Lang::get('app.sign_in')); ?>" onclick="loginAjax()">
                            <p class="text-center"><a href="/auth/reset-password"><?php echo e(Lang::get('app.forget_password')); ?></a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('index.layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>