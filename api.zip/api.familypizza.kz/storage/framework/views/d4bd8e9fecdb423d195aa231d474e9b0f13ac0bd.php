<?php $__env->startSection('content'); ?>

    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="container">
                    <h2 class="main-title"><?php echo e(Lang::get('app.edit_profile')); ?></h2>

                    <div class="row">

                        <?php if($user->is_company == 0): ?>

                            <div class="col-md-6 col-sm-6 form-regis">
                                <span><?php echo e(Lang::get('app.full_name')); ?></span>
                                <input type="text" value="<?php echo e($user->user_name); ?>" id="user_name">
                            </div>

                        <?php else: ?>

                            <div class="col-md-6 col-sm-6 form-regis">
                                <span><?php echo e(Lang::get('app.name_of_organization')); ?></span>
                                <input type="text" value="<?php echo e($user->user_name); ?>" id="user_name">
                            </div>

                        <?php endif; ?>

                        <div class="col-md-6 col-sm-6 form-regis">
                            <span><?php echo e(Lang::get('app.phone')); ?></span>
                            <input  class="phone-mask" type="text" value="<?php echo e(\App\Http\Helpers::getPhoneFormat($user->phone)); ?>" id="phone">
                        </div>

                        <div class="col-md-6 col-sm-6 form-regis">
                            <span><?php echo e(Lang::get('app.iin')); ?></span>
                            <input type="text" value="<?php echo e($user->inn); ?>" id="inn">
                        </div>

                        <?php if($user->role_id == 3): ?>

                            <div class="col-md-6 col-sm-6 form-regis">
                                <span><?php echo e(Lang::get('app.age')); ?></span>
                                <input type="text" value="<?php echo e($user->age); ?>" id="age">
                            </div>

                            <div class="col-md-6 col-sm-6 form-regis">
                                <span><?php echo e(Lang::get('app.work_type')); ?></span>
                                <select id="speciality_id" class="selectpicker" data-live-search="true">

                                    <?php $__currentLoopData = $speciality_row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

                                        <option <?php if($item->speciality_id == $user->speciality_id): ?> selected <?php endif; ?> value="<?php echo e($item->speciality_id); ?>"><?php echo e($item['speciality_name_'.$lang]); ?></option>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                                </select>
                            </div>

                        <?php else: ?>

                            <div class="col-md-6 col-sm-6 form-regis">
                                <span><?php echo e(Lang::get('app.work_type')); ?></span>
                                <input type="text" value="<?php echo e($user->work_type); ?>" id="work_type">
                            </div>

                        <?php endif; ?>

                        <div class="col-md-12 col-sm-12 form-regis">
                            <span><?php echo e(Lang::get('app.about_me')); ?>:</span>
                            <textarea id="user_desc"><?php echo e($user->user_desc); ?></textarea>
                        </div>

                        <div class="col-md-12">
                            <div class="row">
                                <div class="col-md-6 col-sm-6 form-regis">
                                    <input type="button" value="<?php echo e(Lang::get('app.save')); ?>" onclick="editProfile()">
                                </div>

                                <div class="col-md-6 col-sm-6 form-regis">
                                    <a href="/profile">
                                        <input type="button" class="btn-grey" value="<?php echo e(Lang::get('app.cancel')); ?>">
                                    </a>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('index.layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>