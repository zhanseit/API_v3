<?php $__env->startSection('content'); ?>

    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="container">
                    <div class="row">
                        <div class="col-md-offset-3 col-md-6 col-sm-6 form-regis">
                            <h2 class="main-title"><?php echo e(Lang::get('app.confirm_phone')); ?></h2>
                            <p class="phone-confirm"><?php echo e(Lang::get('app.code_have_send_your_phone')); ?>: <span><a href="#"><?php echo e(\App\Http\Helpers::getPhoneFormat($phone)); ?></a></span></p>
                            <span><?php echo e(Lang::get('app.code')); ?></span>
                            <input type="hidden" id="phone" value="<?php echo e(\App\Http\Helpers::getPhoneFormat($phone)); ?>">
                            <input type="text" value="" id="sms_code">
                            <input type="button" value="<?php echo e(Lang::get('app.confirm')); ?>" onclick="confirmPassword()">
                            <p id="send_sms_repeat"></p>
                            <p class="time-send"><?php echo e(Lang::get('app.you_may_send_code_after')); ?> <span>00:<span id="timer_inp">60</span></span></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<script src="/js/jquery-1.11.0.js"></script>
<script src="/js/bootstrap.min.js"></script>

<script>

    function timerSms() {
        var obj = parseInt($('#timer_inp').html());
        obj--;
        var num = '';
        if(obj < 10){
            num = '0';
        }
        $('#timer_inp').html(num + obj);
        if (obj == 0) {
            $('.time-send').css('display','none');
            $('#send_sms_repeat').html('<a href="javascript:void(0)" onclick="sendSmsRepeat()">Отправить код повторно</a>');
            setTimeout(function() {}, 1000);
        } else {
            setTimeout(timerSms, 1000);
        }
    }

    $(document).ready(function(){
        setTimeout(timerSms, 1000);
    });

</script>


<?php echo $__env->make('index.layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>