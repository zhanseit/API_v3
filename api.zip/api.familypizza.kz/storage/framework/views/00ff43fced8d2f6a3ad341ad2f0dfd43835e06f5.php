<?php $__env->startSection('content'); ?>

    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="container">
                    <h2 class="main-title">Поиск вакансий <?php echo e(isset($_GET['search'])?'"'.$_GET['search'].'"':''); ?>

                        <a data-toggle="modal" data-target="#modal-4" class="pull-right r-box-top hidden-xs">
                            <span>не нашли работу по своему профилю?</span>
                            <button class="btns-yellow">Искать другие вакансии</button></a></h2>
                    <table class="table table-responsive list-vacancy">
                        <tr>
                            <th>Вакансия</th>
                            <th>Дата работы</th>
                            <th>Оплата</th>
                        </tr>

                        <?php echo $__env->make('index.vacancy.vacancy-loop', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    </table>

                    <div style="text-align: center">
                        <?php echo e($vacancy_row->appends(\Illuminate\Support\Facades\Input::except('page'))->links()); ?>

                    </div>


                    <div class="text-center">
                        <a data-toggle="modal" data-target="#modal-4" class="in-top-span">
                            <span>не нашли работу по своему профилю?</span>
                            <button class="btns-yellow">Искать другие вакансии</button>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" tabindex="-1" id="modal-4" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <h4 class="modal-title">Выберите другую специальность для поиска работы</h4>
                    <div class="form-auth">
                        <select id="search_speciality_id"  class="selectpicker" data-live-search="true" onchange="getVacancyListBySearch()">

                            <option value="0">Все</option>
                            <?php $__currentLoopData = $speciality_row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

                                <option <?php if(isset($_GET['speciality_id']) && $item->speciality_id == $_GET['speciality_id']): ?> selected <?php endif; ?> value="<?php echo e($item->speciality_id); ?>"><?php echo e($item['speciality_name_'.$lang]); ?></option>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                        </select>
                        <button onclick="getVacancyListBySearch()" class="btn-blue" style="margin-top: 0">Искать</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('index.layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>