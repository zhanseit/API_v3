<header class="mkd-page-header">

    <?php echo $__env->make('index.layout.pre-header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="mkd-menu-area">
        <div class="mkd-grid">
            <div class="mkd-vertical-align-containers">
                <div class="mkd-position-left">
                    <div class="mkd-position-left-inner">
                        <nav class="mkd-main-menu mkd-drop-down mkd-default-nav">
                            <ul id="menu-main_menu" class="clearfix">
                                <li class="<?php if(isset($menu) && $menu == 'home'): ?>  mkd-active-item <?php endif; ?> menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-home current-menu-ancestor current-menu-parent menu-item-has-children  has_sub narrow">
                                    <a href="/">
                                        <span class="item_outer">
                                            <span class="item_inner">
                                                <span class="menu_icon_wrapper">
                                                    <i class="menu_icon null fa"></i>
                                                </span>
                                                <span class="item_text">Главная</span>
                                            </span>
                                            <span class="plus">
                                            </span>
                                        </span>
                                        <span class="bottom-border">
                                            <span class="bottom-border-inner"></span>
                                        </span>
                                    </a>
                                </li>
                                <li class="<?php if(isset($menu) && $menu == 'service'): ?>  mkd-active-item <?php endif; ?> menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow">
                                    <a href="#">
                                        <span class="item_outer">
                                            <span class="item_inner">
                                                <span class="menu_icon_wrapper">
                                                    <i class="menu_icon null fa"></i>
                                                </span>
                                                <span class="item_text">Услуги</span>
                                            </span>
                                            <span class="plus"></span>
                                        </span>
                                        <span class="bottom-border">
                                            <span class="bottom-border-inner"></span>
                                        </span>
                                    </a>
                                    <div class="second" style="height: 0px;">
                                        <div class="inner">
                                            <ul>
                                                <?$service = new \App\Models\Service(); $service = $service->getParentServiceList();?>

                                                <?php $__currentLoopData = $service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

                                                        <li id="nav-menu-item-513" class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                            <a href="<?php if($item->child_count > 0): ?><?php echo e("/services/"); ?><?php else: ?><?php echo e("/service/"); ?><?php endif; ?><?php echo e(\App\Http\Helpers::getTranslatedSlugRu($item->service_name_ru)."-u".$item->service_id); ?>" class="">
                                                                <span class="item_outer">
                                                                    <span class="item_inner">
                                                                        <span class="menu_icon_wrapper">
                                                                            <i class="menu_icon null fa"></i>
                                                                        </span>
                                                                        <span class="item_text"><?php echo e($item->service_name_ru); ?></span>
                                                                    </span>
                                                                    <span class="plus"></span>
                                                                </span>
                                                                <span class="bottom-border"><span class="bottom-border-inner"></span></span>
                                                            </a>
                                                        </li>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>;

                                            </ul>
                                        </div>
                                    </div>
                                </li>
                                <li class="<?php if(isset($menu) && $menu == 'price-list'): ?>  mkd-active-item <?php endif; ?> menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow">
                                    <a href="#" class=" <?php if(isset($menu) && $menu == 'price-list'): ?> current <?php endif; ?>">
                                        <span class="item_outer">
                                            <span class="item_inner">
                                                <span class="menu_icon_wrapper">
                                                    <i class="menu_icon null fa"></i>
                                                </span>
                                                <span class="item_text">Прайс-лист</span>
                                            </span>
                                            <span class="plus"></span>
                                        </span>
                                        <span class="bottom-border">
                                            <span class="bottom-border-inner"></span>
                                        </span>
                                    </a>
                                    <div class="second" style="height: 0px;">
                                        <div class="inner">
                                            <ul>
                                                <?php $__currentLoopData = $service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

                                                    <li id="nav-menu-item-513" class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                        <a href="/price-list/<?php echo e(\App\Http\Helpers::getTranslatedSlugRu($item->service_name_ru) ."-u".$item->service_id); ?>" class="">
                                                                <span class="item_outer">
                                                                    <span class="item_inner">
                                                                        <span class="menu_icon_wrapper">
                                                                            <i class="menu_icon null fa"></i>
                                                                        </span>
                                                                        <span class="item_text"><?php echo e($item->service_name_ru); ?></span>
                                                                    </span>
                                                                    <span class="plus"></span>
                                                                </span>
                                                            <span class="bottom-border"><span class="bottom-border-inner"></span></span>
                                                        </a>
                                                    </li>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>;
                                            </ul>
                                        </div>
                                    </div>
                                </li>
                                <li class="<?php if(isset($menu) && $menu == 'pay'): ?>  mkd-active-item <?php endif; ?> menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow">
                                    <a href="/pay" class=" <?php if(isset($menu) && $menu == 'pay'): ?> current <?php endif; ?>">
                                        <span class="item_outer">
                                            <span class="item_inner">
                                                <span class="menu_icon_wrapper">
                                                    <i class="menu_icon null fa"></i>
                                                </span>
                                                <span class="item_text">Способы оплаты</span>
                                            </span>
                                            <span class="plus"></span>
                                        </span>
                                        <span class="bottom-border">
                                            <span class="bottom-border-inner"></span>
                                        </span>
                                    </a>
                                </li>
                                <li class="<?php if(isset($menu) && $menu == 'blog'): ?>  mkd-active-item <?php endif; ?> menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow">
                                    <a href="/blog" class=" <?php if(isset($menu) && $menu == 'blog'): ?> current <?php endif; ?>">
                                        <span class="item_outer">
                                            <span class="item_inner">
                                                <span class="menu_icon_wrapper">
                                                    <i class="menu_icon null fa"></i>
                                                </span>
                                                <span class="item_text">Полезные статьи</span>
                                            </span>
                                            <span class="plus"></span>
                                        </span>
                                        <span class="bottom-border">
                                            <span class="bottom-border-inner"></span>
                                        </span>
                                    </a>
                                </li>
                                <li class="<?php if(isset($menu) && $menu == 'contact'): ?>  mkd-active-item <?php endif; ?> menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow">
                                    <a href="/contact" class=" <?php if(isset($menu) && $menu == 'contact'): ?> current <?php endif; ?>">
                                        <span class="item_outer">
                                            <span class="item_inner">
                                                <span class="menu_icon_wrapper">
                                                    <i class="menu_icon null fa"></i>
                                                </span>
                                                <span class="item_text">Контакты</span>
                                            </span>
                                            <span class="plus"></span>
                                        </span>
                                        <span class="bottom-border">
                                            <span class="bottom-border-inner"></span>
                                        </span>
                                    </a>
                                </li>
                            </ul>
                                <span class="mkd-item-hover" style="width: 78px; left: 219.217px; opacity: 0;"></span>
                        </nav>

                    </div>
                </div>
                <div class="mkd-position-right">
                    <div class="mkd-position-right-inner">
                        <div id="text-20" class="widget widget_text mkd-right-from-main-menu-widget">
                            <div class="textwidget"><a
                                        href="http://libero.mikado-themes.com/contact-with-google-map/"
                                        target="_self" style="font-weight: 900"
                                        class="mkd-btn mkd-btn-medium mkd-btn-solid mkd-btn-icon">
                                    <span class="mkd-btn-text">Напишите нам</span><span
                                            class="mkd-btn-icon-holder">
            <span aria-hidden="true" class="mkd-icon-font-elegant arrow_carrot-right mkd-btn-icon-elem"></span>            <span
                                                aria-hidden="true"
                                                class="mkd-icon-font-elegant arrow_carrot-right mkd-btn-icon-elem"></span>        </span>
                                </a></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="mkd-sticky-header">
        <div class="mkd-sticky-holder">
            <div class="mkd-grid">
                <div class=" mkd-vertical-align-containers">
                    <div class="mkd-position-left">
                        <div class="mkd-position-left-inner">

                            <div class="mkd-logo-wrapper">
                                <a href="http://libero.mikado-themes.com/" style="height: 60px;">
                                    <img src="/image/logo-sticky.png"
                                         alt="logo">
                                </a>
                            </div>


                            <nav class="mkd-main-menu mkd-drop-down mkd-sticky-nav">
                                <ul id="menu-main_menu-1" class="clearfix">
                                    <li id="sticky-nav-menu-item-496"
                                        class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-home current-menu-ancestor current-menu-parent menu-item-has-children mkd-active-item has_sub narrow">
                                        <a href="http://libero.mikado-themes.com/" class=" current "><span
                                                    class="item_outer"><span class="item_inner"><span
                                                            class="menu_icon_wrapper"><i
                                                                class="menu_icon null fa"></i></span><span
                                                            class="item_text">Homepages</span></span><span
                                                        class="plus"></span></span><span
                                                    class="bottom-border"><span
                                                        class="bottom-border-inner"></span></span></a>
                                        <div class="second" style="height: 0px;">
                                            <div class="inner">
                                                <ul>
                                                    <li id="sticky-nav-menu-item-498"
                                                        class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-388 current_page_item ">
                                                        <a href="http://libero.mikado-themes.com/"
                                                           class=""><span class="item_outer"><span
                                                                        class="item_inner"><span
                                                                            class="menu_icon_wrapper"><i
                                                                                class="menu_icon icon-home fa"></i></span><span
                                                                            class="item_text">Home 1</span></span><span
                                                                        class="plus"></span></span><span
                                                                    class="bottom-border"><span
                                                                        class="bottom-border-inner"></span></span></a>
                                                    </li>
                                                    <li id="sticky-nav-menu-item-2462"
                                                        class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                        <a href="http://libero.mikado-themes.com/home-2/"
                                                           class=""><span class="item_outer"><span
                                                                        class="item_inner"><span
                                                                            class="menu_icon_wrapper"><i
                                                                                class="menu_icon icon-anchor fa"></i></span><span
                                                                            class="item_text">Home 2</span></span><span
                                                                        class="plus"></span></span><span
                                                                    class="bottom-border"><span
                                                                        class="bottom-border-inner"></span></span></a>
                                                    </li>
                                                    <li id="sticky-nav-menu-item-2463"
                                                        class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                        <a href="http://libero.mikado-themes.com/home-3/"
                                                           class=""><span class="item_outer"><span
                                                                        class="item_inner"><span
                                                                            class="menu_icon_wrapper"><i
                                                                                class="menu_icon icon-badge fa"></i></span><span
                                                                            class="item_text">Home 3</span></span><span
                                                                        class="plus"></span></span><span
                                                                    class="bottom-border"><span
                                                                        class="bottom-border-inner"></span></span></a>
                                                    </li>
                                                    <li id="sticky-nav-menu-item-2464"
                                                        class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                        <a href="http://libero.mikado-themes.com/home-4/"
                                                           class=""><span class="item_outer"><span
                                                                        class="item_inner"><span
                                                                            class="menu_icon_wrapper"><i
                                                                                class="menu_icon icon-bell fa"></i></span><span
                                                                            class="item_text">Home 4</span></span><span
                                                                        class="plus"></span></span><span
                                                                    class="bottom-border"><span
                                                                        class="bottom-border-inner"></span></span></a>
                                                    </li>
                                                    <li id="sticky-nav-menu-item-2465"
                                                        class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                        <a href="http://libero.mikado-themes.com/home-5/"
                                                           class=""><span class="item_outer"><span
                                                                        class="item_inner"><span
                                                                            class="menu_icon_wrapper"><i
                                                                                class="menu_icon icon-flag fa"></i></span><span
                                                                            class="item_text">Home 5</span></span><span
                                                                        class="plus"></span></span><span
                                                                    class="bottom-border"><span
                                                                        class="bottom-border-inner"></span></span></a>
                                                    </li>
                                                    <li id="sticky-nav-menu-item-2455"
                                                        class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                        <a href="http://libero.mikado-themes.com/home-6/"
                                                           class=""><span class="item_outer"><span
                                                                        class="item_inner"><span
                                                                            class="menu_icon_wrapper"><i
                                                                                class="menu_icon icon-diamond fa"></i></span><span
                                                                            class="item_text">Home 6</span></span><span
                                                                        class="plus"></span></span><span
                                                                    class="bottom-border"><span
                                                                        class="bottom-border-inner"></span></span></a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </li>
                                    <li id="sticky-nav-menu-item-604"
                                        class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub wide">
                                        <a href="http://libero.mikado-themes.com/about-our-company/"
                                           class=""><span class="item_outer"><span class="item_inner"><span
                                                            class="menu_icon_wrapper"><i
                                                                class="menu_icon null fa"></i></span><span
                                                            class="item_text">Pages</span></span><span
                                                        class="plus"></span></span><span
                                                    class="bottom-border"><span
                                                        class="bottom-border-inner"></span></span></a>
                                        <div class="second background_image" style="left: 0px; height: 0px;">
                                            <div class="inner">
                                                <ul style="background-image:url(http://libero.mikado-themes.com/wp-content/uploads/2015/11/menu-image.jpg); background-size: cover; background-repeat: no-repeat; background-position: center;">
                                                    <li id="sticky-nav-menu-item-1059"
                                                        class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"
                                                        style="height: 289px;"><a href="#" class=" no_link"
                                                                                  style="cursor: default;"
                                                                                  onclick="JavaScript: return false;"><span
                                                                    class="item_outer"><span class="item_inner"><span
                                                                            class="menu_icon_wrapper"><i
                                                                                class="menu_icon null fa"></i></span><span
                                                                            class="item_text">Featured</span></span><span
                                                                        class="plus"></span><i
                                                                        class="q_menu_arrow fa fa-angle-right"></i></span><span
                                                                    class="bottom-border"><span
                                                                        class="bottom-border-inner"></span></span></a>
                                                        <ul>
                                                            <li id="sticky-nav-menu-item-813"
                                                                class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                                <a href="http://libero.mikado-themes.com/about-our-company/"
                                                                   class=""><span class="item_outer"><span
                                                                                class="item_inner"><span
                                                                                    class="menu_icon_wrapper"><i
                                                                                        class="menu_icon icon-home fa"></i></span><span
                                                                                    class="item_text">About Our Company</span></span><span
                                                                                class="plus"></span></span><span
                                                                            class="bottom-border"><span
                                                                                class="bottom-border-inner"></span></span></a>
                                                            </li>
                                                            <li id="sticky-nav-menu-item-918"
                                                                class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                                <a href="http://libero.mikado-themes.com/facts/"
                                                                   class=""><span class="item_outer"><span
                                                                                class="item_inner"><span
                                                                                    class="menu_icon_wrapper"><i
                                                                                        class="menu_icon icon-folder fa"></i></span><span
                                                                                    class="item_text">Facts</span></span><span
                                                                                class="plus"></span></span><span
                                                                            class="bottom-border"><span
                                                                                class="bottom-border-inner"></span></span></a>
                                                            </li>
                                                            <li id="sticky-nav-menu-item-1042"
                                                                class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                                <a href="http://libero.mikado-themes.com/our-team-of-lawyers/"
                                                                   class=""><span class="item_outer"><span
                                                                                class="item_inner"><span
                                                                                    class="menu_icon_wrapper"><i
                                                                                        class="menu_icon icon-graduation fa"></i></span><span
                                                                                    class="item_text">Our Team of Lawyers</span></span><span
                                                                                class="plus"></span></span><span
                                                                            class="bottom-border"><span
                                                                                class="bottom-border-inner"></span></span></a>
                                                            </li>
                                                            <li id="sticky-nav-menu-item-1043"
                                                                class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                                <a href="http://libero.mikado-themes.com/our-services/"
                                                                   class=""><span class="item_outer"><span
                                                                                class="item_inner"><span
                                                                                    class="menu_icon_wrapper"><i
                                                                                        class="menu_icon icon-wrench fa"></i></span><span
                                                                                    class="item_text">Our Services</span></span><span
                                                                                class="plus"></span></span><span
                                                                            class="bottom-border"><span
                                                                                class="bottom-border-inner"></span></span></a>
                                                            </li>
                                                            <li id="sticky-nav-menu-item-831"
                                                                class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                                <a href="http://libero.mikado-themes.com/company-history/"
                                                                   class=""><span class="item_outer"><span
                                                                                class="item_inner"><span
                                                                                    class="menu_icon_wrapper"><i
                                                                                        class="menu_icon icon-compass fa"></i></span><span
                                                                                    class="item_text">Company History</span></span><span
                                                                                class="plus"></span></span><span
                                                                            class="bottom-border"><span
                                                                                class="bottom-border-inner"></span></span></a>
                                                            </li>
                                                            <li id="sticky-nav-menu-item-1010"
                                                                class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                                <a href="http://libero.mikado-themes.com/media-center/"
                                                                   class=""><span class="item_outer"><span
                                                                                class="item_inner"><span
                                                                                    class="menu_icon_wrapper"><i
                                                                                        class="menu_icon icon-earphones-alt fa"></i></span><span
                                                                                    class="item_text">Media Center</span></span><span
                                                                                class="plus"></span></span><span
                                                                            class="bottom-border"><span
                                                                                class="bottom-border-inner"></span></span></a>
                                                            </li>
                                                        </ul>
                                                    </li>
                                                    <li id="sticky-nav-menu-item-1060"
                                                        class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"
                                                        style="height: 289px;"><a href="#" class=" no_link"
                                                                                  style="cursor: default;"
                                                                                  onclick="JavaScript: return false;"><span
                                                                    class="item_outer"><span class="item_inner"><span
                                                                            class="menu_icon_wrapper"><i
                                                                                class="menu_icon null fa"></i></span><span
                                                                            class="item_text">Standard</span></span><span
                                                                        class="plus"></span><i
                                                                        class="q_menu_arrow fa fa-angle-right"></i></span><span
                                                                    class="bottom-border"><span
                                                                        class="bottom-border-inner"></span></span></a>
                                                        <ul>
                                                            <li id="sticky-nav-menu-item-807"
                                                                class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                                <a href="http://libero.mikado-themes.com/coming-soon-page/"
                                                                   class=""><span class="item_outer"><span
                                                                                class="item_inner"><span
                                                                                    class="menu_icon_wrapper"><i
                                                                                        class="menu_icon icon-clock fa"></i></span><span
                                                                                    class="item_text">Coming Soon Page</span></span><span
                                                                                class="plus"></span></span><span
                                                                            class="bottom-border"><span
                                                                                class="bottom-border-inner"></span></span></a>
                                                            </li>
                                                            <li id="sticky-nav-menu-item-991"
                                                                class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                                <a href="http://libero.mikado-themes.com/maintenance-page/"
                                                                   class=""><span class="item_outer"><span
                                                                                class="item_inner"><span
                                                                                    class="menu_icon_wrapper"><i
                                                                                        class="menu_icon icon-fire fa"></i></span><span
                                                                                    class="item_text">Maintenance Page</span></span><span
                                                                                class="plus"></span></span><span
                                                                            class="bottom-border"><span
                                                                                class="bottom-border-inner"></span></span></a>
                                                            </li>
                                                            <li id="sticky-nav-menu-item-1011"
                                                                class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                                <a href="http://libero.mikado-themes.com/our-clients/"
                                                                   class=""><span class="item_outer"><span
                                                                                class="item_inner"><span
                                                                                    class="menu_icon_wrapper"><i
                                                                                        class="menu_icon icon-wallet fa"></i></span><span
                                                                                    class="item_text">Our Clients</span></span><span
                                                                                class="plus"></span></span><span
                                                                            class="bottom-border"><span
                                                                                class="bottom-border-inner"></span></span></a>
                                                            </li>
                                                            <li id="sticky-nav-menu-item-812"
                                                                class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                                <a href="http://libero.mikado-themes.com/areas-of-expertise/"
                                                                   class=""><span class="item_outer"><span
                                                                                class="item_inner"><span
                                                                                    class="menu_icon_wrapper"><i
                                                                                        class="menu_icon icon-diamond fa"></i></span><span
                                                                                    class="item_text">Areas of Expertise</span></span><span
                                                                                class="plus"></span></span><span
                                                                            class="bottom-border"><span
                                                                                class="bottom-border-inner"></span></span></a>
                                                            </li>
                                                            <li id="sticky-nav-menu-item-1482"
                                                                class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                                <a href="http://libero.mikado-themes.com/contact-with-google-map/"
                                                                   class=""><span class="item_outer"><span
                                                                                class="item_inner"><span
                                                                                    class="menu_icon_wrapper"><i
                                                                                        class="menu_icon icon-pin fa"></i></span><span
                                                                                    class="item_text">Contact</span></span><span
                                                                                class="plus"></span></span><span
                                                                            class="bottom-border"><span
                                                                                class="bottom-border-inner"></span></span></a>
                                                            </li>
                                                            <li id="sticky-nav-menu-item-602"
                                                                class="menu-item menu-item-type-custom menu-item-object-custom ">
                                                                <a href="http://libero.mikado-themes.com/missing-page"
                                                                   class=""><span class="item_outer"><span
                                                                                class="item_inner"><span
                                                                                    class="menu_icon_wrapper"><i
                                                                                        class="menu_icon icon-dislike fa"></i></span><span
                                                                                    class="item_text">404 Page</span></span><span
                                                                                class="plus"></span></span><span
                                                                            class="bottom-border"><span
                                                                                class="bottom-border-inner"></span></span></a>
                                                            </li>
                                                        </ul>
                                                    </li>
                                                    <li id="sticky-nav-menu-item-1061"
                                                        class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"
                                                        style="height: 289px;"><a href="#" class=" no_link"
                                                                                  style="cursor: default;"
                                                                                  onclick="JavaScript: return false;"><span
                                                                    class="item_outer"><span class="item_inner"><span
                                                                            class="menu_icon_wrapper"><i
                                                                                class="menu_icon null fa"></i></span><span
                                                                            class="item_text">Additional</span></span><span
                                                                        class="plus"></span><i
                                                                        class="q_menu_arrow fa fa-angle-right"></i></span><span
                                                                    class="bottom-border"><span
                                                                        class="bottom-border-inner"></span></span></a>
                                                        <ul>
                                                            <li id="sticky-nav-menu-item-808"
                                                                class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                                <a href="http://libero.mikado-themes.com/client-testimonials/"
                                                                   class=""><span class="item_outer"><span
                                                                                class="item_inner"><span
                                                                                    class="menu_icon_wrapper"><i
                                                                                        class="menu_icon icon-microphone fa"></i></span><span
                                                                                    class="item_text">Client Testimonials</span></span><span
                                                                                class="plus"></span></span><span
                                                                            class="bottom-border"><span
                                                                                class="bottom-border-inner"></span></span></a>
                                                            </li>
                                                            <li id="sticky-nav-menu-item-810"
                                                                class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                                <a href="http://libero.mikado-themes.com/considering-divorce/"
                                                                   class=""><span class="item_outer"><span
                                                                                class="item_inner"><span
                                                                                    class="menu_icon_wrapper"><i
                                                                                        class="menu_icon icon-shield fa"></i></span><span
                                                                                    class="item_text">Considering Divorce</span></span><span
                                                                                class="plus"></span></span><span
                                                                            class="bottom-border"><span
                                                                                class="bottom-border-inner"></span></span></a>
                                                            </li>
                                                            <li id="sticky-nav-menu-item-917"
                                                                class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                                <a href="http://libero.mikado-themes.com/faq/"
                                                                   class=""><span class="item_outer"><span
                                                                                class="item_inner"><span
                                                                                    class="menu_icon_wrapper"><i
                                                                                        class="menu_icon icon-umbrella fa"></i></span><span
                                                                                    class="item_text">FAQ</span></span><span
                                                                                class="plus"></span></span><span
                                                                            class="bottom-border"><span
                                                                                class="bottom-border-inner"></span></span></a>
                                                            </li>
                                                            <li id="sticky-nav-menu-item-811"
                                                                class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                                <a href="http://libero.mikado-themes.com/avoiding-bail/"
                                                                   class=""><span class="item_outer"><span
                                                                                class="item_inner"><span
                                                                                    class="menu_icon_wrapper"><i
                                                                                        class="menu_icon icon-key fa"></i></span><span
                                                                                    class="item_text">Avoiding Bail</span></span><span
                                                                                class="plus"></span></span><span
                                                                            class="bottom-border"><span
                                                                                class="bottom-border-inner"></span></span></a>
                                                            </li>
                                                            <li id="sticky-nav-menu-item-809"
                                                                class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                                <a href="http://libero.mikado-themes.com/car-accident-injuries/"
                                                                   class=""><span class="item_outer"><span
                                                                                class="item_inner"><span
                                                                                    class="menu_icon_wrapper"><i
                                                                                        class="menu_icon icon-ghost fa"></i></span><span
                                                                                    class="item_text">Car Accident Injuries</span></span><span
                                                                                class="plus"></span></span><span
                                                                            class="bottom-border"><span
                                                                                class="bottom-border-inner"></span></span></a>
                                                            </li>
                                                            <li id="sticky-nav-menu-item-990"
                                                                class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                                <a href="http://libero.mikado-themes.com/fraud-claims/"
                                                                   class=""><span class="item_outer"><span
                                                                                class="item_inner"><span
                                                                                    class="menu_icon_wrapper"><i
                                                                                        class="menu_icon icon-info fa"></i></span><span
                                                                                    class="item_text">Fraud Claims</span></span><span
                                                                                class="plus"></span></span><span
                                                                            class="bottom-border"><span
                                                                                class="bottom-border-inner"></span></span></a>
                                                            </li>
                                                        </ul>
                                                    </li>
                                                    <li id="sticky-nav-menu-item-1704"
                                                        class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"
                                                        style="height: 289px;"><a href="#" class=""><span
                                                                    class="item_outer"><span class="item_inner"><span
                                                                            class="menu_icon_wrapper"><i
                                                                                class="menu_icon null fa"></i></span><span
                                                                            class="item_text">Title Variations</span></span><span
                                                                        class="plus"></span><i
                                                                        class="q_menu_arrow fa fa-angle-right"></i></span><span
                                                                    class="bottom-border"><span
                                                                        class="bottom-border-inner"></span></span></a>
                                                        <ul>
                                                            <li id="sticky-nav-menu-item-1703"
                                                                class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                                <a href="http://libero.mikado-themes.com/theme-default-title/"
                                                                   class=""><span class="item_outer"><span
                                                                                class="item_inner"><span
                                                                                    class="menu_icon_wrapper"><i
                                                                                        class="menu_icon icon-trophy fa"></i></span><span
                                                                                    class="item_text">Theme Default</span></span><span
                                                                                class="plus"></span></span><span
                                                                            class="bottom-border"><span
                                                                                class="bottom-border-inner"></span></span></a>
                                                            </li>
                                                            <li id="sticky-nav-menu-item-1701"
                                                                class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                                <a href="http://libero.mikado-themes.com/title-with-icon/"
                                                                   class=""><span class="item_outer"><span
                                                                                class="item_inner"><span
                                                                                    class="menu_icon_wrapper"><i
                                                                                        class="menu_icon icon-tag fa"></i></span><span
                                                                                    class="item_text">Parallax With Icon</span></span><span
                                                                                class="plus"></span></span><span
                                                                            class="bottom-border"><span
                                                                                class="bottom-border-inner"></span></span></a>
                                                            </li>
                                                            <li id="sticky-nav-menu-item-1702"
                                                                class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                                <a href="http://libero.mikado-themes.com/responsive-image-title/"
                                                                   class=""><span class="item_outer"><span
                                                                                class="item_inner"><span
                                                                                    class="menu_icon_wrapper"><i
                                                                                        class="menu_icon icon-notebook fa"></i></span><span
                                                                                    class="item_text">Responsive Image</span></span><span
                                                                                class="plus"></span></span><span
                                                                            class="bottom-border"><span
                                                                                class="bottom-border-inner"></span></span></a>
                                                            </li>
                                                            <li id="sticky-nav-menu-item-1700"
                                                                class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                                <a href="http://libero.mikado-themes.com/monocolored-title/"
                                                                   class=""><span class="item_outer"><span
                                                                                class="item_inner"><span
                                                                                    class="menu_icon_wrapper"><i
                                                                                        class="menu_icon icon-shield fa"></i></span><span
                                                                                    class="item_text">Monocolored</span></span><span
                                                                                class="plus"></span></span><span
                                                                            class="bottom-border"><span
                                                                                class="bottom-border-inner"></span></span></a>
                                                            </li>
                                                        </ul>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </li>
                                    <li id="sticky-nav-menu-item-1679"
                                        class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub wide">
                                        <a href="http://libero.mikado-themes.com/free-and-premium-sliders/"
                                           class=""><span class="item_outer"><span class="item_inner"><span
                                                            class="menu_icon_wrapper"><i
                                                                class="menu_icon null fa"></i></span><span
                                                            class="item_text">Elements</span></span><span
                                                        class="plus"></span></span><span
                                                    class="bottom-border"><span
                                                        class="bottom-border-inner"></span></span></a>
                                        <div class="second background_image" style="left: 0px; height: 0px;">
                                            <div class="inner">
                                                <ul style="background-image:url(http://libero.mikado-themes.com/wp-content/uploads/2015/11/menu-image.jpg); background-size: cover; background-repeat: no-repeat; background-position: center;">
                                                    <li id="sticky-nav-menu-item-1798"
                                                        class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"
                                                        style="height: 254px;"><a href="#" class=" no_link"
                                                                                  style="cursor: default;"
                                                                                  onclick="JavaScript: return false;"><span
                                                                    class="item_outer"><span class="item_inner"><span
                                                                            class="menu_icon_wrapper"><i
                                                                                class="menu_icon null fa"></i></span><span
                                                                            class="item_text">Specials</span></span><span
                                                                        class="plus"></span><i
                                                                        class="q_menu_arrow fa fa-angle-right"></i></span><span
                                                                    class="bottom-border"><span
                                                                        class="bottom-border-inner"></span></span></a>
                                                        <ul>
                                                            <li id="sticky-nav-menu-item-1690"
                                                                class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                                <a href="http://libero.mikado-themes.com/free-and-premium-sliders/"
                                                                   class=""><span class="item_outer"><span
                                                                                class="item_inner"><span
                                                                                    class="menu_icon_wrapper"><i
                                                                                        class="menu_icon icon-diamond fa"></i></span><span
                                                                                    class="item_text">Premium Sliders</span></span><span
                                                                                class="plus"></span></span><span
                                                                            class="bottom-border"><span
                                                                                class="bottom-border-inner"></span></span></a>
                                                            </li>
                                                            <li id="sticky-nav-menu-item-1685"
                                                                class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                                <a href="http://libero.mikado-themes.com/our-team/"
                                                                   class=""><span class="item_outer"><span
                                                                                class="item_inner"><span
                                                                                    class="menu_icon_wrapper"><i
                                                                                        class="menu_icon icon-people fa"></i></span><span
                                                                                    class="item_text">Our Team</span></span><span
                                                                                class="plus"></span></span><span
                                                                            class="bottom-border"><span
                                                                                class="bottom-border-inner"></span></span></a>
                                                            </li>
                                                            <li id="sticky-nav-menu-item-1681"
                                                                class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                                <a href="http://libero.mikado-themes.com/video-combinations/"
                                                                   class=""><span class="item_outer"><span
                                                                                class="item_inner"><span
                                                                                    class="menu_icon_wrapper"><i
                                                                                        class="menu_icon icon-social-youtube fa"></i></span><span
                                                                                    class="item_text">Video Combinations</span></span><span
                                                                                class="plus"></span></span><span
                                                                            class="bottom-border"><span
                                                                                class="bottom-border-inner"></span></span></a>
                                                            </li>
                                                            <li id="sticky-nav-menu-item-1684"
                                                                class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                                <a href="http://libero.mikado-themes.com/interactive-banners/"
                                                                   class=""><span class="item_outer"><span
                                                                                class="item_inner"><span
                                                                                    class="menu_icon_wrapper"><i
                                                                                        class="menu_icon icon-bell fa"></i></span><span
                                                                                    class="item_text">Interactive Banners</span></span><span
                                                                                class="plus"></span></span><span
                                                                            class="bottom-border"><span
                                                                                class="bottom-border-inner"></span></span></a>
                                                            </li>
                                                            <li id="sticky-nav-menu-item-1686"
                                                                class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                                <a href="http://libero.mikado-themes.com/parallax-sections/"
                                                                   class=""><span class="item_outer"><span
                                                                                class="item_inner"><span
                                                                                    class="menu_icon_wrapper"><i
                                                                                        class="menu_icon icon-picture fa"></i></span><span
                                                                                    class="item_text">Parallax Sections</span></span><span
                                                                                class="plus"></span></span><span
                                                                            class="bottom-border"><span
                                                                                class="bottom-border-inner"></span></span></a>
                                                            </li>
                                                        </ul>
                                                    </li>
                                                    <li id="sticky-nav-menu-item-1832"
                                                        class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"
                                                        style="height: 254px;"><a href="#" class=""><span
                                                                    class="item_outer"><span class="item_inner"><span
                                                                            class="menu_icon_wrapper"><i
                                                                                class="menu_icon null fa"></i></span><span
                                                                            class="item_text">Interactive</span></span><span
                                                                        class="plus"></span><i
                                                                        class="q_menu_arrow fa fa-angle-right"></i></span><span
                                                                    class="bottom-border"><span
                                                                        class="bottom-border-inner"></span></span></a>
                                                        <ul>
                                                            <li id="sticky-nav-menu-item-1829"
                                                                class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                                <a href="http://libero.mikado-themes.com/interactive-icons/"
                                                                   class=""><span class="item_outer"><span
                                                                                class="item_inner"><span
                                                                                    class="menu_icon_wrapper"><i
                                                                                        class="menu_icon icon-badge fa"></i></span><span
                                                                                    class="item_text">Interactive Icons</span></span><span
                                                                                class="plus"></span></span><span
                                                                            class="bottom-border"><span
                                                                                class="bottom-border-inner"></span></span></a>
                                                            </li>
                                                            <li id="sticky-nav-menu-item-2031"
                                                                class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                                <a href="http://libero.mikado-themes.com/icon-with-text/"
                                                                   class=""><span class="item_outer"><span
                                                                                class="item_inner"><span
                                                                                    class="menu_icon_wrapper"><i
                                                                                        class="menu_icon icon-bulb fa"></i></span><span
                                                                                    class="item_text">Icon With Text</span></span><span
                                                                                class="plus"></span></span><span
                                                                            class="bottom-border"><span
                                                                                class="bottom-border-inner"></span></span></a>
                                                            </li>
                                                            <li id="sticky-nav-menu-item-1830"
                                                                class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                                <a href="http://libero.mikado-themes.com/image-with-text/"
                                                                   class=""><span class="item_outer"><span
                                                                                class="item_inner"><span
                                                                                    class="menu_icon_wrapper"><i
                                                                                        class="menu_icon icon-doc fa"></i></span><span
                                                                                    class="item_text">Image with Text</span></span><span
                                                                                class="plus"></span></span><span
                                                                            class="bottom-border"><span
                                                                                class="bottom-border-inner"></span></span></a>
                                                            </li>
                                                            <li id="sticky-nav-menu-item-2033"
                                                                class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                                <a href="http://libero.mikado-themes.com/image-gallery/"
                                                                   class=""><span class="item_outer"><span
                                                                                class="item_inner"><span
                                                                                    class="menu_icon_wrapper"><i
                                                                                        class="menu_icon icon-layers fa"></i></span><span
                                                                                    class="item_text">Image Gallery</span></span><span
                                                                                class="plus"></span></span><span
                                                                            class="bottom-border"><span
                                                                                class="bottom-border-inner"></span></span></a>
                                                            </li>
                                                            <li id="sticky-nav-menu-item-1689"
                                                                class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                                <a href="http://libero.mikado-themes.com/interactive-image/"
                                                                   class=""><span class="item_outer"><span
                                                                                class="item_inner"><span
                                                                                    class="menu_icon_wrapper"><i
                                                                                        class="menu_icon icon-check fa"></i></span><span
                                                                                    class="item_text">Interactive Image</span></span><span
                                                                                class="plus"></span></span><span
                                                                            class="bottom-border"><span
                                                                                class="bottom-border-inner"></span></span></a>
                                                            </li>
                                                        </ul>
                                                    </li>
                                                    <li id="sticky-nav-menu-item-1797"
                                                        class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"
                                                        style="height: 254px;"><a href="#" class=" no_link"
                                                                                  style="cursor: default;"
                                                                                  onclick="JavaScript: return false;"><span
                                                                    class="item_outer"><span class="item_inner"><span
                                                                            class="menu_icon_wrapper"><i
                                                                                class="menu_icon null fa"></i></span><span
                                                                            class="item_text">Standard</span></span><span
                                                                        class="plus"></span><i
                                                                        class="q_menu_arrow fa fa-angle-right"></i></span><span
                                                                    class="bottom-border"><span
                                                                        class="bottom-border-inner"></span></span></a>
                                                        <ul>
                                                            <li id="sticky-nav-menu-item-1682"
                                                                class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                                <a href="http://libero.mikado-themes.com/social-icons/"
                                                                   class=""><span class="item_outer"><span
                                                                                class="item_inner"><span
                                                                                    class="menu_icon_wrapper"><i
                                                                                        class="menu_icon icon-user-female fa"></i></span><span
                                                                                    class="item_text">Social Icons</span></span><span
                                                                                class="plus"></span></span><span
                                                                            class="bottom-border"><span
                                                                                class="bottom-border-inner"></span></span></a>
                                                            </li>
                                                            <li id="sticky-nav-menu-item-1831"
                                                                class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                                <a href="http://libero.mikado-themes.com/latest-posts/"
                                                                   class=""><span class="item_outer"><span
                                                                                class="item_inner"><span
                                                                                    class="menu_icon_wrapper"><i
                                                                                        class="menu_icon icon-eyeglass fa"></i></span><span
                                                                                    class="item_text">Latest Posts</span></span><span
                                                                                class="plus"></span></span><span
                                                                            class="bottom-border"><span
                                                                                class="bottom-border-inner"></span></span></a>
                                                            </li>
                                                            <li id="sticky-nav-menu-item-2035"
                                                                class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                                <a href="http://libero.mikado-themes.com/buttons/"
                                                                   class=""><span class="item_outer"><span
                                                                                class="item_inner"><span
                                                                                    class="menu_icon_wrapper"><i
                                                                                        class="menu_icon icon-flag fa"></i></span><span
                                                                                    class="item_text">Buttons</span></span><span
                                                                                class="plus"></span></span><span
                                                                            class="bottom-border"><span
                                                                                class="bottom-border-inner"></span></span></a>
                                                            </li>
                                                            <li id="sticky-nav-menu-item-2032"
                                                                class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                                <a href="http://libero.mikado-themes.com/separators/"
                                                                   class=""><span class="item_outer"><span
                                                                                class="item_inner"><span
                                                                                    class="menu_icon_wrapper"><i
                                                                                        class="menu_icon icon-wrench fa"></i></span><span
                                                                                    class="item_text">Separators</span></span><span
                                                                                class="plus"></span></span><span
                                                                            class="bottom-border"><span
                                                                                class="bottom-border-inner"></span></span></a>
                                                            </li>
                                                            <li id="sticky-nav-menu-item-1688"
                                                                class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                                <a href="http://libero.mikado-themes.com/clients-slider/"
                                                                   class=""><span class="item_outer"><span
                                                                                class="item_inner"><span
                                                                                    class="menu_icon_wrapper"><i
                                                                                        class="menu_icon icon-home fa"></i></span><span
                                                                                    class="item_text">Clients Slider</span></span><span
                                                                                class="plus"></span></span><span
                                                                            class="bottom-border"><span
                                                                                class="bottom-border-inner"></span></span></a>
                                                            </li>
                                                        </ul>
                                                    </li>
                                                    <li id="sticky-nav-menu-item-1833"
                                                        class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"
                                                        style="height: 254px;"><a href="#" class=""><span
                                                                    class="item_outer"><span class="item_inner"><span
                                                                            class="menu_icon_wrapper"><i
                                                                                class="menu_icon null fa"></i></span><span
                                                                            class="item_text">Infographic</span></span><span
                                                                        class="plus"></span><i
                                                                        class="q_menu_arrow fa fa-angle-right"></i></span><span
                                                                    class="bottom-border"><span
                                                                        class="bottom-border-inner"></span></span></a>
                                                        <ul>
                                                            <li id="sticky-nav-menu-item-1693"
                                                                class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                                <a href="http://libero.mikado-themes.com/accordions-and-toggles/"
                                                                   class=""><span class="item_outer"><span
                                                                                class="item_inner"><span
                                                                                    class="menu_icon_wrapper"><i
                                                                                        class="menu_icon icon-energy fa"></i></span><span
                                                                                    class="item_text">Accordion/Toggle</span></span><span
                                                                                class="plus"></span></span><span
                                                                            class="bottom-border"><span
                                                                                class="bottom-border-inner"></span></span></a>
                                                            </li>
                                                            <li id="sticky-nav-menu-item-1687"
                                                                class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                                <a href="http://libero.mikado-themes.com/service-tables/"
                                                                   class=""><span class="item_outer"><span
                                                                                class="item_inner"><span
                                                                                    class="menu_icon_wrapper"><i
                                                                                        class="menu_icon icon-pencil fa"></i></span><span
                                                                                    class="item_text">Service Tables</span></span><span
                                                                                class="plus"></span></span><span
                                                                            class="bottom-border"><span
                                                                                class="bottom-border-inner"></span></span></a>
                                                            </li>
                                                            <li id="sticky-nav-menu-item-1692"
                                                                class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                                <a href="http://libero.mikado-themes.com/animated-counters/"
                                                                   class=""><span class="item_outer"><span
                                                                                class="item_inner"><span
                                                                                    class="menu_icon_wrapper"><i
                                                                                        class="menu_icon icon-calculator fa"></i></span><span
                                                                                    class="item_text">Animated Counters</span></span><span
                                                                                class="plus"></span></span><span
                                                                            class="bottom-border"><span
                                                                                class="bottom-border-inner"></span></span></a>
                                                            </li>
                                                            <li id="sticky-nav-menu-item-1691"
                                                                class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                                <a href="http://libero.mikado-themes.com/call-to-action/"
                                                                   class=""><span class="item_outer"><span
                                                                                class="item_inner"><span
                                                                                    class="menu_icon_wrapper"><i
                                                                                        class="menu_icon icon-call-in fa"></i></span><span
                                                                                    class="item_text">Call to Action</span></span><span
                                                                                class="plus"></span></span><span
                                                                            class="bottom-border"><span
                                                                                class="bottom-border-inner"></span></span></a>
                                                            </li>
                                                            <li id="sticky-nav-menu-item-1683"
                                                                class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                                <a href="http://libero.mikado-themes.com/skill-progress-bar/"
                                                                   class=""><span class="item_outer"><span
                                                                                class="item_inner"><span
                                                                                    class="menu_icon_wrapper"><i
                                                                                        class="menu_icon icon-chart fa"></i></span><span
                                                                                    class="item_text">Skill Progress Bar</span></span><span
                                                                                class="plus"></span></span><span
                                                                            class="bottom-border"><span
                                                                                class="bottom-border-inner"></span></span></a>
                                                            </li>
                                                        </ul>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </li>
                                    <li id="sticky-nav-menu-item-502"
                                        class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow">
                                        <a href="http://libero.mikado-themes.com/portfolio-classic-four-columns/"
                                           class=""><span class="item_outer"><span class="item_inner"><span
                                                            class="menu_icon_wrapper"><i
                                                                class="menu_icon null fa"></i></span><span
                                                            class="item_text">Practice Areas</span></span><span
                                                        class="plus"></span></span><span
                                                    class="bottom-border"><span
                                                        class="bottom-border-inner"></span></span></a>
                                        <div class="second" style="height: 0px;">
                                            <div class="inner">
                                                <ul>
                                                    <li id="sticky-nav-menu-item-1787"
                                                        class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub">
                                                        <a href="#" class=" no_link" style="cursor: default;"
                                                           onclick="JavaScript: return false;"><span
                                                                    class="item_outer"><span
                                                                        class="item_inner"><span
                                                                            class="menu_icon_wrapper"><i
                                                                                class="menu_icon null fa"></i></span><span
                                                                            class="item_text">Practice Areas – Classic</span></span><span
                                                                        class="plus"></span><i
                                                                        class="q_menu_arrow fa fa-angle-right"></i></span><span
                                                                    class="bottom-border"><span
                                                                        class="bottom-border-inner"></span></span></a>
                                                        <ul>
                                                            <li id="sticky-nav-menu-item-1794"
                                                                class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                                <a href="http://libero.mikado-themes.com/portfolio-classic-two-columns/"
                                                                   class=""><span class="item_outer"><span
                                                                                class="item_inner"><span
                                                                                    class="menu_icon_wrapper"><i
                                                                                        class="menu_icon null fa"></i></span><span
                                                                                    class="item_text">Two Columns</span></span><span
                                                                                class="plus"></span></span><span
                                                                            class="bottom-border"><span
                                                                                class="bottom-border-inner"></span></span></a>
                                                            </li>
                                                            <li id="sticky-nav-menu-item-1793"
                                                                class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                                <a href="http://libero.mikado-themes.com/portfolio-classic-three-columns/"
                                                                   class=""><span class="item_outer"><span
                                                                                class="item_inner"><span
                                                                                    class="menu_icon_wrapper"><i
                                                                                        class="menu_icon null fa"></i></span><span
                                                                                    class="item_text">Three Columns</span></span><span
                                                                                class="plus"></span></span><span
                                                                            class="bottom-border"><span
                                                                                class="bottom-border-inner"></span></span></a>
                                                            </li>
                                                            <li id="sticky-nav-menu-item-504"
                                                                class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                                <a href="http://libero.mikado-themes.com/portfolio-classic-four-columns/"
                                                                   class=""><span class="item_outer"><span
                                                                                class="item_inner"><span
                                                                                    class="menu_icon_wrapper"><i
                                                                                        class="menu_icon null fa"></i></span><span
                                                                                    class="item_text">Four Columns</span></span><span
                                                                                class="plus"></span></span><span
                                                                            class="bottom-border"><span
                                                                                class="bottom-border-inner"></span></span></a>
                                                            </li>
                                                            <li id="sticky-nav-menu-item-1792"
                                                                class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                                <a href="http://libero.mikado-themes.com/portfolio-classic-four-columns-wide/"
                                                                   class=""><span class="item_outer"><span
                                                                                class="item_inner"><span
                                                                                    class="menu_icon_wrapper"><i
                                                                                        class="menu_icon null fa"></i></span><span
                                                                                    class="item_text">Four Columns Wide</span></span><span
                                                                                class="plus"></span></span><span
                                                                            class="bottom-border"><span
                                                                                class="bottom-border-inner"></span></span></a>
                                                            </li>
                                                        </ul>
                                                    </li>
                                                    <li id="sticky-nav-menu-item-1788"
                                                        class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub">
                                                        <a href="#" class=" no_link" style="cursor: default;"
                                                           onclick="JavaScript: return false;"><span
                                                                    class="item_outer"><span
                                                                        class="item_inner"><span
                                                                            class="menu_icon_wrapper"><i
                                                                                class="menu_icon null fa"></i></span><span
                                                                            class="item_text">Practice Areas – Modern</span></span><span
                                                                        class="plus"></span><i
                                                                        class="q_menu_arrow fa fa-angle-right"></i></span><span
                                                                    class="bottom-border"><span
                                                                        class="bottom-border-inner"></span></span></a>
                                                        <ul>
                                                            <li id="sticky-nav-menu-item-1791"
                                                                class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                                <a href="http://libero.mikado-themes.com/portfolio-modern-two-columns/"
                                                                   class=""><span class="item_outer"><span
                                                                                class="item_inner"><span
                                                                                    class="menu_icon_wrapper"><i
                                                                                        class="menu_icon null fa"></i></span><span
                                                                                    class="item_text">Two Columns</span></span><span
                                                                                class="plus"></span></span><span
                                                                            class="bottom-border"><span
                                                                                class="bottom-border-inner"></span></span></a>
                                                            </li>
                                                            <li id="sticky-nav-menu-item-1790"
                                                                class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                                <a href="http://libero.mikado-themes.com/portfolio-modern-three-columns/"
                                                                   class=""><span class="item_outer"><span
                                                                                class="item_inner"><span
                                                                                    class="menu_icon_wrapper"><i
                                                                                        class="menu_icon null fa"></i></span><span
                                                                                    class="item_text">Three Columns</span></span><span
                                                                                class="plus"></span></span><span
                                                                            class="bottom-border"><span
                                                                                class="bottom-border-inner"></span></span></a>
                                                            </li>
                                                            <li id="sticky-nav-menu-item-503"
                                                                class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                                <a href="http://libero.mikado-themes.com/portfolio-modern-four-columns/"
                                                                   class=""><span class="item_outer"><span
                                                                                class="item_inner"><span
                                                                                    class="menu_icon_wrapper"><i
                                                                                        class="menu_icon null fa"></i></span><span
                                                                                    class="item_text">Four Columns</span></span><span
                                                                                class="plus"></span></span><span
                                                                            class="bottom-border"><span
                                                                                class="bottom-border-inner"></span></span></a>
                                                            </li>
                                                            <li id="sticky-nav-menu-item-1789"
                                                                class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                                <a href="http://libero.mikado-themes.com/portfolio-modern-four-columns-wide/"
                                                                   class=""><span class="item_outer"><span
                                                                                class="item_inner"><span
                                                                                    class="menu_icon_wrapper"><i
                                                                                        class="menu_icon null fa"></i></span><span
                                                                                    class="item_text">Four Columns Wide</span></span><span
                                                                                class="plus"></span></span><span
                                                                            class="bottom-border"><span
                                                                                class="bottom-border-inner"></span></span></a>
                                                            </li>
                                                        </ul>
                                                    </li>
                                                    <li id="sticky-nav-menu-item-505"
                                                        class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub">
                                                        <a href="#" class=" no_link" style="cursor: default;"
                                                           onclick="JavaScript: return false;"><span
                                                                    class="item_outer"><span
                                                                        class="item_inner"><span
                                                                            class="menu_icon_wrapper"><i
                                                                                class="menu_icon null fa"></i></span><span
                                                                            class="item_text">Single Projects</span></span><span
                                                                        class="plus"></span><i
                                                                        class="q_menu_arrow fa fa-angle-right"></i></span><span
                                                                    class="bottom-border"><span
                                                                        class="bottom-border-inner"></span></span></a>
                                                        <ul>
                                                            <li id="sticky-nav-menu-item-506"
                                                                class="menu-item menu-item-type-custom menu-item-object-custom ">
                                                                <a href="http://libero.mikado-themes.com/portfolio-item/transactions/"
                                                                   class=""><span class="item_outer"><span
                                                                                class="item_inner"><span
                                                                                    class="menu_icon_wrapper"><i
                                                                                        class="menu_icon null fa"></i></span><span
                                                                                    class="item_text">Big Slider</span></span><span
                                                                                class="plus"></span></span><span
                                                                            class="bottom-border"><span
                                                                                class="bottom-border-inner"></span></span></a>
                                                            </li>
                                                            <li id="sticky-nav-menu-item-509"
                                                                class="menu-item menu-item-type-custom menu-item-object-custom ">
                                                                <a href="http://libero.mikado-themes.com/portfolio-item/formations/"
                                                                   class=""><span class="item_outer"><span
                                                                                class="item_inner"><span
                                                                                    class="menu_icon_wrapper"><i
                                                                                        class="menu_icon null fa"></i></span><span
                                                                                    class="item_text">Small Slider</span></span><span
                                                                                class="plus"></span></span><span
                                                                            class="bottom-border"><span
                                                                                class="bottom-border-inner"></span></span></a>
                                                            </li>
                                                            <li id="sticky-nav-menu-item-508"
                                                                class="menu-item menu-item-type-custom menu-item-object-custom ">
                                                                <a href="http://libero.mikado-themes.com/portfolio-item/contracts/"
                                                                   class=""><span class="item_outer"><span
                                                                                class="item_inner"><span
                                                                                    class="menu_icon_wrapper"><i
                                                                                        class="menu_icon null fa"></i></span><span
                                                                                    class="item_text">Big Images</span></span><span
                                                                                class="plus"></span></span><span
                                                                            class="bottom-border"><span
                                                                                class="bottom-border-inner"></span></span></a>
                                                            </li>
                                                            <li id="sticky-nav-menu-item-507"
                                                                class="menu-item menu-item-type-custom menu-item-object-custom ">
                                                                <a href="http://libero.mikado-themes.com/portfolio-item/insolvency/"
                                                                   class=""><span class="item_outer"><span
                                                                                class="item_inner"><span
                                                                                    class="menu_icon_wrapper"><i
                                                                                        class="menu_icon null fa"></i></span><span
                                                                                    class="item_text">Small Images</span></span><span
                                                                                class="plus"></span></span><span
                                                                            class="bottom-border"><span
                                                                                class="bottom-border-inner"></span></span></a>
                                                            </li>
                                                            <li id="sticky-nav-menu-item-510"
                                                                class="menu-item menu-item-type-custom menu-item-object-custom ">
                                                                <a href="http://libero.mikado-themes.com/portfolio-item/criminal-code/"
                                                                   class=""><span class="item_outer"><span
                                                                                class="item_inner"><span
                                                                                    class="menu_icon_wrapper"><i
                                                                                        class="menu_icon null fa"></i></span><span
                                                                                    class="item_text">Gallery</span></span><span
                                                                                class="plus"></span></span><span
                                                                            class="bottom-border"><span
                                                                                class="bottom-border-inner"></span></span></a>
                                                            </li>
                                                        </ul>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </li>
                                    <li id="sticky-nav-menu-item-512"
                                        class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow">
                                        <a href="http://libero.mikado-themes.com/blog-list-with-right-sidebar/"
                                           class=""><span class="item_outer"><span class="item_inner"><span
                                                            class="menu_icon_wrapper"><i
                                                                class="menu_icon null fa"></i></span><span
                                                            class="item_text">Blog</span></span><span
                                                        class="plus"></span></span><span
                                                    class="bottom-border"><span
                                                        class="bottom-border-inner"></span></span></a>
                                        <div class="second" style="height: 0px;">
                                            <div class="inner">
                                                <ul>
                                                    <li id="sticky-nav-menu-item-513"
                                                        class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                        <a href="http://libero.mikado-themes.com/blog-list-with-right-sidebar/"
                                                           class=""><span class="item_outer"><span
                                                                        class="item_inner"><span
                                                                            class="menu_icon_wrapper"><i
                                                                                class="menu_icon null fa"></i></span><span
                                                                            class="item_text">Blog List with Right Sidebar</span></span><span
                                                                        class="plus"></span></span><span
                                                                    class="bottom-border"><span
                                                                        class="bottom-border-inner"></span></span></a>
                                                    </li>
                                                    <li id="sticky-nav-menu-item-515"
                                                        class="menu-item menu-item-type-custom menu-item-object-custom ">
                                                        <a href="http://libero.mikado-themes.com/form-3115-for-a-cash-to-accrual-method-for-small-businesses/"
                                                           class=""><span class="item_outer"><span
                                                                        class="item_inner"><span
                                                                            class="menu_icon_wrapper"><i
                                                                                class="menu_icon null fa"></i></span><span
                                                                            class="item_text">Standard Single Post</span></span><span
                                                                        class="plus"></span></span><span
                                                                    class="bottom-border"><span
                                                                        class="bottom-border-inner"></span></span></a>
                                                    </li>
                                                    <li id="sticky-nav-menu-item-517"
                                                        class="menu-item menu-item-type-custom menu-item-object-custom ">
                                                        <a href="http://libero.mikado-themes.com/further-specialist-help-providing-free-legal-advice/"
                                                           class=""><span class="item_outer"><span
                                                                        class="item_inner"><span
                                                                            class="menu_icon_wrapper"><i
                                                                                class="menu_icon null fa"></i></span><span
                                                                            class="item_text">Gallery Single Post</span></span><span
                                                                        class="plus"></span></span><span
                                                                    class="bottom-border"><span
                                                                        class="bottom-border-inner"></span></span></a>
                                                    </li>
                                                    <li id="sticky-nav-menu-item-516"
                                                        class="menu-item menu-item-type-custom menu-item-object-custom ">
                                                        <a href="http://libero.mikado-themes.com/elie-wiesel/"
                                                           class=""><span class="item_outer"><span
                                                                        class="item_inner"><span
                                                                            class="menu_icon_wrapper"><i
                                                                                class="menu_icon null fa"></i></span><span
                                                                            class="item_text">Quote Single Post</span></span><span
                                                                        class="plus"></span></span><span
                                                                    class="bottom-border"><span
                                                                        class="bottom-border-inner"></span></span></a>
                                                    </li>
                                                    <li id="sticky-nav-menu-item-518"
                                                        class="menu-item menu-item-type-custom menu-item-object-custom ">
                                                        <a href="http://libero.mikado-themes.com/how-to-write-statements-position-papers-and-letters/"
                                                           class=""><span class="item_outer"><span
                                                                        class="item_inner"><span
                                                                            class="menu_icon_wrapper"><i
                                                                                class="menu_icon null fa"></i></span><span
                                                                            class="item_text">Link Single Post</span></span><span
                                                                        class="plus"></span></span><span
                                                                    class="bottom-border"><span
                                                                        class="bottom-border-inner"></span></span></a>
                                                    </li>
                                                    <li id="sticky-nav-menu-item-526"
                                                        class="menu-item menu-item-type-custom menu-item-object-custom ">
                                                        <a href="http://libero.mikado-themes.com/the-difference-between-legal-information-and-legal-advice/"
                                                           class=""><span class="item_outer"><span
                                                                        class="item_inner"><span
                                                                            class="menu_icon_wrapper"><i
                                                                                class="menu_icon null fa"></i></span><span
                                                                            class="item_text">Audio Single Post</span></span><span
                                                                        class="plus"></span></span><span
                                                                    class="bottom-border"><span
                                                                        class="bottom-border-inner"></span></span></a>
                                                    </li>
                                                    <li id="sticky-nav-menu-item-519"
                                                        class="menu-item menu-item-type-custom menu-item-object-custom ">
                                                        <a href="http://libero.mikado-themes.com/promoting-consciousness-of-legal-culture-by-raising-legal-awareness/"
                                                           class=""><span class="item_outer"><span
                                                                        class="item_inner"><span
                                                                            class="menu_icon_wrapper"><i
                                                                                class="menu_icon null fa"></i></span><span
                                                                            class="item_text">Video Single Post</span></span><span
                                                                        class="plus"></span></span><span
                                                                    class="bottom-border"><span
                                                                        class="bottom-border-inner"></span></span></a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </li>
                                    <li id="sticky-nav-menu-item-1839"
                                        class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow">
                                        <a href="http://libero.mikado-themes.com/shop/" class=""><span
                                                    class="item_outer"><span class="item_inner"><span
                                                            class="menu_icon_wrapper"><i
                                                                class="menu_icon null fa"></i></span><span
                                                            class="item_text">Products</span></span><span
                                                        class="plus"></span></span><span
                                                    class="bottom-border"><span
                                                        class="bottom-border-inner"></span></span></a>
                                        <div class="second" style="height: 0px;">
                                            <div class="inner">
                                                <ul>
                                                    <li id="sticky-nav-menu-item-1838"
                                                        class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                        <a href="http://libero.mikado-themes.com/shop/"
                                                           class=""><span class="item_outer"><span
                                                                        class="item_inner"><span
                                                                            class="menu_icon_wrapper"><i
                                                                                class="menu_icon null fa"></i></span><span
                                                                            class="item_text">With Sidebar</span></span><span
                                                                        class="plus"></span></span><span
                                                                    class="bottom-border"><span
                                                                        class="bottom-border-inner"></span></span></a>
                                                    </li>
                                                    <li id="sticky-nav-menu-item-1837"
                                                        class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                        <a href="http://libero.mikado-themes.com/shop-without-sidebar/"
                                                           class=""><span class="item_outer"><span
                                                                        class="item_inner"><span
                                                                            class="menu_icon_wrapper"><i
                                                                                class="menu_icon null fa"></i></span><span
                                                                            class="item_text">Without Sidebar</span></span><span
                                                                        class="plus"></span></span><span
                                                                    class="bottom-border"><span
                                                                        class="bottom-border-inner"></span></span></a>
                                                    </li>
                                                    <li id="sticky-nav-menu-item-1840"
                                                        class="menu-item menu-item-type-custom menu-item-object-custom ">
                                                        <a href="http://libero.mikado-themes.com/product/bottled-fountain-pen-ink/"
                                                           class=""><span class="item_outer"><span
                                                                        class="item_inner"><span
                                                                            class="menu_icon_wrapper"><i
                                                                                class="menu_icon null fa"></i></span><span
                                                                            class="item_text">Single Product</span></span><span
                                                                        class="plus"></span></span><span
                                                                    class="bottom-border"><span
                                                                        class="bottom-border-inner"></span></span></a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                                        <span class="mkd-item-hover"
                                              style="width: 78px; left: 219.217px; opacity: 0;"></span></nav>

                        </div>
                    </div>
                    <div class="mkd-position-right">
                        <div class="mkd-position-right-inner">
                            <div id="text-21" class="widget widget_text mkd-sticky-right">
                                <div class="textwidget"><a
                                            href="http://libero.mikado-themes.com/contact-with-google-map/"
                                            target="_self" style="font-weight: 900"
                                            class="mkd-btn mkd-btn-medium mkd-btn-solid mkd-btn-icon">
                                        <span class="mkd-btn-text">Free Evaluation</span><span
                                                class="mkd-btn-icon-holder">
            <span aria-hidden="true" class="mkd-icon-font-elegant arrow_carrot-right mkd-btn-icon-elem"></span>            <span
                                                    aria-hidden="true"
                                                    class="mkd-icon-font-elegant arrow_carrot-right mkd-btn-icon-elem"></span>        </span>
                                    </a></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</header>


<header class="mkd-mobile-header mkd-animate-mobile-header" style="margin-bottom: 0px;">
    <div class="mkd-mobile-header-inner">
        <div class="mkd-mobile-header-holder">
            <div class="mkd-vertical-align-containers">
                <div class="mkd-position-left">
                    <div class="mkd-position-left-inner">

                        <div class="mkd-mobile-logo-wrapper">
                            <a href="http://libero.mikado-themes.com/" style="height: 60px">
                                <img src="/image/logo-mobile.png"
                                     alt="mobile logo">
                            </a>
                        </div>

                    </div>
                </div>

                <div class="mkd-position-right">
                    <div class="mkd-position-right-inner">
                        <div class="mkd-mobile-menu-opener">
                            <a href="javascript:void(0)">
                                <span class="mkd-mobile-opener-icon-holder">
                                    <span class="mkd-lines-holder">
                                        <span class="mkd-lines-holder-inner">
                                            <span class="mkd-lines line-1"></span>
                                            <span class="mkd-lines line-2"></span>
                                            <span class="mkd-lines line-3"></span>
                                            <span class="mkd-lines line-4"></span>
                                            <span class="mkd-lines line-5"></span>
                                        </span>
                                    </span>
                                </span>
                            </a>
                        </div>
                    </div>
                </div>
            </div> <!-- close .mkd-vertical-align-containers -->
        </div>

        <nav class="mkd-mobile-nav">
            <div class="mkd-grid">
                <ul id="menu-main_menu-2" class="">
                    <li id="mobile-menu-item-496"
                        class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-home current-menu-ancestor current-menu-parent menu-item-has-children mkd-active-item has_sub">
                        <a href="http://libero.mikado-themes.com/"
                           class=" current "><span>Homepages</span></a><span class="mobile_arrow"><i
                                    class="mkd-sub-arrow fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span>
                        <ul class="sub_menu">
                            <li id="mobile-menu-item-498"
                                class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-388 current_page_item ">
                                <a href="http://libero.mikado-themes.com/" class=""><span>Home 1</span></a></li>
                            <li id="mobile-menu-item-2462"
                                class="menu-item menu-item-type-post_type menu-item-object-page "><a
                                        href="http://libero.mikado-themes.com/home-2/"
                                        class=""><span>Home 2</span></a>
                            </li>
                            <li id="mobile-menu-item-2463"
                                class="menu-item menu-item-type-post_type menu-item-object-page "><a
                                        href="http://libero.mikado-themes.com/home-3/"
                                        class=""><span>Home 3</span></a>
                            </li>
                            <li id="mobile-menu-item-2464"
                                class="menu-item menu-item-type-post_type menu-item-object-page "><a
                                        href="http://libero.mikado-themes.com/home-4/"
                                        class=""><span>Home 4</span></a>
                            </li>
                            <li id="mobile-menu-item-2465"
                                class="menu-item menu-item-type-post_type menu-item-object-page "><a
                                        href="http://libero.mikado-themes.com/home-5/"
                                        class=""><span>Home 5</span></a>
                            </li>
                            <li id="mobile-menu-item-2455"
                                class="menu-item menu-item-type-post_type menu-item-object-page "><a
                                        href="http://libero.mikado-themes.com/home-6/"
                                        class=""><span>Home 6</span></a>
                            </li>
                        </ul>
                    </li>
                    <li id="mobile-menu-item-604"
                        class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub">
                        <a href="http://libero.mikado-themes.com/about-our-company/" class=""><span>Pages</span></a><span
                                class="mobile_arrow"><i class="mkd-sub-arrow fa fa-angle-right"></i><i
                                    class="fa fa-angle-down"></i></span>
                        <ul class="sub_menu">
                            <li id="mobile-menu-item-1059"
                                class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub">
                                <h4><span>Featured</span></h4><span class="mobile_arrow"><i
                                            class="mkd-sub-arrow fa fa-angle-right"></i><i
                                            class="fa fa-angle-down"></i></span>
                                <ul class="sub_menu">
                                    <li id="mobile-menu-item-813"
                                        class="menu-item menu-item-type-post_type menu-item-object-page "><a
                                                href="http://libero.mikado-themes.com/about-our-company/"
                                                class=""><span>About Our Company</span></a></li>
                                    <li id="mobile-menu-item-918"
                                        class="menu-item menu-item-type-post_type menu-item-object-page "><a
                                                href="http://libero.mikado-themes.com/facts/"
                                                class=""><span>Facts</span></a></li>
                                    <li id="mobile-menu-item-1042"
                                        class="menu-item menu-item-type-post_type menu-item-object-page "><a
                                                href="http://libero.mikado-themes.com/our-team-of-lawyers/"
                                                class=""><span>Our Team of Lawyers</span></a></li>
                                    <li id="mobile-menu-item-1043"
                                        class="menu-item menu-item-type-post_type menu-item-object-page "><a
                                                href="http://libero.mikado-themes.com/our-services/"
                                                class=""><span>Our Services</span></a>
                                    </li>
                                    <li id="mobile-menu-item-831"
                                        class="menu-item menu-item-type-post_type menu-item-object-page "><a
                                                href="http://libero.mikado-themes.com/company-history/"
                                                class=""><span>Company History</span></a></li>
                                    <li id="mobile-menu-item-1010"
                                        class="menu-item menu-item-type-post_type menu-item-object-page "><a
                                                href="http://libero.mikado-themes.com/media-center/"
                                                class=""><span>Media Center</span></a>
                                    </li>
                                </ul>
                            </li>
                            <li id="mobile-menu-item-1060"
                                class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub">
                                <h4><span>Standard</span></h4><span class="mobile_arrow"><i
                                            class="mkd-sub-arrow fa fa-angle-right"></i><i
                                            class="fa fa-angle-down"></i></span>
                                <ul class="sub_menu">
                                    <li id="mobile-menu-item-807"
                                        class="menu-item menu-item-type-post_type menu-item-object-page "><a
                                                href="http://libero.mikado-themes.com/coming-soon-page/"
                                                class=""><span>Coming Soon Page</span></a></li>
                                    <li id="mobile-menu-item-991"
                                        class="menu-item menu-item-type-post_type menu-item-object-page "><a
                                                href="http://libero.mikado-themes.com/maintenance-page/"
                                                class=""><span>Maintenance Page</span></a></li>
                                    <li id="mobile-menu-item-1011"
                                        class="menu-item menu-item-type-post_type menu-item-object-page "><a
                                                href="http://libero.mikado-themes.com/our-clients/"
                                                class=""><span>Our Clients</span></a>
                                    </li>
                                    <li id="mobile-menu-item-812"
                                        class="menu-item menu-item-type-post_type menu-item-object-page "><a
                                                href="http://libero.mikado-themes.com/areas-of-expertise/"
                                                class=""><span>Areas of Expertise</span></a>
                                    </li>
                                    <li id="mobile-menu-item-1482"
                                        class="menu-item menu-item-type-post_type menu-item-object-page "><a
                                                href="http://libero.mikado-themes.com/contact-with-google-map/"
                                                class=""><span>Contact</span></a></li>
                                    <li id="mobile-menu-item-602"
                                        class="menu-item menu-item-type-custom menu-item-object-custom "><a
                                                href="http://libero.mikado-themes.com/missing-page"
                                                class=""><span>404 Page</span></a>
                                    </li>
                                </ul>
                            </li>
                            <li id="mobile-menu-item-1061"
                                class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub">
                                <h4><span>Additional</span></h4><span class="mobile_arrow"><i
                                            class="mkd-sub-arrow fa fa-angle-right"></i><i
                                            class="fa fa-angle-down"></i></span>
                                <ul class="sub_menu">
                                    <li id="mobile-menu-item-808"
                                        class="menu-item menu-item-type-post_type menu-item-object-page "><a
                                                href="http://libero.mikado-themes.com/client-testimonials/"
                                                class=""><span>Client Testimonials</span></a></li>
                                    <li id="mobile-menu-item-810"
                                        class="menu-item menu-item-type-post_type menu-item-object-page "><a
                                                href="http://libero.mikado-themes.com/considering-divorce/"
                                                class=""><span>Considering Divorce</span></a></li>
                                    <li id="mobile-menu-item-917"
                                        class="menu-item menu-item-type-post_type menu-item-object-page "><a
                                                href="http://libero.mikado-themes.com/faq/"
                                                class=""><span>FAQ</span></a></li>
                                    <li id="mobile-menu-item-811"
                                        class="menu-item menu-item-type-post_type menu-item-object-page "><a
                                                href="http://libero.mikado-themes.com/avoiding-bail/"
                                                class=""><span>Avoiding Bail</span></a></li>
                                    <li id="mobile-menu-item-809"
                                        class="menu-item menu-item-type-post_type menu-item-object-page "><a
                                                href="http://libero.mikado-themes.com/car-accident-injuries/"
                                                class=""><span>Car Accident Injuries</span></a></li>
                                    <li id="mobile-menu-item-990"
                                        class="menu-item menu-item-type-post_type menu-item-object-page "><a
                                                href="http://libero.mikado-themes.com/fraud-claims/"
                                                class=""><span>Fraud Claims</span></a>
                                    </li>
                                </ul>
                            </li>
                            <li id="mobile-menu-item-1704"
                                class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub">
                                <a href="#" class=""><span>Title Variations</span></a><span
                                        class="mobile_arrow"><i class="mkd-sub-arrow fa fa-angle-right"></i><i
                                            class="fa fa-angle-down"></i></span>
                                <ul class="sub_menu">
                                    <li id="mobile-menu-item-1703"
                                        class="menu-item menu-item-type-post_type menu-item-object-page "><a
                                                href="http://libero.mikado-themes.com/theme-default-title/"
                                                class=""><span>Theme Default</span></a></li>
                                    <li id="mobile-menu-item-1701"
                                        class="menu-item menu-item-type-post_type menu-item-object-page "><a
                                                href="http://libero.mikado-themes.com/title-with-icon/"
                                                class=""><span>Parallax With Icon</span></a></li>
                                    <li id="mobile-menu-item-1702"
                                        class="menu-item menu-item-type-post_type menu-item-object-page "><a
                                                href="http://libero.mikado-themes.com/responsive-image-title/"
                                                class=""><span>Responsive Image</span></a></li>
                                    <li id="mobile-menu-item-1700"
                                        class="menu-item menu-item-type-post_type menu-item-object-page "><a
                                                href="http://libero.mikado-themes.com/monocolored-title/"
                                                class=""><span>Monocolored</span></a></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li id="mobile-menu-item-1679"
                        class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub">
                        <a href="http://libero.mikado-themes.com/free-and-premium-sliders/" class=""><span>Elements</span></a><span
                                class="mobile_arrow"><i class="mkd-sub-arrow fa fa-angle-right"></i><i
                                    class="fa fa-angle-down"></i></span>
                        <ul class="sub_menu">
                            <li id="mobile-menu-item-1798"
                                class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub">
                                <h4><span>Specials</span></h4><span class="mobile_arrow"><i
                                            class="mkd-sub-arrow fa fa-angle-right"></i><i
                                            class="fa fa-angle-down"></i></span>
                                <ul class="sub_menu">
                                    <li id="mobile-menu-item-1690"
                                        class="menu-item menu-item-type-post_type menu-item-object-page "><a
                                                href="http://libero.mikado-themes.com/free-and-premium-sliders/"
                                                class=""><span>Premium Sliders</span></a></li>
                                    <li id="mobile-menu-item-1685"
                                        class="menu-item menu-item-type-post_type menu-item-object-page "><a
                                                href="http://libero.mikado-themes.com/our-team/" class=""><span>Our Team</span></a>
                                    </li>
                                    <li id="mobile-menu-item-1681"
                                        class="menu-item menu-item-type-post_type menu-item-object-page "><a
                                                href="http://libero.mikado-themes.com/video-combinations/"
                                                class=""><span>Video Combinations</span></a>
                                    </li>
                                    <li id="mobile-menu-item-1684"
                                        class="menu-item menu-item-type-post_type menu-item-object-page "><a
                                                href="http://libero.mikado-themes.com/interactive-banners/"
                                                class=""><span>Interactive Banners</span></a></li>
                                    <li id="mobile-menu-item-1686"
                                        class="menu-item menu-item-type-post_type menu-item-object-page "><a
                                                href="http://libero.mikado-themes.com/parallax-sections/"
                                                class=""><span>Parallax Sections</span></a></li>
                                </ul>
                            </li>
                            <li id="mobile-menu-item-1832"
                                class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub">
                                <a href="#" class=""><span>Interactive</span></a><span class="mobile_arrow"><i
                                            class="mkd-sub-arrow fa fa-angle-right"></i><i
                                            class="fa fa-angle-down"></i></span>
                                <ul class="sub_menu">
                                    <li id="mobile-menu-item-1829"
                                        class="menu-item menu-item-type-post_type menu-item-object-page "><a
                                                href="http://libero.mikado-themes.com/interactive-icons/"
                                                class=""><span>Interactive Icons</span></a></li>
                                    <li id="mobile-menu-item-2031"
                                        class="menu-item menu-item-type-post_type menu-item-object-page "><a
                                                href="http://libero.mikado-themes.com/icon-with-text/"
                                                class=""><span>Icon With Text</span></a></li>
                                    <li id="mobile-menu-item-1830"
                                        class="menu-item menu-item-type-post_type menu-item-object-page "><a
                                                href="http://libero.mikado-themes.com/image-with-text/"
                                                class=""><span>Image with Text</span></a></li>
                                    <li id="mobile-menu-item-2033"
                                        class="menu-item menu-item-type-post_type menu-item-object-page "><a
                                                href="http://libero.mikado-themes.com/image-gallery/"
                                                class=""><span>Image Gallery</span></a></li>
                                    <li id="mobile-menu-item-1689"
                                        class="menu-item menu-item-type-post_type menu-item-object-page "><a
                                                href="http://libero.mikado-themes.com/interactive-image/"
                                                class=""><span>Interactive Image</span></a></li>
                                </ul>
                            </li>
                            <li id="mobile-menu-item-1797"
                                class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub">
                                <h4><span>Standard</span></h4><span class="mobile_arrow"><i
                                            class="mkd-sub-arrow fa fa-angle-right"></i><i
                                            class="fa fa-angle-down"></i></span>
                                <ul class="sub_menu">
                                    <li id="mobile-menu-item-1682"
                                        class="menu-item menu-item-type-post_type menu-item-object-page "><a
                                                href="http://libero.mikado-themes.com/social-icons/"
                                                class=""><span>Social Icons</span></a>
                                    </li>
                                    <li id="mobile-menu-item-1831"
                                        class="menu-item menu-item-type-post_type menu-item-object-page "><a
                                                href="http://libero.mikado-themes.com/latest-posts/"
                                                class=""><span>Latest Posts</span></a>
                                    </li>
                                    <li id="mobile-menu-item-2035"
                                        class="menu-item menu-item-type-post_type menu-item-object-page "><a
                                                href="http://libero.mikado-themes.com/buttons/" class=""><span>Buttons</span></a>
                                    </li>
                                    <li id="mobile-menu-item-2032"
                                        class="menu-item menu-item-type-post_type menu-item-object-page "><a
                                                href="http://libero.mikado-themes.com/separators/"
                                                class=""><span>Separators</span></a>
                                    </li>
                                    <li id="mobile-menu-item-1688"
                                        class="menu-item menu-item-type-post_type menu-item-object-page "><a
                                                href="http://libero.mikado-themes.com/clients-slider/"
                                                class=""><span>Clients Slider</span></a></li>
                                </ul>
                            </li>
                            <li id="mobile-menu-item-1833"
                                class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub">
                                <a href="#" class=""><span>Infographic</span></a><span class="mobile_arrow"><i
                                            class="mkd-sub-arrow fa fa-angle-right"></i><i
                                            class="fa fa-angle-down"></i></span>
                                <ul class="sub_menu">
                                    <li id="mobile-menu-item-1693"
                                        class="menu-item menu-item-type-post_type menu-item-object-page "><a
                                                href="http://libero.mikado-themes.com/accordions-and-toggles/"
                                                class=""><span>Accordion/Toggle</span></a></li>
                                    <li id="mobile-menu-item-1687"
                                        class="menu-item menu-item-type-post_type menu-item-object-page "><a
                                                href="http://libero.mikado-themes.com/service-tables/"
                                                class=""><span>Service Tables</span></a></li>
                                    <li id="mobile-menu-item-1692"
                                        class="menu-item menu-item-type-post_type menu-item-object-page "><a
                                                href="http://libero.mikado-themes.com/animated-counters/"
                                                class=""><span>Animated Counters</span></a></li>
                                    <li id="mobile-menu-item-1691"
                                        class="menu-item menu-item-type-post_type menu-item-object-page "><a
                                                href="http://libero.mikado-themes.com/call-to-action/"
                                                class=""><span>Call to Action</span></a></li>
                                    <li id="mobile-menu-item-1683"
                                        class="menu-item menu-item-type-post_type menu-item-object-page "><a
                                                href="http://libero.mikado-themes.com/skill-progress-bar/"
                                                class=""><span>Skill Progress Bar</span></a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li id="mobile-menu-item-502"
                        class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub">
                        <a href="http://libero.mikado-themes.com/portfolio-classic-four-columns/"
                           class=""><span>Practice Areas</span></a><span class="mobile_arrow"><i
                                    class="mkd-sub-arrow fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span>
                        <ul class="sub_menu">
                            <li id="mobile-menu-item-1787"
                                class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub">
                                <h4><span>Practice Areas – Classic</span></h4><span class="mobile_arrow"><i
                                            class="mkd-sub-arrow fa fa-angle-right"></i><i
                                            class="fa fa-angle-down"></i></span>
                                <ul class="sub_menu">
                                    <li id="mobile-menu-item-1794"
                                        class="menu-item menu-item-type-post_type menu-item-object-page "><a
                                                href="http://libero.mikado-themes.com/portfolio-classic-two-columns/"
                                                class=""><span>Two Columns</span></a></li>
                                    <li id="mobile-menu-item-1793"
                                        class="menu-item menu-item-type-post_type menu-item-object-page "><a
                                                href="http://libero.mikado-themes.com/portfolio-classic-three-columns/"
                                                class=""><span>Three Columns</span></a></li>
                                    <li id="mobile-menu-item-504"
                                        class="menu-item menu-item-type-post_type menu-item-object-page "><a
                                                href="http://libero.mikado-themes.com/portfolio-classic-four-columns/"
                                                class=""><span>Four Columns</span></a></li>
                                    <li id="mobile-menu-item-1792"
                                        class="menu-item menu-item-type-post_type menu-item-object-page "><a
                                                href="http://libero.mikado-themes.com/portfolio-classic-four-columns-wide/"
                                                class=""><span>Four Columns Wide</span></a></li>
                                </ul>
                            </li>
                            <li id="mobile-menu-item-1788"
                                class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub">
                                <h4><span>Practice Areas – Modern</span></h4><span class="mobile_arrow"><i
                                            class="mkd-sub-arrow fa fa-angle-right"></i><i
                                            class="fa fa-angle-down"></i></span>
                                <ul class="sub_menu">
                                    <li id="mobile-menu-item-1791"
                                        class="menu-item menu-item-type-post_type menu-item-object-page "><a
                                                href="http://libero.mikado-themes.com/portfolio-modern-two-columns/"
                                                class=""><span>Two Columns</span></a></li>
                                    <li id="mobile-menu-item-1790"
                                        class="menu-item menu-item-type-post_type menu-item-object-page "><a
                                                href="http://libero.mikado-themes.com/portfolio-modern-three-columns/"
                                                class=""><span>Three Columns</span></a></li>
                                    <li id="mobile-menu-item-503"
                                        class="menu-item menu-item-type-post_type menu-item-object-page "><a
                                                href="http://libero.mikado-themes.com/portfolio-modern-four-columns/"
                                                class=""><span>Four Columns</span></a></li>
                                    <li id="mobile-menu-item-1789"
                                        class="menu-item menu-item-type-post_type menu-item-object-page "><a
                                                href="http://libero.mikado-themes.com/portfolio-modern-four-columns-wide/"
                                                class=""><span>Four Columns Wide</span></a></li>
                                </ul>
                            </li>
                            <li id="mobile-menu-item-505"
                                class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub">
                                <h4><span>Single Projects</span></h4><span class="mobile_arrow"><i
                                            class="mkd-sub-arrow fa fa-angle-right"></i><i
                                            class="fa fa-angle-down"></i></span>
                                <ul class="sub_menu">
                                    <li id="mobile-menu-item-506"
                                        class="menu-item menu-item-type-custom menu-item-object-custom "><a
                                                href="http://libero.mikado-themes.com/portfolio-item/transactions/"
                                                class=""><span>Big Slider</span></a></li>
                                    <li id="mobile-menu-item-509"
                                        class="menu-item menu-item-type-custom menu-item-object-custom "><a
                                                href="http://libero.mikado-themes.com/portfolio-item/formations/"
                                                class=""><span>Small Slider</span></a></li>
                                    <li id="mobile-menu-item-508"
                                        class="menu-item menu-item-type-custom menu-item-object-custom "><a
                                                href="http://libero.mikado-themes.com/portfolio-item/contracts/"
                                                class=""><span>Big Images</span></a></li>
                                    <li id="mobile-menu-item-507"
                                        class="menu-item menu-item-type-custom menu-item-object-custom "><a
                                                href="http://libero.mikado-themes.com/portfolio-item/insolvency/"
                                                class=""><span>Small Images</span></a></li>
                                    <li id="mobile-menu-item-510"
                                        class="menu-item menu-item-type-custom menu-item-object-custom "><a
                                                href="http://libero.mikado-themes.com/portfolio-item/criminal-code/"
                                                class=""><span>Gallery</span></a></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li id="mobile-menu-item-512"
                        class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub">
                        <a href="http://libero.mikado-themes.com/blog-list-with-right-sidebar/" class=""><span>Blog</span></a><span
                                class="mobile_arrow"><i class="mkd-sub-arrow fa fa-angle-right"></i><i
                                    class="fa fa-angle-down"></i></span>
                        <ul class="sub_menu">
                            <li id="mobile-menu-item-513"
                                class="menu-item menu-item-type-post_type menu-item-object-page "><a
                                        href="http://libero.mikado-themes.com/blog-list-with-right-sidebar/"
                                        class=""><span>Blog List with Right Sidebar</span></a></li>
                            <li id="mobile-menu-item-515"
                                class="menu-item menu-item-type-custom menu-item-object-custom "><a
                                        href="http://libero.mikado-themes.com/form-3115-for-a-cash-to-accrual-method-for-small-businesses/"
                                        class=""><span>Standard Single Post</span></a></li>
                            <li id="mobile-menu-item-517"
                                class="menu-item menu-item-type-custom menu-item-object-custom "><a
                                        href="http://libero.mikado-themes.com/further-specialist-help-providing-free-legal-advice/"
                                        class=""><span>Gallery Single Post</span></a></li>
                            <li id="mobile-menu-item-516"
                                class="menu-item menu-item-type-custom menu-item-object-custom "><a
                                        href="http://libero.mikado-themes.com/elie-wiesel/" class=""><span>Quote Single Post</span></a>
                            </li>
                            <li id="mobile-menu-item-518"
                                class="menu-item menu-item-type-custom menu-item-object-custom "><a
                                        href="http://libero.mikado-themes.com/how-to-write-statements-position-papers-and-letters/"
                                        class=""><span>Link Single Post</span></a></li>
                            <li id="mobile-menu-item-526"
                                class="menu-item menu-item-type-custom menu-item-object-custom "><a
                                        href="http://libero.mikado-themes.com/the-difference-between-legal-information-and-legal-advice/"
                                        class=""><span>Audio Single Post</span></a></li>
                            <li id="mobile-menu-item-519"
                                class="menu-item menu-item-type-custom menu-item-object-custom "><a
                                        href="http://libero.mikado-themes.com/promoting-consciousness-of-legal-culture-by-raising-legal-awareness/"
                                        class=""><span>Video Single Post</span></a></li>
                        </ul>
                    </li>
                    <li id="mobile-menu-item-1839"
                        class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub">
                        <a href="http://libero.mikado-themes.com/shop/" class=""><span>Products</span></a><span
                                class="mobile_arrow"><i class="mkd-sub-arrow fa fa-angle-right"></i><i
                                    class="fa fa-angle-down"></i></span>
                        <ul class="sub_menu">
                            <li id="mobile-menu-item-1838"
                                class="menu-item menu-item-type-post_type menu-item-object-page "><a
                                        href="http://libero.mikado-themes.com/shop/"
                                        class=""><span>With Sidebar</span></a></li>
                            <li id="mobile-menu-item-1837"
                                class="menu-item menu-item-type-post_type menu-item-object-page "><a
                                        href="http://libero.mikado-themes.com/shop-without-sidebar/"
                                        class=""><span>Without Sidebar</span></a>
                            </li>
                            <li id="mobile-menu-item-1840"
                                class="menu-item menu-item-type-custom menu-item-object-custom "><a
                                        href="http://libero.mikado-themes.com/product/bottled-fountain-pen-ink/"
                                        class=""><span>Single Product</span></a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </nav>

    </div>
</header> <!-- close .mkd-mobile-header -->

