<?php $__env->startSection('content'); ?>

    <div class="mkd-content" style="margin-bottom: 529px;">
        <div class="mkd-content-inner">
            <div class="mkd-slider">
                <div class="mkd-slider-inner">
                    <link href="/css/css_003.css"
                          rel="stylesheet" property="stylesheet" type="text/css" media="all">
                    <link href="/css/css_002.css"
                          rel="stylesheet" property="stylesheet" type="text/css" media="all">
                    <div class="forcefullwidth_wrapper_tp_banner"
                         style="position:relative;width:100%;height:auto;margin-top:0px;margin-bottom:0px">
                        <div id="rev_slider_8_1_wrapper" class="rev_slider_wrapper fullscreen-container"
                             style="background-color: transparent; padding: 0px; height: 505px; margin-top: 0px; margin-bottom: 0px; position: absolute; max-height: none; overflow: visible; width: 1349px; left: 0px;">
                            <!-- START REVOLUTION SLIDER 5.1.4 fullscreen mode -->
                            <div id="rev_slider_8_1"
                                 class="rev_slider fullscreenbanner revslider-initialised tp-simpleresponsive"
                                 style="max-height: none; margin-top: 0px; margin-bottom: 0px; height: 100%;"
                                 data-version="5.1.4">
                                <ul class="tp-revslider-mainul"
                                    style="visibility: visible; display: block; overflow: hidden; width: 100%; height: 100%; max-height: none;">
                                    <!-- SLIDE  -->
                                    <li data-index="rs-11" data-transition="fade" data-slotamount="default"
                                        data-easein="default" data-easeout="default" data-masterspeed="300"
                                        data-thumb="http://libero.mikado-themes.com/wp-content/uploads/2015/12/h4-slide-1-new-100x50.jpg"
                                        data-rotate="0" data-saveperformance="off" data-title="Slide" data-param1=""
                                        data-param2="" data-param3="" data-param4="" data-param5="" data-param6=""
                                        data-param7="" data-param8="" data-param9="" data-param10=""
                                        data-description="" class="tp-revslider-slidesli"
                                        style="width: 100%; height: 100%; overflow: hidden; z-index: 18; visibility: hidden; opacity: 0; background-color: rgba(255, 255, 255, 0);">
                                        <!-- MAIN IMAGE -->
                                        <div class="slotholder"
                                             style="width: 100%; height: 100%; visibility: inherit; opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);">
                                            <!--Runtime Modification - Img tag is Still Available for SEO Goals in Source - <img src="http://libero.mikado-themes.com/wp-content/uploads/2015/12/h4-slide-1-new.jpg" alt="a" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg defaultimg" data-no-retina="" width="1920" height="1200">-->
                                            <div class="tp-bgimg defaultimg"
                                                 style="background-color: transparent; background-repeat: no-repeat; background-image: url(&quot;http://libero.mikado-themes.com/wp-content/uploads/2015/12/h4-slide-1-new.jpg&quot;); background-size: cover; background-position: center center; width: 100%; height: 100%; opacity: 1; visibility: inherit; z-index: 20;"
                                                 src="http://libero.mikado-themes.com/wp-content/uploads/2015/12/h4-slide-1-new.jpg"></div>
                                        </div>
                                        <!-- LAYERS -->

                                        <!-- LAYER NR. 1 -->
                                        <div class="tp-parallax-wrap"
                                             style="position: absolute; visibility: hidden; left: 455px; top: 76px; z-index: 5;">
                                            <div class="tp-loop-wrap" style="position:absolute;">
                                                <div class="tp-mask-wrap"
                                                     style="position: absolute; overflow: visible; height: auto; width: auto;">
                                                    <div class="tp-caption   tp-resizeme" id="slide-11-layer-1"
                                                         data-x="['center','center','center','center']"
                                                         data-hoffset="['0','0','0','0']"
                                                         data-y="['top','top','top','top']"
                                                         data-voffset="['130','78','200','160']" data-width="none"
                                                         data-height="none" data-whitespace="nowrap"
                                                         data-transform_idle="o:1;"
                                                         data-transform_in="y:top;s:150;e:Power2.easeInOut;"
                                                         data-transform_out="opacity:0;s:300;s:300;"
                                                         data-start="1200" data-responsive_offset="on"
                                                         style="z-index: 5; visibility: hidden; transition: none 0s ease 0s ; line-height: 17px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 8px; white-space: nowrap; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 0; transform-origin: 50% 50% 0px; transform: translate3d(0px, 0px, 0px);">
                                                        <img src="/image/h4-graphic-1.png"
                                                             alt=""
                                                             data-ww="['754px','754px','680px','449.7354497354497']"
                                                             data-hh="['209px','209px','189','125']"
                                                             data-no-retina=""
                                                             style="width: 438.675px; height: 121.596px; transition: none 0s ease 0s ; line-height: 17px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 8px;"
                                                             width="754" height="209">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- LAYER NR. 2 -->
                                        <div class="tp-parallax-wrap"
                                             style="position: absolute; visibility: hidden; left: 392px; top: 204px; z-index: 6;">
                                            <div class="tp-loop-wrap" style="position:absolute;">
                                                <div class="tp-mask-wrap"
                                                     style="position: absolute; overflow: visible; height: auto; width: auto;">
                                                    <div class="tp-caption Title   tp-resizeme"
                                                         id="slide-11-layer-3"
                                                         data-x="['center','center','center','center']"
                                                         data-hoffset="['0','0','0','0']"
                                                         data-y="['middle','middle','middle','middle']"
                                                         data-voffset="['-30','-30','-30','0']"
                                                         data-fontsize="['95','95','70','40']"
                                                         data-lineheight="['95','95','80','50']"
                                                         data-width="['973','973','973','518']"
                                                         data-height="['106','106','106','121']"
                                                         data-whitespace="normal" data-transform_idle="o:1;"
                                                         data-transform_in="opacity:0;s:1300;e:Power2.easeInOut;"
                                                         data-transform_out="opacity:0;s:300;s:300;"
                                                         data-start="500" data-splitin="none" data-splitout="none"
                                                         data-responsive_offset="on"
                                                         style="z-index: 6; min-width: 566px; max-width: 566px; white-space: normal; font-size: 55px; line-height: 55px; text-align: center; visibility: hidden; transition: none 0s ease 0s ; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 900; min-height: 62px; max-height: 62px; opacity: 0; transform: translate3d(0px, 0px, 0px); transform-origin: 50% 50% 0px;">
                                                        You Deserve The Best Defence Lawyers
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- LAYER NR. 3 -->
                                        <div class="tp-parallax-wrap"
                                             style="position: absolute; visibility: hidden; left: 455px; top: 337px; z-index: 7;">
                                            <div class="tp-loop-wrap" style="position:absolute;">
                                                <div class="tp-mask-wrap"
                                                     style="position: absolute; overflow: visible; height: auto; width: auto;">
                                                    <div class="tp-caption tp-shape tp-shapewrapper  tp-resizeme"
                                                         id="slide-11-layer-2"
                                                         data-x="['center','center','center','center']"
                                                         data-hoffset="['0','0','0','0']"
                                                         data-y="['middle','middle','middle','middle']"
                                                         data-voffset="['146','146','115','59']"
                                                         data-width="['755','755','680','449']" data-height="1"
                                                         data-whitespace="nowrap" data-transform_idle="o:1;"
                                                         data-transform_in="y:bottom;s:150;e:Power2.easeInOut;"
                                                         data-transform_out="opacity:0;s:300;s:300;"
                                                         data-start="1600" data-responsive_offset="on"
                                                         style="z-index: 7; background-color: rgb(189, 142, 85); border-color: rgba(0, 0, 0, 0.5); visibility: hidden; transition: none 0s ease 0s ; line-height: 17px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 8px; white-space: nowrap; min-height: 1px; min-width: 439px; max-height: 1px; max-width: 439px; opacity: 0; transform-origin: 50% 50% 0px; transform: translate3d(0px, 0px, 0px);">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- LAYER NR. 4 -->
                                        <div class="tp-parallax-wrap"
                                             style="position: absolute; visibility: hidden; left: 529px; top: 356px; z-index: 8;">
                                            <div class="tp-loop-wrap" style="position:absolute;">
                                                <div class="tp-mask-wrap"
                                                     style="position: absolute; overflow: visible; height: auto; width: auto;">
                                                    <div class="tp-caption Small-Subtitle   tp-resizeme"
                                                         id="slide-11-layer-4"
                                                         data-x="['center','center','center','center']"
                                                         data-hoffset="['0','0','0','0']"
                                                         data-y="['middle','middle','middle','middle']"
                                                         data-voffset="['192','192','166','100']"
                                                         data-fontsize="['19','19','19','16']"
                                                         data-lineheight="['29','29','29','26']" data-width="none"
                                                         data-height="none" data-whitespace="nowrap"
                                                         data-transform_idle="o:1;"
                                                         data-transform_in="y:bottom;s:150;e:Power2.easeInOut;"
                                                         data-transform_out="opacity:0;s:300;s:300;"
                                                         data-start="1600" data-splitin="none" data-splitout="none"
                                                         data-responsive_offset="on"
                                                         style="z-index: 8; white-space: nowrap; font-size: 11px; line-height: 17px; visibility: hidden; transition: none 0s ease 0s ; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 900; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 0; transform-origin: 50% 50% 0px; transform: translate3d(0px, 0px, 0px);">
                                                        WITH OVER 35 YEARS OF LAW PRACTICE IN USA COURTS
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                    <!-- SLIDE  -->
                                    <li data-index="rs-25" data-transition="fade" data-slotamount="default"
                                        data-easein="default" data-easeout="default" data-masterspeed="300"
                                        data-thumb="http://libero.mikado-themes.com/wp-content/uploads/2015/11/h8-slide-1-new-100x50.jpg"
                                        data-rotate="0" data-saveperformance="off" data-title="h7-slide-2"
                                        data-param1="" data-param2="" data-param3="" data-param4="" data-param5=""
                                        data-param6="" data-param7="" data-param8="" data-param9="" data-param10=""
                                        data-description="" class="tp-revslider-slidesli"
                                        style="width: 100%; height: 100%; overflow: hidden; z-index: 18; visibility: hidden; opacity: 0; background-color: rgba(255, 255, 255, 0);">
                                        <!-- MAIN IMAGE -->
                                        <div class="slotholder"
                                             style="width: 100%; height: 100%; visibility: inherit; opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);">
                                            <!--Runtime Modification - Img tag is Still Available for SEO Goals in Source - <img src="http://libero.mikado-themes.com/wp-content/uploads/2015/11/h8-slide-1-new.jpg" alt="" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg defaultimg" data-no-retina="" width="1920" height="1050">-->
                                            <div class="tp-bgimg defaultimg"
                                                 style="background-color: transparent; background-repeat: no-repeat; background-image: url(&quot;http://libero.mikado-themes.com/wp-content/uploads/2015/11/h8-slide-1-new.jpg&quot;); background-size: cover; background-position: center center; width: 100%; height: 100%; opacity: 1; visibility: inherit; z-index: 20;"
                                                 src="http://libero.mikado-themes.com/wp-content/uploads/2015/11/h8-slide-1-new.jpg"></div>
                                        </div>
                                        <!-- LAYERS -->

                                        <!-- LAYER NR. 1 -->
                                        <div class="tp-parallax-wrap"
                                             style="position: absolute; visibility: hidden; left: 418px; top: 173px; z-index: 5;">
                                            <div class="tp-loop-wrap" style="position:absolute;">
                                                <div class="tp-mask-wrap"
                                                     style="position: absolute; overflow: visible; height: auto; width: auto;">
                                                    <div class="tp-caption   tp-resizeme" id="slide-25-layer-6"
                                                         data-x="['center','center','center','center']"
                                                         data-hoffset="['-15','-16','-36','-36']"
                                                         data-y="['top','top','top','top']"
                                                         data-voffset="['298','203','373','373']" data-width="none"
                                                         data-height="none" data-whitespace="nowrap"
                                                         data-transform_idle="o:1;"
                                                         data-transform_in="opacity:0;s:700;e:Power2.easeInOut;"
                                                         data-transform_out="opacity:0;s:500;s:500;"
                                                         data-start="1400" data-responsive_offset="on"
                                                         data-end="4700"
                                                         style="z-index: 5; visibility: hidden; transition: none 0s ease 0s ; line-height: 17px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 8px; white-space: nowrap; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 0; transform: translate3d(0px, 0px, 0px); transform-origin: 50% 50% 0px;">
                                                        <img src="/image/h8-graphic-2-slide-1.png"
                                                             alt="a"
                                                             data-ww="['852px','852px','537.8407079646017','537.8407079646017']"
                                                             data-hh="['339px','339px','214','214']"
                                                             data-no-retina=""
                                                             style="width: 495.691px; height: 197.229px; transition: none 0s ease 0s ; line-height: 17px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 8px;"
                                                             width="852" height="339">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- LAYER NR. 2 -->
                                        <div class="tp-parallax-wrap"
                                             style="position: absolute; visibility: hidden; left: 631px; top: 99px; z-index: 6;">
                                            <div class="tp-loop-wrap" style="position:absolute;">
                                                <div class="tp-mask-wrap"
                                                     style="position: absolute; overflow: visible; height: auto; width: auto;">
                                                    <div class="tp-caption   tp-resizeme" id="slide-25-layer-5"
                                                         data-x="['center','center','center','center']"
                                                         data-hoffset="['0','0','0','2']"
                                                         data-y="['top','top','top','top']"
                                                         data-voffset="['170','100','235','160']" data-width="none"
                                                         data-height="none" data-whitespace="nowrap"
                                                         data-transform_idle="o:1;"
                                                         data-transform_in="y:-50px;opacity:0;s:300;e:Power2.easeInOut;"
                                                         data-transform_out="y:50px;opacity:0;s:300;e:Power2.easeInOut;s:300;e:Power2.easeInOut;"
                                                         data-start="1300" data-responsive_offset="on"
                                                         data-end="5400"
                                                         style="z-index: 6; visibility: hidden; transition: none 0s ease 0s ; line-height: 17px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 8px; white-space: nowrap; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 0; transform: translate3d(0px, 29.0899px, 0px); transform-origin: 50% 50% 0px;">
                                                        <img src="/image/h8-graphic-1-slide-1.png"
                                                             alt="a" data-ww="['149px','149px','149px','149px']"
                                                             data-hh="['130px','130px','130px','130px']"
                                                             data-no-retina=""
                                                             style="width: 86.6878px; height: 75.6336px; transition: none 0s ease 0s ; line-height: 17px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 8px;"
                                                             width="149" height="130">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- LAYER NR. 3 -->
                                        <div class="tp-parallax-wrap"
                                             style="position: absolute; visibility: hidden; left: 484px; top: 175px; z-index: 7;">
                                            <div class="tp-loop-wrap" style="position:absolute;">
                                                <div class="tp-mask-wrap"
                                                     style="position: absolute; overflow: visible; height: auto; width: auto;">
                                                    <div class="tp-caption Title   tp-resizeme"
                                                         id="slide-25-layer-2"
                                                         data-x="['center','center','center','center']"
                                                         data-hoffset="['-4','-4','-3','-3']"
                                                         data-y="['top','top','middle','middle']"
                                                         data-voffset="['300','225','-75','-35']"
                                                         data-fontsize="['83','73','43','35']"
                                                         data-lineheight="['93','83','53','45']" data-width="none"
                                                         data-height="none" data-whitespace="nowrap"
                                                         data-transform_idle="o:1;"
                                                         data-transform_in="y:-50px;opacity:0;s:200;e:Power2.easeInOut;"
                                                         data-transform_out="y:50px;opacity:0;s:200;s:200;"
                                                         data-start="1100" data-splitin="none" data-splitout="none"
                                                         data-responsive_offset="on" data-end="5300"
                                                         style="z-index: 7; white-space: nowrap; font-size: 48px; line-height: 54px; visibility: hidden; transition: none 0s ease 0s ; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 900; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 0; transform: translate3d(0px, 29.0899px, 0px); transform-origin: 50% 50% 0px;">
                                                        We are experts in
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- LAYER NR. 4 -->
                                        <div class="tp-parallax-wrap"
                                             style="position: absolute; visibility: hidden; left: 339px; top: 227px; z-index: 8;">
                                            <div class="tp-loop-wrap" style="position:absolute;">
                                                <div class="tp-mask-wrap"
                                                     style="position: absolute; overflow: visible; height: auto; width: auto;">
                                                    <div class="tp-caption Title   tp-resizeme"
                                                         id="slide-25-layer-1"
                                                         data-x="['center','center','center','center']"
                                                         data-hoffset="['0','0','0','0']"
                                                         data-y="['middle','middle','middle','middle']"
                                                         data-voffset="['30','-10','0','20']"
                                                         data-fontsize="['138','128','85','55']"
                                                         data-lineheight="['148','138','95','65']" data-width="none"
                                                         data-height="none" data-whitespace="nowrap"
                                                         data-transform_idle="o:1;"
                                                         data-transform_in="y:-50px;opacity:0;s:200;e:Power2.easeInOut;"
                                                         data-transform_out="y:50px;opacity:0;s:200;s:200;"
                                                         data-start="900" data-splitin="none" data-splitout="none"
                                                         data-responsive_offset="on" data-end="5100"
                                                         style="z-index: 8; white-space: nowrap; font-size: 80px; line-height: 86px; visibility: hidden; transition: none 0s ease 0s ; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 900; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 0; transform: translate3d(0px, 29.0899px, 0px); transform-origin: 50% 50% 0px;">
                                                        Business litigation
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- LAYER NR. 5 -->
                                        <div class="tp-parallax-wrap"
                                             style="position: absolute; visibility: hidden; left: 516px; top: 325px; z-index: 9;">
                                            <div class="tp-loop-wrap" style="position:absolute;">
                                                <div class="tp-mask-wrap"
                                                     style="position: absolute; overflow: visible; height: auto; width: auto;">
                                                    <div class="tp-caption Small-Subtitle   tp-resizeme"
                                                         id="slide-25-layer-3"
                                                         data-x="['center','center','center','center']"
                                                         data-hoffset="['0','0','0','0']"
                                                         data-y="['middle','middle','middle','middle']"
                                                         data-voffset="['140','100','78','78']"
                                                         data-fontsize="['20','20','20','15']"
                                                         data-lineheight="['30','30','30','25']" data-width="none"
                                                         data-height="none" data-whitespace="nowrap"
                                                         data-transform_idle="o:1;"
                                                         data-transform_in="y:-50px;opacity:0;s:200;e:Power2.easeInOut;"
                                                         data-transform_out="y:50px;opacity:0;s:200;s:200;"
                                                         data-start="700" data-splitin="none" data-splitout="none"
                                                         data-responsive_offset="on" data-end="4900"
                                                         style="z-index: 9; white-space: nowrap; font-size: 12px; line-height: 17px; visibility: hidden; transition: none 0s ease 0s ; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 900; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 0; transform: translate3d(0px, 29.0899px, 0px); transform-origin: 50% 50% 0px;">
                                                        WITH OVER 35 YEARS OF LAW PRACTICE IN USA COURTS
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- LAYER NR. 6 -->
                                        <div class="tp-parallax-wrap"
                                             style="position: absolute; visibility: hidden; left: 583px; top: 353px; z-index: 10;">
                                            <div class="tp-loop-wrap" style="position:absolute;">
                                                <div class="tp-mask-wrap"
                                                     style="position: absolute; overflow: visible; height: auto; width: auto;">
                                                    <div class="tp-caption Button-Style" id="slide-25-layer-4"
                                                         data-x="['center','center','center','center']"
                                                         data-hoffset="['0','0','0','0']"
                                                         data-y="['middle','middle','middle','middle']"
                                                         data-voffset="['210','160','140','140']" data-width="none"
                                                         data-height="none" data-whitespace="nowrap"
                                                         data-visibility="['on','on','on','off']"
                                                         data-transform_idle="o:1;"
                                                         data-transform_in="y:-50px;opacity:0;s:200;e:Power2.easeInOut;"
                                                         data-transform_out="y:50px;opacity:0;s:200;s:200;"
                                                         data-start="500" data-splitin="none" data-splitout="none"
                                                         data-responsive_offset="on" data-end="4700"
                                                         style="z-index: 10; white-space: nowrap; letter-spacing: 0px; visibility: hidden; transition: none 0s ease 0s ; line-height: 10px; border-width: 0px; margin: 0px; padding: 0px; font-weight: 900; font-size: 6px; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 0; transform: translate3d(0px, 29.0899px, 0px); transform-origin: 50% 50% 0px;">
                                                        <a href="#" target="_self" style="font-weight: 700"
                                                           class="mkd-btn mkd-btn-medium mkd-btn-solid mkd-btn-icon">
                                                            <span class="mkd-btn-text">Contact us now</span><span
                                                                    class="mkd-btn-icon-holder">
            <span aria-hidden="true" class="mkd-icon-font-elegant arrow_carrot-right mkd-btn-icon-elem"></span>            <span
                                                                        aria-hidden="true"
                                                                        class="mkd-icon-font-elegant arrow_carrot-right mkd-btn-icon-elem"></span>        </span>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                    <!-- SLIDE  -->
                                    <li data-index="rs-26" data-transition="fade" data-slotamount="default"
                                        data-easein="default" data-easeout="default" data-masterspeed="300"
                                        data-thumb="http://libero.mikado-themes.com/wp-content/uploads/2015/12/h7-s3-img-100x50.jpg"
                                        data-rotate="0" data-saveperformance="off" data-title="h7-slide-3"
                                        data-param1="" data-param2="" data-param3="" data-param4="" data-param5=""
                                        data-param6="" data-param7="" data-param8="" data-param9="" data-param10=""
                                        data-description="" class="tp-revslider-slidesli"
                                        style="width: 100%; height: 100%; overflow: hidden; z-index: 18; visibility: hidden; opacity: 0; background-color: rgba(255, 255, 255, 0);">
                                        <!-- MAIN IMAGE -->
                                        <div class="slotholder"
                                             style="width: 100%; height: 100%; visibility: inherit; opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);">
                                            <!--Runtime Modification - Img tag is Still Available for SEO Goals in Source - <img src="http://libero.mikado-themes.com/wp-content/uploads/2015/12/h7-s3-img.jpg" alt="" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg defaultimg" data-no-retina="" width="1920" height="1200">-->
                                            <div class="tp-bgimg defaultimg"
                                                 style="background-color: transparent; background-repeat: no-repeat; background-image: url(&quot;http://libero.mikado-themes.com/wp-content/uploads/2015/12/h7-s3-img.jpg&quot;); background-size: cover; background-position: center center; width: 100%; height: 100%; opacity: 1; visibility: inherit; z-index: 20;"
                                                 src="http://libero.mikado-themes.com/wp-content/uploads/2015/12/h7-s3-img.jpg"></div>
                                        </div>
                                        <!-- LAYERS -->

                                        <!-- LAYER NR. 1 -->
                                        <div class="tp-parallax-wrap"
                                             style="position: absolute; visibility: hidden; left: 620px; top: 116px; z-index: 5;">
                                            <div class="tp-loop-wrap" style="position:absolute;">
                                                <div class="tp-mask-wrap"
                                                     style="position: absolute; overflow: visible; height: auto; width: auto;">
                                                    <div class="tp-caption   tp-resizeme" id="slide-26-layer-1"
                                                         data-x="['center','center','center','center']"
                                                         data-hoffset="['0','0','0','0']"
                                                         data-y="['top','top','top','top']"
                                                         data-voffset="['200','200','320','254']" data-width="none"
                                                         data-height="none" data-whitespace="nowrap"
                                                         data-transform_idle="o:1;"
                                                         data-transform_in="y:-50px;opacity:0;s:300;e:Power2.easeInOut;"
                                                         data-transform_out="y:50px;opacity:0;s:300;s:300;"
                                                         data-start="1300" data-splitin="none" data-splitout="none"
                                                         data-responsive_offset="on" data-end="5400"
                                                         style="z-index: 5; white-space: nowrap; font-size: 22px; line-height: 26px; font-weight: 400; color: rgb(207, 148, 85); font-family: Dynalight; visibility: hidden; transition: none 0s ease 0s ; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 0; transform: translate3d(0px, 29.0899px, 0px); transform-origin: 50% 50% 0px;">
                                                        quickest response
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- LAYER NR. 2 -->
                                        <div class="tp-parallax-wrap"
                                             style="position: absolute; visibility: hidden; left: 439px; top: 145px; z-index: 6;">
                                            <div class="tp-loop-wrap" style="position:absolute;">
                                                <div class="tp-mask-wrap"
                                                     style="position: absolute; overflow: visible; height: auto; width: auto;">
                                                    <div class="tp-caption   tp-resizeme" id="slide-26-layer-2"
                                                         data-x="['center','center','center','center']"
                                                         data-hoffset="['0','0','0','0']"
                                                         data-y="['top','top','middle','middle']"
                                                         data-voffset="['250','250','-75','-35']"
                                                         data-fontsize="['83','63','43','35']"
                                                         data-lineheight="['90','73','53','45']" data-width="none"
                                                         data-height="none" data-whitespace="nowrap"
                                                         data-transform_idle="o:1;"
                                                         data-transform_in="y:-50px;opacity:0;s:200;e:Power2.easeInOut;"
                                                         data-transform_out="y:50px;opacity:0;s:200;s:200;"
                                                         data-start="1100" data-splitin="none" data-splitout="none"
                                                         data-responsive_offset="on" data-end="5300"
                                                         style="z-index: 6; white-space: nowrap; font-size: 48px; line-height: 52px; font-weight: 900; color: rgb(255, 255, 255); font-family: roboto; visibility: hidden; transition: none 0s ease 0s ; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 0; transform: translate3d(0px, 29.0899px, 0px); transform-origin: 50% 50% 0px;">
                                                        We guide you through
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- LAYER NR. 3 -->
                                        <div class="tp-parallax-wrap"
                                             style="position: absolute; visibility: hidden; left: 302px; top: 198px; z-index: 7;">
                                            <div class="tp-loop-wrap" style="position:absolute;">
                                                <div class="tp-mask-wrap"
                                                     style="position: absolute; overflow: visible; height: auto; width: auto;">
                                                    <div class="tp-caption   tp-resizeme" id="slide-26-layer-3"
                                                         data-x="['center','center','center','center']"
                                                         data-hoffset="['0','0','0','0']"
                                                         data-y="['top','top','middle','middle']"
                                                         data-voffset="['340','330','0','20']"
                                                         data-fontsize="['138','115','80','50']"
                                                         data-lineheight="['145','125','95','65']" data-width="none"
                                                         data-height="none" data-whitespace="nowrap"
                                                         data-transform_idle="o:1;"
                                                         data-transform_in="y:-50px;opacity:0;s:200;e:Power2.easeInOut;"
                                                         data-transform_out="y:50px;opacity:0;s:200;s:200;"
                                                         data-start="900" data-splitin="none" data-splitout="none"
                                                         data-responsive_offset="on" data-end="5100"
                                                         style="z-index: 7; white-space: nowrap; font-size: 80px; line-height: 84px; font-weight: 900; color: rgb(255, 255, 255); font-family: roboto; visibility: hidden; transition: none 0s ease 0s ; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 0; transform: translate3d(0px, 29.0899px, 0px); transform-origin: 50% 50% 0px;">
                                                        Bankrupcy problems
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- LAYER NR. 4 -->
                                        <div class="tp-parallax-wrap"
                                             style="position: absolute; visibility: hidden; left: 516px; top: 297px; z-index: 8;">
                                            <div class="tp-loop-wrap" style="position:absolute;">
                                                <div class="tp-mask-wrap"
                                                     style="position: absolute; overflow: visible; height: auto; width: auto;">
                                                    <div class="tp-caption   tp-resizeme" id="slide-26-layer-4"
                                                         data-x="['center','center','center','center']"
                                                         data-hoffset="['0','0','0','0']"
                                                         data-y="['top','top','middle','middle']"
                                                         data-voffset="['510','500','78','78']"
                                                         data-fontsize="['20','20','20','15']" data-width="none"
                                                         data-height="none" data-whitespace="nowrap"
                                                         data-transform_idle="o:1;"
                                                         data-transform_in="y:-50px;opacity:0;s:200;e:Power2.easeInOut;"
                                                         data-transform_out="y:50px;opacity:0;s:200;s:200;"
                                                         data-start="700" data-splitin="none" data-splitout="none"
                                                         data-responsive_offset="on" data-end="4900"
                                                         style="z-index: 8; white-space: nowrap; font-size: 12px; line-height: 15px; font-weight: 900; color: rgb(255, 255, 255); font-family: roboto; visibility: hidden; transition: none 0s ease 0s ; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 0; transform: translate3d(0px, 29.0899px, 0px); transform-origin: 50% 50% 0px;">
                                                        WITH OVER 35 YEARS OF LAW PRACTICE IN USA COURTS
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- LAYER NR. 5 -->
                                        <div class="tp-parallax-wrap"
                                             style="position: absolute; visibility: hidden; left: 583px; top: 332px; z-index: 9;">
                                            <div class="tp-loop-wrap" style="position:absolute;">
                                                <div class="tp-mask-wrap"
                                                     style="position: absolute; overflow: visible; height: auto; width: auto;">
                                                    <div class="tp-caption Button-Style" id="slide-26-layer-5"
                                                         data-x="['center','center','center','center']"
                                                         data-hoffset="['0','0','0','0']"
                                                         data-y="['top','top','middle','middle']"
                                                         data-voffset="['570','561','140','140']" data-width="none"
                                                         data-height="none" data-whitespace="nowrap"
                                                         data-visibility="['on','on','on','off']"
                                                         data-transform_idle="o:1;"
                                                         data-transform_in="y:-50px;opacity:0;s:200;e:Power2.easeInOut;"
                                                         data-transform_out="y:50px;opacity:0;s:200;s:200;"
                                                         data-start="500" data-splitin="none" data-splitout="none"
                                                         data-responsive_offset="on" data-end="4700"
                                                         style="z-index: 9; white-space: nowrap; visibility: hidden; transition: none 0s ease 0s ; line-height: 10px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 900; font-size: 6px; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 0; transform: translate3d(0px, 29.0899px, 0px); transform-origin: 50% 50% 0px;">
                                                        <a href="#" target="_self" style="font-weight: 700"
                                                           class="mkd-btn mkd-btn-medium mkd-btn-solid mkd-btn-icon">
                                                            <span class="mkd-btn-text">Contact us now</span><span
                                                                    class="mkd-btn-icon-holder">
            <span aria-hidden="true" class="mkd-icon-font-elegant arrow_carrot-right mkd-btn-icon-elem"></span>            <span
                                                                        aria-hidden="true"
                                                                        class="mkd-icon-font-elegant arrow_carrot-right mkd-btn-icon-elem"></span>        </span>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                    <!-- SLIDE  -->
                                    <li data-index="rs-24" data-transition="fade" data-slotamount="default"
                                        data-easein="default" data-easeout="default" data-masterspeed="300"
                                        data-thumb="http://libero.mikado-themes.com/wp-content/uploads/2015/12/video-background-100x50.jpg"
                                        data-rotate="0" data-saveperformance="off" data-title="h7-slide-1"
                                        data-param1="" data-param2="" data-param3="" data-param4="" data-param5=""
                                        data-param6="" data-param7="" data-param8="" data-param9="" data-param10=""
                                        data-description=""
                                        class="tp-revslider-slidesli rs-pause-timer-always active-revslide"
                                        style="width: 100%; height: 100%; overflow: hidden; z-index: 20; visibility: inherit; opacity: 1; background-color: rgba(255, 255, 255, 0);">
                                        <!-- MAIN IMAGE -->
                                        <div class="slotholder"
                                             style="width: 100%; height: 100%; visibility: inherit; opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);">
                                            <!--Runtime Modification - Img tag is Still Available for SEO Goals in Source - <img src="http://libero.mikado-themes.com/wp-content/uploads/2015/12/video-background.jpg" alt="a" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg defaultimg" data-no-retina="" width="1920" height="1057">-->
                                            <div class="rs-background-video-layer defaultvid HasListener videoisplaying"
                                                 data-forcerewind="on" data-volume="mute" data-videowidth="100%"
                                                 data-videoheight="100%"
                                                 data-videoogv="http://libero.mikado-themes.com/wp-content/uploads/2015/12/lawyer.ogv"
                                                 data-videowebm="http://libero.mikado-themes.com/wp-content/uploads/2015/12/lawyer.webm"
                                                 data-videomp4="http://libero.mikado-themes.com/wp-content/uploads/2015/12/lawyer.mpg"
                                                 data-videopreload="preload" data-videoloop="none"
                                                 data-dottedoverlay="twoxtwo" data-forcecover="1"
                                                 data-aspectratio="16:9" data-autoplay="true"
                                                 data-autoplayonlyfirsttime="false" data-nextslideatend="true"
                                                 style="z-index: 30; left: 0px; top: 0px; transform: matrix(1, 0, 0, 1, 0, 0); visibility: inherit; opacity: 1;">
                                                <div class="html5vid fullcoveredvideo"
                                                     style="position:relative;top:0px;left:0px;width:100%;height:100%; overflow:hidden;">
                                                    <video style="object-fit: cover; background-size: cover; width: 100%; height: 150.26%; visibility: inherit; opacity: 1; position: absolute; left: 0px; top: -25.1299%; display: block;"
                                                           class="" preload="undefined">
                                                        <source src="/image/lawyer.webm"
                                                                type="video/webm">
                                                        <source src="/image/lawyer.mpeg"
                                                                type="video/mp4">
                                                        <source src="/image/lawyer.ogv"
                                                                type="video/ogg">
                                                    </video>
                                                </div>
                                                <div class="tp-video-play-button"><i
                                                            class="revicon-right-dir"></i><span class="tp-revstop">&nbsp;</span>
                                                </div>
                                                <div class="tp-dottedoverlay twoxtwo"></div>
                                                <div class="rs-fullvideo-cover"></div>
                                            </div>
                                            <div class="tp-bgimg defaultimg"
                                                 style="background-color: transparent; background-repeat: no-repeat; background-image: url(&quot;http://libero.mikado-themes.com/wp-content/uploads/2015/12/video-background.jpg&quot;); background-size: cover; background-position: center center; width: 100%; height: 100%; opacity: 1; visibility: inherit; z-index: 20;"
                                                 src="http://libero.mikado-themes.com/wp-content/uploads/2015/12/video-background.jpg"></div>
                                        </div>
                                        <!-- LAYERS -->

                                        <!-- BACKGROUND VIDEO LAYER -->

                                        <!-- LAYER NR. 1 -->
                                        <div class="tp-parallax-wrap"
                                             style="position: absolute; visibility: hidden; left: 418px; top: 173px; z-index: 5;">
                                            <div class="tp-loop-wrap" style="position:absolute;">
                                                <div class="tp-mask-wrap"
                                                     style="position: absolute; overflow: visible; height: auto; width: auto;">
                                                    <div class="tp-caption   tp-resizeme" id="slide-24-layer-6"
                                                         data-x="['center','center','center','center']"
                                                         data-hoffset="['-15','-16','-36','-36']"
                                                         data-y="['top','top','top','top']"
                                                         data-voffset="['298','221','373','373']" data-width="none"
                                                         data-height="none" data-whitespace="nowrap"
                                                         data-transform_idle="o:1;"
                                                         data-transform_in="opacity:0;s:700;e:Power2.easeInOut;"
                                                         data-transform_out="opacity:0;s:500;s:500;"
                                                         data-start="1400" data-responsive_offset="on"
                                                         data-end="4700"
                                                         style="z-index: 5; visibility: hidden; transition: none 0s ease 0s ; line-height: 17px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 8px; white-space: nowrap; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 0; transform: translate3d(0px, 0px, 0px); transform-origin: 50% 50% 0px;">
                                                        <img src="/image/h8-graphic-2-slide-1.png"
                                                             alt="a"
                                                             data-ww="['852px','852px','537.8407079646017','537.8407079646017']"
                                                             data-hh="['339px','339px','214','214']"
                                                             data-no-retina=""
                                                             style="width: 495.691px; height: 197.229px; transition: none 0s ease 0s ; line-height: 17px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 8px;"
                                                             width="852" height="339">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- LAYER NR. 2 -->
                                        <div class="tp-parallax-wrap"
                                             style="position: absolute; visibility: hidden; left: 631px; top: 99px; z-index: 6;">
                                            <div class="tp-loop-wrap" style="position:absolute;">
                                                <div class="tp-mask-wrap"
                                                     style="position: absolute; overflow: visible; height: auto; width: auto;">
                                                    <div class="tp-caption   tp-resizeme" id="slide-24-layer-5"
                                                         data-x="['center','center','center','center']"
                                                         data-hoffset="['0','0','0','2']"
                                                         data-y="['top','top','top','top']"
                                                         data-voffset="['170','100','235','160']" data-width="none"
                                                         data-height="none" data-whitespace="nowrap"
                                                         data-transform_idle="o:1;"
                                                         data-transform_in="y:-50px;opacity:0;s:300;e:Power2.easeInOut;"
                                                         data-transform_out="y:50px;opacity:0;s:300;e:Power2.easeInOut;s:300;e:Power2.easeInOut;"
                                                         data-start="1300" data-responsive_offset="on"
                                                         data-end="5400"
                                                         style="z-index: 6; visibility: hidden; transition: none 0s ease 0s ; line-height: 17px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 8px; white-space: nowrap; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 0; transform: translate3d(0px, 29.0899px, 0px); transform-origin: 50% 50% 0px;">
                                                        <img src="/image/h8-graphic-1-slide-1.png"
                                                             alt="a" data-ww="['149px','149px','149px','149px']"
                                                             data-hh="['130px','130px','130px','130px']"
                                                             data-no-retina=""
                                                             style="width: 86.6878px; height: 75.6336px; transition: none 0s ease 0s ; line-height: 17px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 8px;"
                                                             width="149" height="130">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- LAYER NR. 3 -->
                                        <div class="tp-parallax-wrap"
                                             style="position: absolute; visibility: hidden; left: 484px; top: 175px; z-index: 7;">
                                            <div class="tp-loop-wrap" style="position:absolute;">
                                                <div class="tp-mask-wrap"
                                                     style="position: absolute; overflow: visible; height: auto; width: auto;">
                                                    <div class="tp-caption Title   tp-resizeme"
                                                         id="slide-24-layer-2"
                                                         data-x="['center','center','center','center']"
                                                         data-hoffset="['-4','0','-3','-3']"
                                                         data-y="['top','top','middle','middle']"
                                                         data-voffset="['300','225','-75','-35']"
                                                         data-fontsize="['83','73','43','35']"
                                                         data-lineheight="['93','83','53','45']" data-width="none"
                                                         data-height="none" data-whitespace="nowrap"
                                                         data-transform_idle="o:1;"
                                                         data-transform_in="y:-50px;opacity:0;s:200;e:Power2.easeInOut;"
                                                         data-transform_out="y:50px;opacity:0;s:200;s:200;"
                                                         data-start="1100" data-splitin="none" data-splitout="none"
                                                         data-responsive_offset="on" data-end="5300"
                                                         style="z-index: 7; white-space: nowrap; font-size: 48px; line-height: 54px; visibility: hidden; transition: none 0s ease 0s ; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 900; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 0; transform: translate3d(0px, 29.0899px, 0px); transform-origin: 50% 50% 0px;">
                                                        We are experts in
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- LAYER NR. 4 -->
                                        <div class="tp-parallax-wrap"
                                             style="position: absolute; visibility: hidden; left: 339px; top: 227px; z-index: 8;">
                                            <div class="tp-loop-wrap" style="position:absolute;">
                                                <div class="tp-mask-wrap"
                                                     style="position: absolute; overflow: visible; height: auto; width: auto;">
                                                    <div class="tp-caption Title   tp-resizeme"
                                                         id="slide-24-layer-1"
                                                         data-x="['center','center','center','center']"
                                                         data-hoffset="['0','0','0','0']"
                                                         data-y="['middle','middle','middle','middle']"
                                                         data-voffset="['30','-10','0','20']"
                                                         data-fontsize="['138','128','85','55']"
                                                         data-lineheight="['148','138','95','65']" data-width="none"
                                                         data-height="none" data-whitespace="nowrap"
                                                         data-transform_idle="o:1;"
                                                         data-transform_in="y:-50px;opacity:0;s:200;e:Power2.easeInOut;"
                                                         data-transform_out="y:50px;opacity:0;s:200;s:200;"
                                                         data-start="900" data-splitin="none" data-splitout="none"
                                                         data-responsive_offset="on" data-end="5100"
                                                         style="z-index: 8; white-space: nowrap; font-size: 80px; line-height: 86px; visibility: hidden; transition: none 0s ease 0s ; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 900; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 0; transform: translate3d(0px, 29.0899px, 0px); transform-origin: 50% 50% 0px;">
                                                        Business litigation
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- LAYER NR. 5 -->
                                        <div class="tp-parallax-wrap"
                                             style="position: absolute; visibility: hidden; left: 516px; top: 325px; z-index: 9;">
                                            <div class="tp-loop-wrap" style="position:absolute;">
                                                <div class="tp-mask-wrap"
                                                     style="position: absolute; overflow: visible; height: auto; width: auto;">
                                                    <div class="tp-caption Small-Subtitle   tp-resizeme"
                                                         id="slide-24-layer-3"
                                                         data-x="['center','center','center','center']"
                                                         data-hoffset="['0','0','0','0']"
                                                         data-y="['middle','middle','middle','middle']"
                                                         data-voffset="['140','100','78','78']"
                                                         data-fontsize="['20','20','20','15']"
                                                         data-lineheight="['30','30','30','25']" data-width="none"
                                                         data-height="none" data-whitespace="nowrap"
                                                         data-transform_idle="o:1;"
                                                         data-transform_in="y:-50px;opacity:0;s:200;e:Power2.easeInOut;"
                                                         data-transform_out="y:50px;opacity:0;s:200;s:200;"
                                                         data-start="700" data-splitin="none" data-splitout="none"
                                                         data-responsive_offset="on" data-end="4900"
                                                         style="z-index: 9; white-space: nowrap; font-size: 12px; line-height: 17px; visibility: hidden; transition: none 0s ease 0s ; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 900; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 0; transform: translate3d(0px, 29.0899px, 0px); transform-origin: 50% 50% 0px;">
                                                        WITH OVER 35 YEARS OF LAW PRACTICE IN USA COURTS
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- LAYER NR. 6 -->
                                        <div class="tp-parallax-wrap"
                                             style="position: absolute; visibility: hidden; left: 583px; top: 353px; z-index: 10;">
                                            <div class="tp-loop-wrap" style="position:absolute;">
                                                <div class="tp-mask-wrap"
                                                     style="position: absolute; overflow: visible; height: auto; width: auto;">
                                                    <div class="tp-caption Button-Style" id="slide-24-layer-4"
                                                         data-x="['center','center','center','center']"
                                                         data-hoffset="['0','0','0','0']"
                                                         data-y="['middle','middle','middle','middle']"
                                                         data-voffset="['210','160','140','140']" data-width="none"
                                                         data-height="none" data-whitespace="nowrap"
                                                         data-visibility="['on','on','on','off']"
                                                         data-transform_idle="o:1;"
                                                         data-transform_in="y:-50px;opacity:0;s:200;e:Power2.easeInOut;"
                                                         data-transform_out="y:50px;opacity:0;s:200;s:200;"
                                                         data-start="500" data-splitin="none" data-splitout="none"
                                                         data-responsive_offset="on" data-end="4700"
                                                         style="z-index: 10; white-space: nowrap; letter-spacing: 0px; visibility: hidden; transition: none 0s ease 0s ; line-height: 10px; border-width: 0px; margin: 0px; padding: 0px; font-weight: 900; font-size: 6px; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 0; transform: translate3d(0px, 29.0899px, 0px); transform-origin: 50% 50% 0px;">
                                                        <a href="#" target="_self" style="font-weight: 700"
                                                           class="mkd-btn mkd-btn-medium mkd-btn-solid mkd-btn-icon">
                                                            <span class="mkd-btn-text">Contact us now</span><span
                                                                    class="mkd-btn-icon-holder">
            <span aria-hidden="true" class="mkd-icon-font-elegant arrow_carrot-right mkd-btn-icon-elem"></span>            <span
                                                                        aria-hidden="true"
                                                                        class="mkd-icon-font-elegant arrow_carrot-right mkd-btn-icon-elem"></span>        </span>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                    <!-- SLIDE  -->
                                    <li data-index="rs-28" data-transition="fade" data-slotamount="default"
                                        data-easein="default" data-easeout="default" data-masterspeed="300"
                                        data-thumb="http://libero.mikado-themes.com/wp-content/uploads/2015/12/h7-s5-img-100x50.jpg"
                                        data-rotate="0" data-saveperformance="off" data-title="h7-slide-5"
                                        data-param1="" data-param2="" data-param3="" data-param4="" data-param5=""
                                        data-param6="" data-param7="" data-param8="" data-param9="" data-param10=""
                                        data-description="" class="tp-revslider-slidesli"
                                        style="width: 100%; height: 100%; overflow: hidden; z-index: 18; visibility: hidden; opacity: 0; background-color: rgba(255, 255, 255, 0);">
                                        <!-- MAIN IMAGE -->
                                        <div class="slotholder"
                                             style="width: 100%; height: 100%; visibility: inherit; opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);">
                                            <!--Runtime Modification - Img tag is Still Available for SEO Goals in Source - <img src="http://libero.mikado-themes.com/wp-content/uploads/2015/12/h7-s5-img.jpg" alt="a" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg defaultimg" data-no-retina="" width="1920" height="1200">-->
                                            <div class="tp-bgimg defaultimg"
                                                 style="background-color: transparent; background-repeat: no-repeat; background-image: url(&quot;http://libero.mikado-themes.com/wp-content/uploads/2015/12/h7-s5-img.jpg&quot;); background-size: cover; background-position: center center; width: 100%; height: 100%; opacity: 1; visibility: inherit; z-index: 20;"
                                                 src="http://libero.mikado-themes.com/wp-content/uploads/2015/12/h7-s5-img.jpg"></div>
                                        </div>
                                        <!-- LAYERS -->

                                        <!-- LAYER NR. 1 -->
                                        <div class="tp-parallax-wrap"
                                             style="position: absolute; visibility: hidden; left: 622px; top: 116px; z-index: 5;">
                                            <div class="tp-loop-wrap" style="position:absolute;">
                                                <div class="tp-mask-wrap"
                                                     style="position: absolute; overflow: visible; height: auto; width: auto;">
                                                    <div class="tp-caption   tp-resizeme" id="slide-28-layer-1"
                                                         data-x="['center','center','center','center']"
                                                         data-hoffset="['0','0','0','0']"
                                                         data-y="['top','top','top','top']"
                                                         data-voffset="['200','200','320','254']" data-width="none"
                                                         data-height="none" data-whitespace="nowrap"
                                                         data-transform_idle="o:1;"
                                                         data-transform_in="y:-50px;opacity:0;s:300;e:Power2.easeInOut;"
                                                         data-transform_out="y:50px;opacity:0;s:300;s:300;"
                                                         data-start="1300" data-splitin="none" data-splitout="none"
                                                         data-responsive_offset="on" data-end="5400"
                                                         style="z-index: 5; white-space: nowrap; font-size: 22px; line-height: 26px; font-weight: 400; color: rgb(207, 148, 85); font-family: Dynalight; visibility: hidden; transition: none 0s ease 0s ; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 0; transform: translate3d(0px, 29.0899px, 0px); transform-origin: 50% 50% 0px;">
                                                        protecting rights
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- LAYER NR. 2 -->
                                        <div class="tp-parallax-wrap"
                                             style="position: absolute; visibility: hidden; left: 466px; top: 145px; z-index: 6;">
                                            <div class="tp-loop-wrap" style="position:absolute;">
                                                <div class="tp-mask-wrap"
                                                     style="position: absolute; overflow: visible; height: auto; width: auto;">
                                                    <div class="tp-caption   tp-resizeme" id="slide-28-layer-2"
                                                         data-x="['center','center','center','center']"
                                                         data-hoffset="['0','0','0','0']"
                                                         data-y="['top','top','middle','middle']"
                                                         data-voffset="['250','250','-75','-35']"
                                                         data-fontsize="['83','73','43','35']"
                                                         data-lineheight="['90','83','53','45']" data-width="none"
                                                         data-height="none" data-whitespace="nowrap"
                                                         data-transform_idle="o:1;"
                                                         data-transform_in="y:-50px;opacity:0;s:200;e:Power2.easeInOut;"
                                                         data-transform_out="y:50px;opacity:0;s:200;s:200;"
                                                         data-start="1100" data-splitin="none" data-splitout="none"
                                                         data-responsive_offset="on" data-end="5300"
                                                         style="z-index: 6; white-space: nowrap; font-size: 48px; line-height: 52px; font-weight: 900; color: rgb(255, 255, 255); font-family: roboto; visibility: hidden; transition: none 0s ease 0s ; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 0; transform: translate3d(0px, 29.0899px, 0px); transform-origin: 50% 50% 0px;">
                                                        Presentation of the
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- LAYER NR. 3 -->
                                        <div class="tp-parallax-wrap"
                                             style="position: absolute; visibility: hidden; left: 372px; top: 198px; z-index: 7;">
                                            <div class="tp-loop-wrap" style="position:absolute;">
                                                <div class="tp-mask-wrap"
                                                     style="position: absolute; overflow: visible; height: auto; width: auto;">
                                                    <div class="tp-caption   tp-resizeme" id="slide-28-layer-3"
                                                         data-x="['center','center','center','center']"
                                                         data-hoffset="['0','0','0','0']"
                                                         data-y="['top','top','middle','middle']"
                                                         data-voffset="['340','330','0','20']"
                                                         data-fontsize="['138','128','80','50']"
                                                         data-lineheight="['145','138','95','65']" data-width="none"
                                                         data-height="none" data-whitespace="nowrap"
                                                         data-transform_idle="o:1;"
                                                         data-transform_in="y:-50px;opacity:0;s:200;e:Power2.easeInOut;"
                                                         data-transform_out="y:50px;opacity:0;s:200;s:200;"
                                                         data-start="900" data-splitin="none" data-splitout="none"
                                                         data-responsive_offset="on" data-end="5100"
                                                         style="z-index: 7; white-space: nowrap; font-size: 80px; line-height: 84px; font-weight: 900; color: rgb(255, 255, 255); font-family: roboto; visibility: hidden; transition: none 0s ease 0s ; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 0; transform: translate3d(0px, 29.0899px, 0px); transform-origin: 50% 50% 0px;">
                                                        International law
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- LAYER NR. 4 -->
                                        <div class="tp-parallax-wrap"
                                             style="position: absolute; visibility: hidden; left: 516px; top: 297px; z-index: 8;">
                                            <div class="tp-loop-wrap" style="position:absolute;">
                                                <div class="tp-mask-wrap"
                                                     style="position: absolute; overflow: visible; height: auto; width: auto;">
                                                    <div class="tp-caption   tp-resizeme" id="slide-28-layer-4"
                                                         data-x="['center','center','center','center']"
                                                         data-hoffset="['0','0','0','0']"
                                                         data-y="['top','top','middle','middle']"
                                                         data-voffset="['510','510','78','78']"
                                                         data-fontsize="['20','20','20','15']" data-width="none"
                                                         data-height="none" data-whitespace="nowrap"
                                                         data-transform_idle="o:1;"
                                                         data-transform_in="y:-50px;opacity:0;s:200;e:Power2.easeInOut;"
                                                         data-transform_out="y:50px;opacity:0;s:200;s:200;"
                                                         data-start="700" data-splitin="none" data-splitout="none"
                                                         data-responsive_offset="on" data-end="4900"
                                                         style="z-index: 8; white-space: nowrap; font-size: 12px; line-height: 15px; font-weight: 900; color: rgb(255, 255, 255); font-family: roboto; visibility: hidden; transition: none 0s ease 0s ; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 0; transform: translate3d(0px, 29.0899px, 0px); transform-origin: 50% 50% 0px;">
                                                        WITH OVER 35 YEARS OF LAW PRACTICE IN USA COURTS
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- LAYER NR. 5 -->
                                        <div class="tp-parallax-wrap"
                                             style="position: absolute; visibility: hidden; left: 583px; top: 332px; z-index: 9;">
                                            <div class="tp-loop-wrap" style="position:absolute;">
                                                <div class="tp-mask-wrap"
                                                     style="position: absolute; overflow: visible; height: auto; width: auto;">
                                                    <div class="tp-caption Button-Style" id="slide-28-layer-5"
                                                         data-x="['center','center','center','center']"
                                                         data-hoffset="['0','0','0','0']"
                                                         data-y="['top','top','middle','middle']"
                                                         data-voffset="['570','570','140','140']" data-width="none"
                                                         data-height="none" data-whitespace="nowrap"
                                                         data-visibility="['on','on','on','off']"
                                                         data-transform_idle="o:1;"
                                                         data-transform_in="y:-50px;opacity:0;s:200;e:Power2.easeInOut;"
                                                         data-transform_out="y:50px;opacity:0;s:200;s:200;"
                                                         data-start="500" data-splitin="none" data-splitout="none"
                                                         data-responsive_offset="on" data-end="4700"
                                                         style="z-index: 9; white-space: nowrap; visibility: hidden; transition: none 0s ease 0s ; line-height: 10px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 900; font-size: 6px; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 0; transform: translate3d(0px, 29.0899px, 0px); transform-origin: 50% 50% 0px;">
                                                        <a href="#" target="_self" style="font-weight: 700"
                                                           class="mkd-btn mkd-btn-medium mkd-btn-solid mkd-btn-icon">
                                                            <span class="mkd-btn-text">Contact us now</span><span
                                                                    class="mkd-btn-icon-holder">
            <span aria-hidden="true" class="mkd-icon-font-elegant arrow_carrot-right mkd-btn-icon-elem"></span>            <span
                                                                        aria-hidden="true"
                                                                        class="mkd-icon-font-elegant arrow_carrot-right mkd-btn-icon-elem"></span>        </span>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                                <div class="tp-bannertimer tp-bottom"
                                     style="visibility: hidden; width: 0%; transform: matrix(1, 0, 0, 1, 0, 0);"></div>
                                <div class="tp-loader off" style="display: none;">
                                    <div class="dot1"></div>
                                    <div class="dot2"></div>
                                    <div class="bounce1"></div>
                                    <div class="bounce2"></div>
                                    <div class="bounce3"></div>
                                </div>
                                <div class="tp-leftarrow tparrows gyges"
                                     style="top: 50%; transform: matrix(1, 0, 0, 1, 0, -20); left: 0px;"></div>
                                <div class="tp-rightarrow tparrows gyges"
                                     style="top: 50%; transform: matrix(1, 0, 0, 1, -40, -20); left: 100%;"></div>
                            </div>
                            <script>var htmlDiv = document.getElementById("rs-plugin-settings-inline-css");
                                var htmlDivCss = ".tp-caption.Title,.Title{color:rgba(255,255,255,1.00);font-size:103px;line-height:103px;font-weight:900;font-style:normal;font-family:Roboto;padding:0px 0px 0px 0px;text-decoration:none;text-align:left;background-color:transparent;border-color:transparent;border-style:none;border-width:0px;border-radius:0px 0px 0px 0px}.tp-caption.Button-Style,.Button-Style{color:rgba(255,255,255,1.00);font-size:11px;line-height:17px;font-weight:900;font-style:normal;font-family:roboto;padding:0px 0px 0px 0px;text-decoration:none;text-align:left;background-color:transparent;border-color:transparent;border-style:none;border-width:0px;border-radius:0px 0px 0px 0px}.tp-caption.Small-Subtitle,.Small-Subtitle{color:rgba(255,255,255,1.00);font-size:16px;line-height:26px;font-weight:900;font-style:normal;font-family:Roboto;padding:0px 0px 0px 0px;text-decoration:none;text-align:left;background-color:transparent;border-color:transparent;border-style:none;border-width:0px;border-radius:0px 0px 0px 0px}";
                                if (htmlDiv) {
                                    htmlDiv.innerHTML = htmlDiv.innerHTML + htmlDivCss;
                                } else {
                                    var htmlDiv = document.createElement("div");
                                    htmlDiv.innerHTML = "<style>" + htmlDivCss + "</style>";
                                    document.getElementsByTagName("head")[0].appendChild(htmlDiv.childNodes[0]);
                                }
                            </script>
                            <script type="text/javascript">
                                /******************************************
                                 -    PREPARE PLACEHOLDER FOR SLIDER    -
                                 ******************************************/

                                var setREVStartSize = function () {
                                    try {
                                        var e = new Object, i = jQuery(window).width(), t = 9999, r = 0, n = 0, l = 0, f = 0, s = 0, h = 0;
                                        e.c = jQuery('#rev_slider_8_1');
                                        e.responsiveLevels = [1920, 1300, 778, 480];
                                        e.gridwidth = [1300, 1100, 778, 480];
                                        e.gridheight = [868, 768, 960, 720];

                                        e.sliderLayout = "fullscreen";
                                        e.fullScreenAutoWidth = 'off';
                                        e.fullScreenAlignForce = 'off';
                                        e.fullScreenOffsetContainer = '.no-touch .mkd-page-header, .touch .mkd-mobile-header';
                                        e.fullScreenOffset = '';
                                        if (e.responsiveLevels && (jQuery.each(e.responsiveLevels, function (e, f) {
                                                    f > i && (t = r = f, l = e), i > f && f > r && (r = f, n = e)
                                                }), t > r && (l = n)), f = e.gridheight[l] || e.gridheight[0] || e.gridheight, s = e.gridwidth[l] || e.gridwidth[0] || e.gridwidth, h = i / s, h = h > 1 ? 1 : h, f = Math.round(h * f), "fullscreen" == e.sliderLayout) {
                                            var u = (e.c.width(), jQuery(window).height());
                                            if (void 0 != e.fullScreenOffsetContainer) {
                                                var c = e.fullScreenOffsetContainer.split(",");
                                                if (c) jQuery.each(c, function (e, i) {
                                                    u = jQuery(i).length > 0 ? u - jQuery(i).outerHeight(!0) : u
                                                }), e.fullScreenOffset.split("%").length > 1 && void 0 != e.fullScreenOffset && e.fullScreenOffset.length > 0 ? u -= jQuery(window).height() * parseInt(e.fullScreenOffset, 0) / 100 : void 0 != e.fullScreenOffset && e.fullScreenOffset.length > 0 && (u -= parseInt(e.fullScreenOffset, 0))
                                            }
                                            f = u
                                        } else void 0 != e.minHeight && f < e.minHeight && (f = e.minHeight);
                                        e.c.closest(".rev_slider_wrapper").css({height: f})

                                    } catch (d) {
                                        console.log("Failure at Presize of Slider:" + d)
                                    }
                                };


                                setREVStartSize();
                                function revslider_showDoubleJqueryError(sliderID) {
                                    var errorMessage = "Revolution Slider Error: You have some jquery.js library include that comes after the revolution files js include.";
                                    errorMessage += "<br> This includes make eliminates the revolution slider libraries, and make it not work.";
                                    errorMessage += "<br><br> To fix it you can:<br>&nbsp;&nbsp;&nbsp; 1. In the Slider Settings -> Troubleshooting set option:  <strong><b>Put JS Includes To Body</b></strong> option to true.";
                                    errorMessage += "<br>&nbsp;&nbsp;&nbsp; 2. Find the double jquery.js include and remove it.";
                                    errorMessage = "<span style='font-size:16px;color:#BC0C06;'>" + errorMessage + "</span>";
                                    jQuery(sliderID).show().html(errorMessage);
                                }
                                var tpj = jQuery;

                                var revapi8;
                                tpj(document).ready(function () {
                                    if (tpj("#rev_slider_8_1").revolution == undefined) {
                                        revslider_showDoubleJqueryError("#rev_slider_8_1");
                                    } else {
                                        revapi8 = tpj("#rev_slider_8_1").show().revolution({
                                            sliderType: "standard",
                                            jsFileLocation: "//libero.mikado-themes.com/wp-content/plugins/revslider/public/assets/js/",
                                            sliderLayout: "fullscreen",
                                            dottedOverlay: "none",
                                            delay: 5500,
                                            navigation: {
                                                keyboardNavigation: "off",
                                                keyboard_direction: "horizontal",
                                                mouseScrollNavigation: "off",
                                                onHoverStop: "off",
                                                arrows: {
                                                    style: "gyges",
                                                    enable: true,
                                                    hide_onmobile: true,
                                                    hide_under: 1050,
                                                    hide_onleave: false,
                                                    tmp: '',
                                                    left: {
                                                        h_align: "left",
                                                        v_align: "center",
                                                        h_offset: 0,
                                                        v_offset: 0
                                                    },
                                                    right: {
                                                        h_align: "right",
                                                        v_align: "center",
                                                        h_offset: 0,
                                                        v_offset: 0
                                                    }
                                                }
                                            },
                                            responsiveLevels: [1920, 1300, 778, 480],
                                            visibilityLevels: [1920, 1300, 778, 480],
                                            gridwidth: [1300, 1100, 778, 480],
                                            gridheight: [868, 768, 960, 720],
                                            lazyType: "none",
                                            shadow: 0,
                                            spinner: "off",
                                            stopLoop: "off",
                                            stopAfterLoops: -1,
                                            stopAtSlide: -1,
                                            shuffle: "off",
                                            autoHeight: "off",
                                            fullScreenAutoWidth: "off",
                                            fullScreenAlignForce: "off",
                                            fullScreenOffsetContainer: ".no-touch .mkd-page-header, .touch .mkd-mobile-header",
                                            fullScreenOffset: "",
                                            disableProgressBar: "on",
                                            hideThumbsOnMobile: "off",
                                            hideSliderAtLimit: 0,
                                            hideCaptionAtLimit: 0,
                                            hideAllCaptionAtLilmit: 0,
                                            debugMode: false,
                                            fallbacks: {
                                                simplifyAll: "off",
                                                nextSlideOnWindowFocus: "on",
                                                disableFocusListener: false,
                                            }
                                        });
                                    }
                                });
                                /*ready*/
                            </script>
                        </div>
                        <div class="tp-fullwidth-forcer" style="width: 100%; height: 505px;"></div>
                    </div><!-- END REVOLUTION SLIDER -->        </div>
            </div>

            <div class="mkd-full-width">
                <div class="mkd-full-width-inner">
                    <div data-mkd-parallax-speed="1"
                         class="vc_row wpb_row vc_row-fluid mkd-section vc_custom_1449053863566 mkd-content-aligment-center mkd-grid-section"
                         style="">
                        <div class="clearfix mkd-section-inner">
                            <div class="mkd-section-inner-margin clearfix">
                                <div class="wpb_column vc_column_container vc_col-sm-4 vc_col-lg-2 vc_col-md-4 vc_custom_1447665617658">
                                    <div class="wpb_wrapper">
                                        <div class="mkd-elements-holder mkd-responsive-mode-768">
                                            <div class="mkd-elements-holder-item mkd-horizontal-alignment-center">
                                                <div class="mkd-elements-holder-item-inner">
                                                    <div class="mkd-elements-holder-item-content mkd-elements-holder-custom-532829"
                                                         style="padding: 0px">
                                                        <style type="text/css"
                                                               data-type="mkd-elements-custom-padding" scoped="">
                                                            <
                                                            br

                                                            /
                                                            >
                                                            <
                                                            b > Notice<

                                                            /
                                                            b > : Undefined index: item_padding_1024_1280 in < b > /www/ sites

                                                            /
                                                            libero.mikado-themes.com /files/ html /wp-content/ themes /libero/ framework /modules/ shortcodes /elements-holder/ templates

                                                            /
                                                            elements-holder-item-template.php<

                                                            /
                                                            b > on line < b >

                                                            6
                                                            <
                                                            /
                                                            b > < br

                                                            /
                                                            >
                                                            @media  only screen and (min-width: 1024px) and (max-width: 1280px) {
                                                                .mkd-elements-holder .mkd-elements-holder-item-content.mkd-elements-holder-custom-532829 {
                                                                    padding: < br / > < b > Notice < / b >: Undefined
                                                                    index: item_padding_1024_1280 in < b > /www/ sites / libero . mikado-themes . com /files/ html /wp-content/ themes /libero/ framework /modules/ shortcodes /elements-holder/ templates / elements-holder-item-template . php < / b > on line < b > 9 < / b > < br / > !important;
                                                                }
                                                            }

                                                            @media  only screen and (min-width: 768px) and (max-width: 1024px) {
                                                                .mkd-elements-holder .mkd-elements-holder-item-content.mkd-elements-holder-custom-532829 {
                                                                    padding: 20px 0px !important;
                                                                }
                                                            }

                                                            @media  only screen and (min-width: 600px) and (max-width: 768px) {
                                                                .mkd-elements-holder .mkd-elements-holder-item-content.mkd-elements-holder-custom-532829 {
                                                                    padding: 20px 0px 40px 0px !important;
                                                                }
                                                            }

                                                            @media  only screen and (min-width: 480px) and (max-width: 600px) {
                                                                .mkd-elements-holder .mkd-elements-holder-item-content.mkd-elements-holder-custom-532829 {
                                                                    padding: 20px 0px 40px 0px !important;
                                                                }
                                                            }

                                                            @media  only screen and (max-width: 480px) {
                                                                .mkd-elements-holder .mkd-elements-holder-item-content.mkd-elements-holder-custom-532829 {
                                                                    padding: 20px 0px 40px 0px !important;
                                                                }
                                                            }
                                                        </style>
                                                        <div class="mkd-interactive-icon mkd-right-border-added mkd-right-border-hide-1024"
                                                             style="opacity: 1;">
                                                            <div class="mkd-interactive-icon-inner"
                                                                 style="height: 150px;">
                                                                <div class="mkd-interactive-icon-initial-content">
                                                                    <div class="mkd-interactive-icon-image mkd-initial-content-item">
                                                                        <img src="/image/interactive-icon-1.png"
                                                                             class="attachment-full" alt="a"
                                                                             width="63" height="62"></div>
                                                                    <div class="mkd-interactive-icon-title mkd-initial-content-item">
                                                                        <h4 style="color: #ffffff">Bankrupcy</h4>
                                                                    </div>
                                                                </div>
                                                                <div class="mkd-interactive-icon-hover-content"
                                                                     style="top: 44px;">
                                                                    <div style="background-color: #c18f59"
                                                                         class="mkd-interactive-icon-separator">
                                                                    </div>
                                                                    <a href="http://libero.mikado-themes.com/about-our-company/"
                                                                       class="mkd-interactive-icon-link">
                                                                        <div class="mkd-interactive-icon-text">
                                                                            <p style="color: #ffffff">Representation
                                                                                in civil litigation cases.</p>
                                                                        </div>

                    <span style="color: #ffffff" class="mkd-interactive-icon-small icon-holder">
                        <span aria-hidden="true" class="arrow_carrot-right_alt2"></span>
                    </span>
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="wpb_column vc_column_container vc_col-sm-4 vc_col-lg-2 vc_col-md-4 vc_custom_1447665628867">
                                    <div class="wpb_wrapper">
                                        <div class="mkd-elements-holder mkd-responsive-mode-768">
                                            <div class="mkd-elements-holder-item mkd-horizontal-alignment-center">
                                                <div class="mkd-elements-holder-item-inner">
                                                    <div class="mkd-elements-holder-item-content mkd-elements-holder-custom-202215"
                                                         style="padding: 0px">
                                                        <style type="text/css"
                                                               data-type="mkd-elements-custom-padding" scoped="">
                                                            <
                                                            br

                                                            /
                                                            >
                                                            <
                                                            b > Notice<

                                                            /
                                                            b > : Undefined index: item_padding_1024_1280 in < b > /www/ sites

                                                            /
                                                            libero.mikado-themes.com /files/ html /wp-content/ themes /libero/ framework /modules/ shortcodes /elements-holder/ templates

                                                            /
                                                            elements-holder-item-template.php<

                                                            /
                                                            b > on line < b >

                                                            6
                                                            <
                                                            /
                                                            b > < br

                                                            /
                                                            >
                                                            @media  only screen and (min-width: 1024px) and (max-width: 1280px) {
                                                                .mkd-elements-holder .mkd-elements-holder-item-content.mkd-elements-holder-custom-202215 {
                                                                    padding: < br / > < b > Notice < / b >: Undefined
                                                                    index: item_padding_1024_1280 in < b > /www/ sites / libero . mikado-themes . com /files/ html /wp-content/ themes /libero/ framework /modules/ shortcodes /elements-holder/ templates / elements-holder-item-template . php < / b > on line < b > 9 < / b > < br / > !important;
                                                                }
                                                            }

                                                            @media  only screen and (min-width: 768px) and (max-width: 1024px) {
                                                                .mkd-elements-holder .mkd-elements-holder-item-content.mkd-elements-holder-custom-202215 {
                                                                    padding: 20px 0px !important;
                                                                }
                                                            }

                                                            @media  only screen and (min-width: 600px) and (max-width: 768px) {
                                                                .mkd-elements-holder .mkd-elements-holder-item-content.mkd-elements-holder-custom-202215 {
                                                                    padding: 20px 0px 40px 0px !important;
                                                                }
                                                            }

                                                            @media  only screen and (min-width: 480px) and (max-width: 600px) {
                                                                .mkd-elements-holder .mkd-elements-holder-item-content.mkd-elements-holder-custom-202215 {
                                                                    padding: 20px 0px 40px 0px !important;
                                                                }
                                                            }

                                                            @media  only screen and (max-width: 480px) {
                                                                .mkd-elements-holder .mkd-elements-holder-item-content.mkd-elements-holder-custom-202215 {
                                                                    padding: 20px 0px 40px 0px !important;
                                                                }
                                                            }
                                                        </style>
                                                        <div class="mkd-interactive-icon mkd-right-border-added mkd-right-border-hide-1024"
                                                             style="opacity: 1;">
                                                            <div class="mkd-interactive-icon-inner"
                                                                 style="height: 150px;">
                                                                <div class="mkd-interactive-icon-initial-content">
                                                                    <div class="mkd-interactive-icon-image mkd-initial-content-item">
                                                                        <img src="/image/interactive-icon-2.png"
                                                                             class="attachment-full" alt="a"
                                                                             width="65" height="62"></div>
                                                                    <div class="mkd-interactive-icon-title mkd-initial-content-item">
                                                                        <h4 style="color: #ffffff">Traffic
                                                                            Tikets</h4>
                                                                    </div>
                                                                </div>
                                                                <div class="mkd-interactive-icon-hover-content"
                                                                     style="top: 44px;">
                                                                    <div style="background-color: #c18f59"
                                                                         class="mkd-interactive-icon-separator">
                                                                    </div>
                                                                    <a href="http://libero.mikado-themes.com/facts/"
                                                                       class="mkd-interactive-icon-link">
                                                                        <div class="mkd-interactive-icon-text">
                                                                            <p style="color: #ffffff">Representation
                                                                                in civil litigation cases.</p>
                                                                        </div>

                    <span style="color: #ffffff" class="mkd-interactive-icon-small icon-holder">
                        <span aria-hidden="true" class="arrow_carrot-right_alt2"></span>
                    </span>
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="wpb_column vc_column_container vc_col-sm-4 vc_col-lg-2 vc_col-md-4 vc_custom_1447665635018">
                                    <div class="wpb_wrapper">
                                        <div class="mkd-elements-holder mkd-responsive-mode-768">
                                            <div class="mkd-elements-holder-item mkd-horizontal-alignment-center">
                                                <div class="mkd-elements-holder-item-inner">
                                                    <div class="mkd-elements-holder-item-content mkd-elements-holder-custom-953633"
                                                         style="padding: 0px">
                                                        <style type="text/css"
                                                               data-type="mkd-elements-custom-padding" scoped="">
                                                            <
                                                            br

                                                            /
                                                            >
                                                            <
                                                            b > Notice<

                                                            /
                                                            b > : Undefined index: item_padding_1024_1280 in < b > /www/ sites

                                                            /
                                                            libero.mikado-themes.com /files/ html /wp-content/ themes /libero/ framework /modules/ shortcodes /elements-holder/ templates

                                                            /
                                                            elements-holder-item-template.php<

                                                            /
                                                            b > on line < b >

                                                            6
                                                            <
                                                            /
                                                            b > < br

                                                            /
                                                            >
                                                            @media  only screen and (min-width: 1024px) and (max-width: 1280px) {
                                                                .mkd-elements-holder .mkd-elements-holder-item-content.mkd-elements-holder-custom-953633 {
                                                                    padding: < br / > < b > Notice < / b >: Undefined
                                                                    index: item_padding_1024_1280 in < b > /www/ sites / libero . mikado-themes . com /files/ html /wp-content/ themes /libero/ framework /modules/ shortcodes /elements-holder/ templates / elements-holder-item-template . php < / b > on line < b > 9 < / b > < br / > !important;
                                                                }
                                                            }

                                                            @media  only screen and (min-width: 768px) and (max-width: 1024px) {
                                                                .mkd-elements-holder .mkd-elements-holder-item-content.mkd-elements-holder-custom-953633 {
                                                                    padding: 20px 0px !important;
                                                                }
                                                            }

                                                            @media  only screen and (min-width: 600px) and (max-width: 768px) {
                                                                .mkd-elements-holder .mkd-elements-holder-item-content.mkd-elements-holder-custom-953633 {
                                                                    padding: 20px 0px 40px 0px !important;
                                                                }
                                                            }

                                                            @media  only screen and (min-width: 480px) and (max-width: 600px) {
                                                                .mkd-elements-holder .mkd-elements-holder-item-content.mkd-elements-holder-custom-953633 {
                                                                    padding: 20px 0px 40px 0px !important;
                                                                }
                                                            }

                                                            @media  only screen and (max-width: 480px) {
                                                                .mkd-elements-holder .mkd-elements-holder-item-content.mkd-elements-holder-custom-953633 {
                                                                    padding: 20px 0px 40px 0px !important;
                                                                }
                                                            }
                                                        </style>
                                                        <div class="mkd-interactive-icon mkd-right-border-added mkd-right-border-hide-1024"
                                                             style="opacity: 1;">
                                                            <div class="mkd-interactive-icon-inner"
                                                                 style="height: 150px;">
                                                                <div class="mkd-interactive-icon-initial-content">
                                                                    <div class="mkd-interactive-icon-image mkd-initial-content-item">
                                                                        <img src="/image/interactive-icon-3.png"
                                                                             class="attachment-full" alt="a"
                                                                             width="50" height="62"></div>
                                                                    <div class="mkd-interactive-icon-title mkd-initial-content-item">
                                                                        <h4 style="color: #ffffff">Personal
                                                                            Injury</h4>
                                                                    </div>
                                                                </div>
                                                                <div class="mkd-interactive-icon-hover-content"
                                                                     style="top: 44px;">
                                                                    <div style="background-color: #c18f59"
                                                                         class="mkd-interactive-icon-separator">
                                                                    </div>
                                                                    <a href="http://libero.mikado-themes.com/our-team-of-lawyers/"
                                                                       class="mkd-interactive-icon-link">
                                                                        <div class="mkd-interactive-icon-text">
                                                                            <p style="color: #ffffff">Representation
                                                                                in civil litigation cases.</p>
                                                                        </div>

                    <span style="color: #ffffff" class="mkd-interactive-icon-small icon-holder">
                        <span aria-hidden="true" class="arrow_carrot-right_alt2"></span>
                    </span>
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="wpb_column vc_column_container vc_col-sm-4 vc_col-lg-2 vc_col-md-4 vc_custom_1447665667284">
                                    <div class="wpb_wrapper">
                                        <div class="mkd-elements-holder mkd-responsive-mode-768">
                                            <div class="mkd-elements-holder-item mkd-horizontal-alignment-center">
                                                <div class="mkd-elements-holder-item-inner">
                                                    <div class="mkd-elements-holder-item-content mkd-elements-holder-custom-592614"
                                                         style="padding: 0px">
                                                        <style type="text/css"
                                                               data-type="mkd-elements-custom-padding" scoped="">
                                                            <
                                                            br

                                                            /
                                                            >
                                                            <
                                                            b > Notice<

                                                            /
                                                            b > : Undefined index: item_padding_1024_1280 in < b > /www/ sites

                                                            /
                                                            libero.mikado-themes.com /files/ html /wp-content/ themes /libero/ framework /modules/ shortcodes /elements-holder/ templates

                                                            /
                                                            elements-holder-item-template.php<

                                                            /
                                                            b > on line < b >

                                                            6
                                                            <
                                                            /
                                                            b > < br

                                                            /
                                                            >
                                                            @media  only screen and (min-width: 1024px) and (max-width: 1280px) {
                                                                .mkd-elements-holder .mkd-elements-holder-item-content.mkd-elements-holder-custom-592614 {
                                                                    padding: < br / > < b > Notice < / b >: Undefined
                                                                    index: item_padding_1024_1280 in < b > /www/ sites / libero . mikado-themes . com /files/ html /wp-content/ themes /libero/ framework /modules/ shortcodes /elements-holder/ templates / elements-holder-item-template . php < / b > on line < b > 9 < / b > < br / > !important;
                                                                }
                                                            }

                                                            @media  only screen and (min-width: 768px) and (max-width: 1024px) {
                                                                .mkd-elements-holder .mkd-elements-holder-item-content.mkd-elements-holder-custom-592614 {
                                                                    padding: 20px 0px !important;
                                                                }
                                                            }

                                                            @media  only screen and (min-width: 600px) and (max-width: 768px) {
                                                                .mkd-elements-holder .mkd-elements-holder-item-content.mkd-elements-holder-custom-592614 {
                                                                    padding: 20px 0px 40px 0px !important;
                                                                }
                                                            }

                                                            @media  only screen and (min-width: 480px) and (max-width: 600px) {
                                                                .mkd-elements-holder .mkd-elements-holder-item-content.mkd-elements-holder-custom-592614 {
                                                                    padding: 20px 0px 40px 0px !important;
                                                                }
                                                            }

                                                            @media  only screen and (max-width: 480px) {
                                                                .mkd-elements-holder .mkd-elements-holder-item-content.mkd-elements-holder-custom-592614 {
                                                                    padding: 20px 0px 40px 0px !important;
                                                                }
                                                            }
                                                        </style>
                                                        <div class="mkd-interactive-icon mkd-right-border-added mkd-right-border-hide-1024"
                                                             style="opacity: 1;">
                                                            <div class="mkd-interactive-icon-inner"
                                                                 style="height: 150px;">
                                                                <div class="mkd-interactive-icon-initial-content">
                                                                    <div class="mkd-interactive-icon-image mkd-initial-content-item">
                                                                        <img src="/image/interactive-icon-4.png"
                                                                             class="attachment-full" alt="a"
                                                                             width="62" height="62"></div>
                                                                    <div class="mkd-interactive-icon-title mkd-initial-content-item">
                                                                        <h4 style="color: #ffffff">Estate
                                                                            Planning</h4>
                                                                    </div>
                                                                </div>
                                                                <div class="mkd-interactive-icon-hover-content"
                                                                     style="top: 44px;">
                                                                    <div style="background-color: #c18f59"
                                                                         class="mkd-interactive-icon-separator">
                                                                    </div>
                                                                    <a href="http://libero.mikado-themes.com/our-team-of-lawyers/"
                                                                       class="mkd-interactive-icon-link">
                                                                        <div class="mkd-interactive-icon-text">
                                                                            <p style="color: #ffffff">Representation
                                                                                in civil litigation cases.</p>
                                                                        </div>

                    <span style="color: #ffffff" class="mkd-interactive-icon-small icon-holder">
                        <span aria-hidden="true" class="arrow_carrot-right_alt2"></span>
                    </span>
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="wpb_column vc_column_container vc_col-sm-4 vc_col-lg-2 vc_col-md-4 vc_custom_1447665660344">
                                    <div class="wpb_wrapper">
                                        <div class="mkd-elements-holder mkd-responsive-mode-768">
                                            <div class="mkd-elements-holder-item mkd-horizontal-alignment-center">
                                                <div class="mkd-elements-holder-item-inner">
                                                    <div class="mkd-elements-holder-item-content mkd-elements-holder-custom-227057"
                                                         style="padding: 0px">
                                                        <style type="text/css"
                                                               data-type="mkd-elements-custom-padding" scoped="">
                                                            <
                                                            br

                                                            /
                                                            >
                                                            <
                                                            b > Notice<

                                                            /
                                                            b > : Undefined index: item_padding_1024_1280 in < b > /www/ sites

                                                            /
                                                            libero.mikado-themes.com /files/ html /wp-content/ themes /libero/ framework /modules/ shortcodes /elements-holder/ templates

                                                            /
                                                            elements-holder-item-template.php<

                                                            /
                                                            b > on line < b >

                                                            6
                                                            <
                                                            /
                                                            b > < br

                                                            /
                                                            >
                                                            @media  only screen and (min-width: 1024px) and (max-width: 1280px) {
                                                                .mkd-elements-holder .mkd-elements-holder-item-content.mkd-elements-holder-custom-227057 {
                                                                    padding: < br / > < b > Notice < / b >: Undefined
                                                                    index: item_padding_1024_1280 in < b > /www/ sites / libero . mikado-themes . com /files/ html /wp-content/ themes /libero/ framework /modules/ shortcodes /elements-holder/ templates / elements-holder-item-template . php < / b > on line < b > 9 < / b > < br / > !important;
                                                                }
                                                            }

                                                            @media  only screen and (min-width: 768px) and (max-width: 1024px) {
                                                                .mkd-elements-holder .mkd-elements-holder-item-content.mkd-elements-holder-custom-227057 {
                                                                    padding: 20px 0px !important;
                                                                }
                                                            }

                                                            @media  only screen and (min-width: 600px) and (max-width: 768px) {
                                                                .mkd-elements-holder .mkd-elements-holder-item-content.mkd-elements-holder-custom-227057 {
                                                                    padding: 20px 0px 40px 0px !important;
                                                                }
                                                            }

                                                            @media  only screen and (min-width: 480px) and (max-width: 600px) {
                                                                .mkd-elements-holder .mkd-elements-holder-item-content.mkd-elements-holder-custom-227057 {
                                                                    padding: 20px 0px 40px 0px !important;
                                                                }
                                                            }

                                                            @media  only screen and (max-width: 480px) {
                                                                .mkd-elements-holder .mkd-elements-holder-item-content.mkd-elements-holder-custom-227057 {
                                                                    padding: 20px 0px 40px 0px !important;
                                                                }
                                                            }
                                                        </style>
                                                        <div class="mkd-interactive-icon mkd-right-border-added mkd-right-border-hide-1024"
                                                             style="opacity: 1;">
                                                            <div class="mkd-interactive-icon-inner"
                                                                 style="height: 150px;">
                                                                <div class="mkd-interactive-icon-initial-content">
                                                                    <div class="mkd-interactive-icon-image mkd-initial-content-item">
                                                                        <img src="/image/interactive-icon-2.png"
                                                                             class="attachment-full" alt="a"
                                                                             width="65" height="62"></div>
                                                                    <div class="mkd-interactive-icon-title mkd-initial-content-item">
                                                                        <h4 style="color: #ffffff">Car
                                                                            Accidents</h4>
                                                                    </div>
                                                                </div>
                                                                <div class="mkd-interactive-icon-hover-content"
                                                                     style="top: 44px;">
                                                                    <div style="background-color: #c18f59"
                                                                         class="mkd-interactive-icon-separator">
                                                                    </div>
                                                                    <a href="http://libero.mikado-themes.com/client-testimonials/"
                                                                       class="mkd-interactive-icon-link">
                                                                        <div class="mkd-interactive-icon-text">
                                                                            <p style="color: #ffffff">Representation
                                                                                in civil litigation cases.</p>
                                                                        </div>

                    <span style="color: #ffffff" class="mkd-interactive-icon-small icon-holder">
                        <span aria-hidden="true" class="arrow_carrot-right_alt2"></span>
                    </span>
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="wpb_column vc_column_container vc_col-sm-4 vc_col-lg-2 vc_col-md-4 vc_custom_1447665676106">
                                    <div class="wpb_wrapper">
                                        <div class="mkd-elements-holder mkd-responsive-mode-768">
                                            <div class="mkd-elements-holder-item mkd-horizontal-alignment-center">
                                                <div class="mkd-elements-holder-item-inner">
                                                    <div class="mkd-elements-holder-item-content mkd-elements-holder-custom-974565"
                                                         style="padding: 0px">
                                                        <style type="text/css"
                                                               data-type="mkd-elements-custom-padding" scoped="">
                                                            <
                                                            br

                                                            /
                                                            >
                                                            <
                                                            b > Notice<

                                                            /
                                                            b > : Undefined index: item_padding_1024_1280 in < b > /www/ sites

                                                            /
                                                            libero.mikado-themes.com /files/ html /wp-content/ themes /libero/ framework /modules/ shortcodes /elements-holder/ templates

                                                            /
                                                            elements-holder-item-template.php<

                                                            /
                                                            b > on line < b >

                                                            6
                                                            <
                                                            /
                                                            b > < br

                                                            /
                                                            >
                                                            @media  only screen and (min-width: 1024px) and (max-width: 1280px) {
                                                                .mkd-elements-holder .mkd-elements-holder-item-content.mkd-elements-holder-custom-974565 {
                                                                    padding: < br / > < b > Notice < / b >: Undefined
                                                                    index: item_padding_1024_1280 in < b > /www/ sites / libero . mikado-themes . com /files/ html /wp-content/ themes /libero/ framework /modules/ shortcodes /elements-holder/ templates / elements-holder-item-template . php < / b > on line < b > 9 < / b > < br / > !important;
                                                                }
                                                            }

                                                            @media  only screen and (min-width: 768px) and (max-width: 1024px) {
                                                                .mkd-elements-holder .mkd-elements-holder-item-content.mkd-elements-holder-custom-974565 {
                                                                    padding: 20px 0px !important;
                                                                }
                                                            }

                                                            @media  only screen and (min-width: 600px) and (max-width: 768px) {
                                                                .mkd-elements-holder .mkd-elements-holder-item-content.mkd-elements-holder-custom-974565 {
                                                                    padding: 20px 0px 40px 0px !important;
                                                                }
                                                            }

                                                            @media  only screen and (min-width: 480px) and (max-width: 600px) {
                                                                .mkd-elements-holder .mkd-elements-holder-item-content.mkd-elements-holder-custom-974565 {
                                                                    padding: 20px 0px 40px 0px !important;
                                                                }
                                                            }

                                                            @media  only screen and (max-width: 480px) {
                                                                .mkd-elements-holder .mkd-elements-holder-item-content.mkd-elements-holder-custom-974565 {
                                                                    padding: 20px 0px 40px 0px !important;
                                                                }
                                                            }
                                                        </style>
                                                        <div class="mkd-interactive-icon " style="opacity: 1;">
                                                            <div class="mkd-interactive-icon-inner"
                                                                 style="height: 150px;">
                                                                <div class="mkd-interactive-icon-initial-content">
                                                                    <div class="mkd-interactive-icon-image mkd-initial-content-item">
                                                                        <img src="/image/interactive-icon-1.png"
                                                                             class="attachment-full" alt="a"
                                                                             width="63" height="62"></div>
                                                                    <div class="mkd-interactive-icon-title mkd-initial-content-item">
                                                                        <h4 style="color: #ffffff">Capital
                                                                            Market</h4>
                                                                    </div>
                                                                </div>
                                                                <div class="mkd-interactive-icon-hover-content"
                                                                     style="top: 44px;">
                                                                    <div style="background-color: #c18f59"
                                                                         class="mkd-interactive-icon-separator">
                                                                    </div>
                                                                    <a href="http://libero.mikado-themes.com/company-history/"
                                                                       class="mkd-interactive-icon-link">
                                                                        <div class="mkd-interactive-icon-text">
                                                                            <p style="color: #ffffff">Representation
                                                                                in civil litigation cases.</p>
                                                                        </div>

                    <span style="color: #ffffff" class="mkd-interactive-icon-small icon-holder">
                        <span aria-hidden="true" class="arrow_carrot-right_alt2"></span>
                    </span>
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div data-mkd-parallax-speed="1"
                         class="vc_row wpb_row vc_row-fluid mkd-section vc_custom_1450197220155 mkd-content-aligment-center mkd-grid-section"
                         style="">
                        <div class="clearfix mkd-section-inner">
                            <div class="mkd-section-inner-margin clearfix">
                                <div class="wpb_column vc_column_container vc_col-sm-12">
                                    <div class="wpb_wrapper">
                                        <div class="mkd-separator-holder clearfix  mkd-separator-center mkd-separator-with-icon mkd-animate appeared"
                                             style="margin-top: 20px; margin-bottom: 30px">
                                            <div class="mkd-separator"
                                                 style="border-color: #c18f59;border-style: solid;width: 97.5px"></div>
                                            <div class="mkd-separator-icon">
                                                <img src="/image/h1-separator-custom-icon-1.png"
                                                     class="attachment-full" alt="a" width="34" height="23"></div>
                                            <div class="mkd-separator"
                                                 style="border-color: #c18f59;border-style: solid;width: 97.5px"></div>
                                        </div>

                                        <div class="wpb_text_column wpb_content_element ">
                                            <div class="wpb_wrapper">
                                                <h1><span style="color: #c18f59;">Toughest Defense</span> Lawyers
                                                    for Your Money</h1>

                                            </div>
                                        </div>
                                        <div class="vc_empty_space" style="height: 23px"><span
                                                    class="vc_empty_space_inner"></span></div>

                                        <div class="wpb_text_column wpb_content_element ">
                                            <div class="wpb_wrapper">
                                                <h3>Our&nbsp;lawyers will also represent you in civil litigation
                                                    cases such as&nbsp;divorce, child and spouse maintenance.</h3>

                                            </div>
                                        </div>
                                        <div data-mkd-parallax-speed="1"
                                             class="vc_row wpb_row vc_inner vc_row-fluid mkd-section vc_custom_1450192780703 mkd-content-aligment-center"
                                             style="">
                                            <div class="mkd-full-section-inner">
                                                <div class="wpb_column vc_column_container vc_col-sm-6 vc_col-lg-3 vc_col-md-6">
                                                    <div class="wpb_wrapper">
                                                        <div class="mkd-interactive-banner linked">
                                                            <div class="mkd-interactive-banner-inner">
                                                                <div class="mkd-interactive-banner-icon">

    <span class="mkd-icon-shortcode circle mkd-icon-small">

        <i class="mkd-icon-simple-line-icon icon-flag mkd-icon-element" style=""></i>
                <span class="mkd-background"></span>
    </span>

                                                                </div>
                                                                <div class="mkd-interactive-banner-image">
                                                                    <img src="/image/interactive-banner-color-pic-1.jpg"
                                                                         class="attachment-full" alt="a" width="500"
                                                                         height="408"></div>

                                                                <div class="mkd-interactive-banner-info">
                                                                    <div class="mkd-interactive-banner-title-holder">
                                                                        <h2 class="mkd-interactive-banner-title"
                                                                            style="color: #ffffff">
                                                                            In the Court of Law </h2>
                                                                        <h5 class="mkd-interactive-banner-subtitle"
                                                                            style="color: #ffffff">criminal law</h5>
                                                                    </div>
                                                                    <div class="mkd-interactive-banner-read-more">
                                                                        <a href="http://libero.mikado-themes.com/about-our-company/">
					<span class="mkd-interactive-banner-read-more-inner">
						<span class="mkd-interactive-banner-read-more-text">Find Out More</span>
						<span aria-hidden="true"
                              class="arrow_carrot-right_alt2 mkd-interactive-banner-read-more-icon"></span>
					</span>
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                                <span class="mkd-interactive-banner-triangle"
                                                                      style="top: 146.767px;"></span>
                                                        </div>
                                                        <div class="vc_empty_space" style="height: 40px"><span
                                                                    class="vc_empty_space_inner"></span></div>
                                                    </div>
                                                </div>
                                                <div class="wpb_column vc_column_container vc_col-sm-6 vc_col-lg-3 vc_col-md-6">
                                                    <div class="wpb_wrapper">
                                                        <div class="mkd-interactive-banner linked">
                                                            <div class="mkd-interactive-banner-inner">
                                                                <div class="mkd-interactive-banner-icon">

    <span class="mkd-icon-shortcode circle mkd-icon-small">

        <i class="mkd-icon-simple-line-icon icon-energy mkd-icon-element" style=""></i>
                <span class="mkd-background"></span>
    </span>

                                                                </div>
                                                                <div class="mkd-interactive-banner-image">
                                                                    <img src="/image/interactive-banner-color-pic-2.jpg"
                                                                         class="attachment-full" alt="a" width="500"
                                                                         height="408"></div>

                                                                <div class="mkd-interactive-banner-info">
                                                                    <div class="mkd-interactive-banner-title-holder">
                                                                        <h2 class="mkd-interactive-banner-title"
                                                                            style="color: #ffffff">
                                                                            Medical Negligence </h2>
                                                                        <h5 class="mkd-interactive-banner-subtitle"
                                                                            style="color: #ffffff">medical
                                                                            malpractice</h5>
                                                                    </div>
                                                                    <div class="mkd-interactive-banner-read-more">
                                                                        <a href="http://libero.mikado-themes.com/facts/">
					<span class="mkd-interactive-banner-read-more-inner">
						<span class="mkd-interactive-banner-read-more-text">Find Out More</span>
						<span aria-hidden="true"
                              class="arrow_carrot-right_alt2 mkd-interactive-banner-read-more-icon"></span>
					</span>
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                                <span class="mkd-interactive-banner-triangle"
                                                                      style="top: 146.767px;"></span>
                                                        </div>
                                                        <div class="vc_empty_space" style="height: 40px"><span
                                                                    class="vc_empty_space_inner"></span></div>
                                                    </div>
                                                </div>
                                                <div class="wpb_column vc_column_container vc_col-sm-6 vc_col-lg-3 vc_col-md-6">
                                                    <div class="wpb_wrapper">
                                                        <div class="mkd-interactive-banner linked">
                                                            <div class="mkd-interactive-banner-inner">
                                                                <div class="mkd-interactive-banner-icon">

    <span class="mkd-icon-shortcode circle mkd-icon-small">

        <i class="mkd-icon-simple-line-icon icon-earphones-alt mkd-icon-element" style=""></i>
                <span class="mkd-background"></span>
    </span>

                                                                </div>
                                                                <div class="mkd-interactive-banner-image">
                                                                    <img src="/image/interactive-banner-color-pic-3.jpg"
                                                                         class="attachment-full" alt="a" width="500"
                                                                         height="408"></div>

                                                                <div class="mkd-interactive-banner-info">
                                                                    <div class="mkd-interactive-banner-title-holder">
                                                                        <h2 class="mkd-interactive-banner-title"
                                                                            style="color: #ffffff">
                                                                            Family Law </h2>
                                                                        <h5 class="mkd-interactive-banner-subtitle"
                                                                            style="color: #ffffff">insurance
                                                                            law</h5>
                                                                    </div>
                                                                    <div class="mkd-interactive-banner-read-more">
                                                                        <a href="http://libero.mikado-themes.com/our-team-of-lawyers/">
					<span class="mkd-interactive-banner-read-more-inner">
						<span class="mkd-interactive-banner-read-more-text">Find Out More</span>
						<span aria-hidden="true"
                              class="arrow_carrot-right_alt2 mkd-interactive-banner-read-more-icon"></span>
					</span>
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                                <span class="mkd-interactive-banner-triangle"
                                                                      style="top: 146.767px;"></span>
                                                        </div>
                                                        <div class="vc_empty_space" style="height: 40px"><span
                                                                    class="vc_empty_space_inner"></span></div>
                                                    </div>
                                                </div>
                                                <div class="wpb_column vc_column_container vc_col-sm-6 vc_col-lg-3 vc_col-md-6">
                                                    <div class="wpb_wrapper">
                                                        <div class="mkd-interactive-banner linked">
                                                            <div class="mkd-interactive-banner-inner">
                                                                <div class="mkd-interactive-banner-icon">

    <span class="mkd-icon-shortcode circle mkd-icon-small">

        <i class="mkd-icon-simple-line-icon icon-lock mkd-icon-element" style=""></i>
                <span class="mkd-background"></span>
    </span>

                                                                </div>
                                                                <div class="mkd-interactive-banner-image">
                                                                    <img src="/image/interactive-banner-color-pic-4.jpg"
                                                                         class="attachment-full" alt="a" width="500"
                                                                         height="408"></div>

                                                                <div class="mkd-interactive-banner-info">
                                                                    <div class="mkd-interactive-banner-title-holder">
                                                                        <h2 class="mkd-interactive-banner-title"
                                                                            style="color: #ffffff">
                                                                            Stop a Foreclosure </h2>
                                                                        <h5 class="mkd-interactive-banner-subtitle"
                                                                            style="color: #ffffff">real estate
                                                                            law</h5>
                                                                    </div>
                                                                    <div class="mkd-interactive-banner-read-more">
                                                                        <a href="http://libero.mikado-themes.com/company-history/">
					<span class="mkd-interactive-banner-read-more-inner">
						<span class="mkd-interactive-banner-read-more-text">Find Out More</span>
						<span aria-hidden="true"
                              class="arrow_carrot-right_alt2 mkd-interactive-banner-read-more-icon"></span>
					</span>
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                                <span class="mkd-interactive-banner-triangle"
                                                                      style="top: 146.767px;"></span>
                                                        </div>
                                                        <div class="vc_empty_space" style="height: 40px"><span
                                                                    class="vc_empty_space_inner"></span></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div data-mkd-parallax-speed="1"
                         class="vc_row wpb_row vc_row-fluid mkd-section vc_custom_1450176712252 mkd-content-aligment-center mkd-grid-section"
                         style="">
                        <div class="clearfix mkd-section-inner">
                            <div class="mkd-section-inner-margin clearfix">
                                <div class="wpb_column vc_column_container vc_col-sm-12">
                                    <div class="wpb_wrapper">

                                        <div class="mkd-call-to-action normal" style="background-color: #f2f2f2">

                                            <div class="mkd-container-inner">
                                                <div class="mkd-call-to-action-row-66-33 clearfix"
                                                     style="padding: 45px 0% 45px 16%;">

                                                    <div class="mkd-text-wrapper mkd-call-to-action-column1 mkd-call-to-action-cell">


                                                        <div class="mkd-call-to-action-text">
                                                            <h3>Our&nbsp;lawyers will also represent you in civil
                                                                litigation cases such as&nbsp;divorce.</h3>
                                                        </div>

                                                    </div>


                                                    <div class="mkd-button-wrapper mkd-call-to-action-column2 mkd-call-to-action-cell"
                                                         style="text-align: left ;">

                                                        <a href="#" target="_self"
                                                           class="mkd-btn mkd-btn-medium mkd-btn-solid mkd-btn-icon">
                                                            <span class="mkd-btn-text">Contact us</span><span
                                                                    class="mkd-btn-icon-holder">            <span
                                                                        aria-hidden="true"
                                                                        class="mkd-icon-font-elegant arrow_carrot-right mkd-btn-icon-elem"></span>            <span
                                                                        aria-hidden="true"
                                                                        class="mkd-icon-font-elegant arrow_carrot-right mkd-btn-icon-elem"></span>        </span>
                                                        </a>
                                                    </div>


                                                </div>

                                            </div>

                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div data-mkd-parallax-speed="1"
                         class="vc_row wpb_row vc_row-fluid mkd-section mkd-content-aligment-center" style="">
                        <div class="mkd-row-triangle mkd-row-triangle-top mkd-triangle-bkg"
                             style="border-color:#f2f2f2;"></div>
                        <div class="clearfix mkd-full-section-inner">
                            <div class="wpb_column vc_column_container vc_col-sm-12">
                                <div class="wpb_wrapper">
                                    <div class="mkd-elements-holder mkd-two-columns mkd-responsive-mode-1024">
                                        <div class="mkd-elements-holder-item mkd-horizontal-alignment-center"
                                             style="background-image: url(http://libero.mikado-themes.com/wp-content/uploads/2015/11/h4-holder-img-1.jpg)">
                                            <div class="mkd-elements-holder-item-inner">
                                                <div class="mkd-elements-holder-item-content mkd-elements-holder-custom-993402"
                                                     style="padding: 12% 28%">
                                                    <style type="text/css" data-type="mkd-elements-custom-padding"
                                                           scoped="">
                                                        @media  only screen and (min-width: 1024px) and (max-width: 1280px) {
                                                            .mkd-elements-holder .mkd-elements-holder-item-content.mkd-elements-holder-custom-993402 {
                                                                padding: 13% 18% !important;
                                                            }
                                                        }

                                                        @media  only screen and (min-width: 768px) and (max-width: 1024px) {
                                                            .mkd-elements-holder .mkd-elements-holder-item-content.mkd-elements-holder-custom-993402 {
                                                                padding: 7% 22% 7% 22% !important;
                                                            }
                                                        }

                                                        @media  only screen and (min-width: 600px) and (max-width: 768px) {
                                                            .mkd-elements-holder .mkd-elements-holder-item-content.mkd-elements-holder-custom-993402 {
                                                                padding: 10% 15% 10% 15% !important;
                                                            }
                                                        }

                                                        @media  only screen and (min-width: 480px) and (max-width: 600px) {
                                                            .mkd-elements-holder .mkd-elements-holder-item-content.mkd-elements-holder-custom-993402 {
                                                                padding: 10% 8% 10% 8% !important;
                                                            }
                                                        }

                                                        @media  only screen and (max-width: 480px) {
                                                            .mkd-elements-holder .mkd-elements-holder-item-content.mkd-elements-holder-custom-993402 {
                                                                padding: 10% 3% 10% 3% !important;
                                                            }
                                                        }
                                                    </style>
                                                    <div class="mkd-separator-holder clearfix  mkd-separator-center mkd-separator-with-icon"
                                                         style="margin-top: 10px; margin-bottom: 17px">
                                                        <div class="mkd-separator"
                                                             style="border-color: #ffffff;border-style: solid;width: 60px"></div>
                                                        <div class="mkd-separator-icon">
                                                            <img src="/image/h4-custom-icon-white.png"
                                                                 class="attachment-full" alt="a" width="35"
                                                                 height="23"></div>
                                                        <div class="mkd-separator"
                                                             style="border-color: #ffffff;border-style: solid;width: 60px"></div>
                                                    </div>
                                                    <div class="mkd-counter-holder center mkd-counter-holder-show"
                                                         style="padding-bottom: 20px" data-digit-size="75">
                                                        <div class="mkd-counter-number-holder">
                                                                <span class="mkd-counter-currency"
                                                                      style="font-size: 75px;color: #ffffff;font-weight: 900">$</span>
                                                                <span class="mkd-counter zero"
                                                                      style="font-size: 75px;color: #ffffff;font-weight: 900">325000</span>
                                                        </div>

                                                    </div>
                                                    <div class="wpb_text_column wpb_content_element ">
                                                        <div class="wpb_wrapper">
                                                            <h2><span style="color: #ffffff;">Recovered for Our Clients This Year</span>
                                                            </h2>

                                                        </div>
                                                    </div>
                                                    <div class="vc_empty_space" style="height: 17px"><span
                                                                class="vc_empty_space_inner"></span></div>

                                                    <p class="mkd-custom-font-holder"
                                                       style="font-size: 14px;line-height: 24px;font-weight: 400;letter-spacing: 0px;color: #ffffff"
                                                       data-font-size="14" data-line-height="24">
                                                        Sometimes you may find yourself in difficult situations and
                                                        not be able to defuse the situation without going to
                                                        court.</p>
                                                    <div class="vc_empty_space" style="height: 40px"><span
                                                                class="vc_empty_space_inner"></span></div>
                                                    <a href="#" target="_self"
                                                       style="color: #ffffff;background-color: #3e475d"
                                                       class="mkd-btn mkd-btn-medium mkd-btn-solid mkd-btn-icon">
                                                        <span class="mkd-btn-text">Contact us</span><span
                                                                class="mkd-btn-icon-holder">
            <span aria-hidden="true" class="mkd-icon-font-elegant arrow_carrot-right mkd-btn-icon-elem"></span>            <span
                                                                    aria-hidden="true"
                                                                    class="mkd-icon-font-elegant arrow_carrot-right mkd-btn-icon-elem"></span>        </span>
                                                    </a></div>
                                            </div>
                                        </div>
                                        <div class="mkd-elements-holder-item mkd-horizontal-alignment-center"
                                             style="background-image: url(http://libero.mikado-themes.com/wp-content/uploads/2015/11/h4-holder-img-2.jpg)">
                                            <div class="mkd-elements-holder-item-inner">
                                                <div class="mkd-elements-holder-item-content mkd-elements-holder-custom-723773"
                                                     style="padding: 12% 28%">
                                                    <style type="text/css" data-type="mkd-elements-custom-padding"
                                                           scoped="">
                                                        @media  only screen and (min-width: 1024px) and (max-width: 1280px) {
                                                            .mkd-elements-holder .mkd-elements-holder-item-content.mkd-elements-holder-custom-723773 {
                                                                padding: 13% 18% !important;
                                                            }
                                                        }

                                                        @media  only screen and (min-width: 768px) and (max-width: 1024px) {
                                                            .mkd-elements-holder .mkd-elements-holder-item-content.mkd-elements-holder-custom-723773 {
                                                                padding: 7% 22% 7% 22% !important;
                                                            }
                                                        }

                                                        @media  only screen and (min-width: 600px) and (max-width: 768px) {
                                                            .mkd-elements-holder .mkd-elements-holder-item-content.mkd-elements-holder-custom-723773 {
                                                                padding: 10% 15% 10% 15% !important;
                                                            }
                                                        }

                                                        @media  only screen and (min-width: 480px) and (max-width: 600px) {
                                                            .mkd-elements-holder .mkd-elements-holder-item-content.mkd-elements-holder-custom-723773 {
                                                                padding: 10% 8% 10% 8% !important;
                                                            }
                                                        }

                                                        @media  only screen and (max-width: 480px) {
                                                            .mkd-elements-holder .mkd-elements-holder-item-content.mkd-elements-holder-custom-723773 {
                                                                padding: 10% 3% 10% 3% !important;
                                                            }
                                                        }
                                                    </style>
                                                    <div class="mkd-separator-holder clearfix  mkd-separator-center mkd-separator-with-icon"
                                                         style="margin-top: 10px; margin-bottom: 17px">
                                                        <div class="mkd-separator"
                                                             style="border-color: #ffffff;border-style: solid;width: 60px"></div>
                                                        <div class="mkd-separator-icon">
                                                            <img src="/image/h4-custom-icon-white.png"
                                                                 class="attachment-full" alt="a" width="35"
                                                                 height="23"></div>
                                                        <div class="mkd-separator"
                                                             style="border-color: #ffffff;border-style: solid;width: 60px"></div>
                                                    </div>
                                                    <div class="mkd-counter-holder center mkd-counter-holder-show"
                                                         style="padding-bottom: 20px" data-digit-size="75">
                                                        <div class="mkd-counter-number-holder">
                                                                <span class="mkd-counter-currency"
                                                                      style="font-size: 75px;color: #ffffff;font-weight: 900">$</span>
                                                                <span class="mkd-counter zero"
                                                                      style="font-size: 75px;color: #ffffff;font-weight: 900">125000</span>
                                                        </div>

                                                    </div>
                                                    <div class="wpb_text_column wpb_content_element ">
                                                        <div class="wpb_wrapper">
                                                            <h2><span style="color: #ffffff;">Recovered Bail Expenses&nbsp;This Year</span>
                                                            </h2>

                                                        </div>
                                                    </div>
                                                    <div class="vc_empty_space" style="height: 17px"><span
                                                                class="vc_empty_space_inner"></span></div>

                                                    <p class="mkd-custom-font-holder"
                                                       style="font-size: 14px;line-height: 24px;font-weight: 400;letter-spacing: 0px;color: #ffffff"
                                                       data-font-size="14" data-line-height="24">
                                                        Sometimes you may find yourself in difficult situations and
                                                        not be able to defuse the situation without going to
                                                        court.</p>
                                                    <div class="vc_empty_space" style="height: 40px"><span
                                                                class="vc_empty_space_inner"></span></div>
                                                    <a href="#" target="_self"
                                                       class="mkd-btn mkd-btn-medium mkd-btn-solid mkd-btn-icon">
                                                        <span class="mkd-btn-text">Contact us</span><span
                                                                class="mkd-btn-icon-holder">
            <span aria-hidden="true" class="mkd-icon-font-elegant arrow_carrot-right mkd-btn-icon-elem"></span>            <span
                                                                    aria-hidden="true"
                                                                    class="mkd-icon-font-elegant arrow_carrot-right mkd-btn-icon-elem"></span>        </span>
                                                    </a></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div data-mkd-parallax-speed="1"
                         class="vc_row wpb_row vc_row-fluid mkd-section vc_custom_1449053902261 mkd-content-aligment-center mkd-grid-section"
                         style="">
                        <div class="clearfix mkd-section-inner">
                            <div class="mkd-section-inner-margin clearfix">
                                <div class="wpb_column vc_column_container vc_col-sm-12">
                                    <div class="wpb_wrapper">
                                        <div class="mkd-separator-holder clearfix  mkd-separator-center mkd-separator-with-icon mkd-animate appeared"
                                             style="margin-top: 20px; margin-bottom: 30px">
                                            <div class="mkd-separator"
                                                 style="border-color: #c18f59;border-style: solid;width: 97.5px"></div>
                                            <div class="mkd-separator-icon">
                                                <img src="/image/h1-separator-custom-icon-1.png"
                                                     class="attachment-full" alt="a" width="34" height="23"></div>
                                            <div class="mkd-separator"
                                                 style="border-color: #c18f59;border-style: solid;width: 97.5px"></div>
                                        </div>

                                        <div class="wpb_text_column wpb_content_element ">
                                            <div class="wpb_wrapper">
                                                <h1><span style="color: #c18f59;">Legal Representation</span> in
                                                    Litigation Cases</h1>

                                            </div>
                                        </div>
                                        <div class="vc_empty_space" style="height: 23px"><span
                                                    class="vc_empty_space_inner"></span></div>

                                        <div class="wpb_text_column wpb_content_element ">
                                            <div class="wpb_wrapper">
                                                <h3>Our&nbsp;lawyers will also represent you in civil litigation
                                                    cases such as&nbsp;divorce, child and spouse maintenance.</h3>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div data-mkd-parallax-speed="1"
                         class="vc_row wpb_row vc_row-fluid mkd-section vc_custom_1450197352911 mkd-content-aligment-center mkd-grid-section"
                         style="">
                        <div class="clearfix mkd-section-inner">
                            <div class="mkd-section-inner-margin clearfix">
                                <div class="wpb_column vc_column_container vc_col-sm-6 vc_col-lg-3 vc_col-md-6">
                                    <div class="wpb_wrapper">
                                        <div class="mkd-team linked more-info-shown">
                                            <div class="mkd-team-inner">
                                                <div class="mkd-team-image">
                                                    <img src="/image/h-main-team-1.jpg"
                                                         class="attachment-full" alt="a" width="303" height="303">
                                                </div>

                                                <div class="mkd-team-info">
                                                    <div class="mkd-team-title-holder">
                                                        <h4 class="mkd-team-name">
                                                            Thomas McClain </h4>
                                                        <h5 class="mkd-team-position" style="color: #ffffff">Titular
                                                            Attorney</h5>
                                                    </div>
                                                    <div class="mkd-team-read-more">
                                                        <a href="http://libero.mikado-themes.com/our-team-of-lawyers/">
					<span class="mkd-team-read-more-inner">
						<span class="mkd-team-read-more-text">See Success Rates</span>
						<span aria-hidden="true" class="arrow_carrot-right_alt2 mkd-team-read-more-icon"></span>
					</span>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="mkd-team-social-holder">
                                                <div class="mkd-team-social">
                                                    <div class="mkd-team-social-inner">
                                                        <div class="mkd-team-social-wrapp clearfix">


                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <span class="mkd-team-triangle" style="top: 190.833px;"></span>
                                        </div>
                                        <div class="vc_empty_space" style="height: 70px"><span
                                                    class="vc_empty_space_inner"></span></div>
                                    </div>
                                </div>
                                <div class="wpb_column vc_column_container vc_col-sm-6 vc_col-lg-3 vc_col-md-6">
                                    <div class="wpb_wrapper">
                                        <div class="mkd-team linked more-info-shown">
                                            <div class="mkd-team-inner">
                                                <div class="mkd-team-image">
                                                    <img src="/image/h-main-team-2.jpg"
                                                         class="attachment-full" alt="a" width="303" height="303">
                                                </div>

                                                <div class="mkd-team-info">
                                                    <div class="mkd-team-title-holder">
                                                        <h4 class="mkd-team-name">
                                                            Rose Johnson </h4>
                                                        <h5 class="mkd-team-position" style="color: #ffffff">
                                                            External Relations</h5>
                                                    </div>
                                                    <div class="mkd-team-read-more">
                                                        <a href="http://libero.mikado-themes.com/our-team-of-lawyers/">
					<span class="mkd-team-read-more-inner">
						<span class="mkd-team-read-more-text">See Success Rates</span>
						<span aria-hidden="true" class="arrow_carrot-right_alt2 mkd-team-read-more-icon"></span>
					</span>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="mkd-team-social-holder">
                                                <div class="mkd-team-social">
                                                    <div class="mkd-team-social-inner">
                                                        <div class="mkd-team-social-wrapp clearfix">


                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <span class="mkd-team-triangle" style="top: 190.833px;"></span>
                                        </div>
                                        <div class="vc_empty_space" style="height: 70px"><span
                                                    class="vc_empty_space_inner"></span></div>
                                    </div>
                                </div>
                                <div class="wpb_column vc_column_container vc_col-sm-6 vc_col-lg-3 vc_col-md-6">
                                    <div class="wpb_wrapper">
                                        <div class="mkd-team linked more-info-shown">
                                            <div class="mkd-team-inner">
                                                <div class="mkd-team-image">
                                                    <img src="/image/h-main-team-3.jpg"
                                                         class="attachment-full" alt="a" width="303" height="303">
                                                </div>

                                                <div class="mkd-team-info">
                                                    <div class="mkd-team-title-holder">
                                                        <h4 class="mkd-team-name">
                                                            Simon Robins </h4>
                                                        <h5 class="mkd-team-position" style="color: #ffffff">
                                                            Associate Attorney</h5>
                                                    </div>
                                                    <div class="mkd-team-read-more">
                                                        <a href="http://libero.mikado-themes.com/our-team-of-lawyers/">
					<span class="mkd-team-read-more-inner">
						<span class="mkd-team-read-more-text">See Success Rates</span>
						<span aria-hidden="true" class="arrow_carrot-right_alt2 mkd-team-read-more-icon"></span>
					</span>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="mkd-team-social-holder">
                                                <div class="mkd-team-social">
                                                    <div class="mkd-team-social-inner">
                                                        <div class="mkd-team-social-wrapp clearfix">


                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <span class="mkd-team-triangle" style="top: 190.833px;"></span>
                                        </div>
                                        <div class="vc_empty_space" style="height: 70px"><span
                                                    class="vc_empty_space_inner"></span></div>
                                    </div>
                                </div>
                                <div class="wpb_column vc_column_container vc_col-sm-6 vc_col-lg-3 vc_col-md-6">
                                    <div class="wpb_wrapper">
                                        <div class="mkd-team linked more-info-shown">
                                            <div class="mkd-team-inner">
                                                <div class="mkd-team-image">
                                                    <img src="/image/h-main-team-4.jpg"
                                                         class="attachment-full" alt="a" width="303" height="303">
                                                </div>

                                                <div class="mkd-team-info">
                                                    <div class="mkd-team-title-holder">
                                                        <h4 class="mkd-team-name">
                                                            Nelson Conroy </h4>
                                                        <h5 class="mkd-team-position" style="color: #ffffff">
                                                            Executive Director</h5>
                                                    </div>
                                                    <div class="mkd-team-read-more">
                                                        <a href="http://libero.mikado-themes.com/our-team-of-lawyers/">
					<span class="mkd-team-read-more-inner">
						<span class="mkd-team-read-more-text">See Success Rates</span>
						<span aria-hidden="true" class="arrow_carrot-right_alt2 mkd-team-read-more-icon"></span>
					</span>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="mkd-team-social-holder">
                                                <div class="mkd-team-social">
                                                    <div class="mkd-team-social-inner">
                                                        <div class="mkd-team-social-wrapp clearfix">


                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <span class="mkd-team-triangle" style="top: 190.833px;"></span>
                                        </div>
                                        <div class="vc_empty_space" style="height: 70px"><span
                                                    class="vc_empty_space_inner"></span></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div data-mkd-parallax-speed="1"
                         class="vc_row wpb_row vc_row-fluid mkd-section mkd-content-aligment-left" style="">
                        <div class="clearfix mkd-full-section-inner">
                            <div class="wpb_column vc_column_container vc_col-sm-12">
                                <div class="wpb_wrapper">
                                    <div class="mkd-fullwidth-slider-holder">
                                        <div class="mkd-fullwidth-slider-slides owl-carousel owl-theme"
                                             style="opacity: 1; display: block; visibility: visible;">
                                            <div class="owl-wrapper-outer autoHeight" style="height: 379px;">
                                                <div class="owl-wrapper"
                                                     style="width: 10792px; left: 0px; display: block; transition: all 0ms ease 0s; transform: translate3d(-4047px, 0px, 0px); transform-origin: 4721.5px 50% 0px; perspective-origin: 4721.5px 50%;">
                                                    <div class="owl-item" style="width: 1349px;">
                                                        <div class="mkd-fullwidth-slider-item"
                                                             style="background-image: url(http://libero.mikado-themes.com/wp-content/uploads/2015/11/h-main-new-slide-3.jpg)">
                                                            <div class="mkd-fullwidth-slider-item-image-holder-wrapper">
        <span class="mkd-fullwidth-slider-item-image-holder">
            <img src="/image/h-main-new-slide-3.jpg"
                 class="attachment-full" alt="a" width="1920" height="540">        </span>
                                                            </div>
                                                            <div class="mkd-fullwidth-slider-item-content-holder">
                                                                <div class="mkd-fullwidth-slider-item-content-holder-inner">
                                                                    <div class="mkd-fullwidth-slider-item-content-wrapper">
                                                                        <div class="mkd-fullwidth-slider-item-wrapper-inner">
                                                                            <div class="mkd-fullwidth-slider-item-elements-holder">
                                                                                <div class="mkd-fullwidth-slider-item-title">
                                                                                    <h1>Intellectual Property</h1>
                                                                                </div>
                                                                                <div class="mkd-fullwidth-slider-item-text">
                                                                                    <h3>Maybe it won’t get that far,
                                                                                        but those
                                                                                        who care about these
                                                                                        international law disputes
                                                                                        think China and the U.S.
                                                                                        are on a collision course
                                                                                        because both sides hew
                                                                                        closely to
                                                                                        contradictory readings of
                                                                                        international law.</h3>
                                                                                </div>
                                                                                <div class="mkd-fullwidth-slider-item-button">
                                                                                    <a href="#" target="_self"
                                                                                       class="mkd-btn mkd-btn-medium mkd-btn-solid mkd-btn-icon">
                                                                                        <span class="mkd-btn-text">Contact us</span><span
                                                                                                class="mkd-btn-icon-holder">            <span
                                                                                                    aria-hidden="true"
                                                                                                    class="mkd-icon-font-elegant arrow_triangle-right mkd-btn-icon-elem"></span>            <span
                                                                                                    aria-hidden="true"
                                                                                                    class="mkd-icon-font-elegant arrow_triangle-right mkd-btn-icon-elem"></span>        </span>
                                                                                    </a></div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="owl-item" style="width: 1349px;">
                                                        <div class="mkd-fullwidth-slider-item"
                                                             style="background-image: url(http://libero.mikado-themes.com/wp-content/uploads/2015/11/h-main-new-slide-1.jpg)">
                                                            <div class="mkd-fullwidth-slider-item-image-holder-wrapper">
        <span class="mkd-fullwidth-slider-item-image-holder">
            <img src="/image/h-main-new-slide-1.jpg"
                 class="attachment-full" alt="a" width="1917" height="540">        </span>
                                                            </div>
                                                            <div class="mkd-fullwidth-slider-item-content-holder">
                                                                <div class="mkd-fullwidth-slider-item-content-holder-inner">
                                                                    <div class="mkd-fullwidth-slider-item-content-wrapper">
                                                                        <div class="mkd-fullwidth-slider-item-wrapper-inner">
                                                                            <div class="mkd-fullwidth-slider-item-elements-holder">
                                                                                <div class="mkd-fullwidth-slider-item-title">
                                                                                    <h1>20 years of experience in
                                                                                        various malpractice
                                                                                        cases</h1>
                                                                                </div>
                                                                                <div class="mkd-fullwidth-slider-item-text">
                                                                                    <h3>Maybe it won’t get that far,
                                                                                        but those
                                                                                        who care about these
                                                                                        international law disputes
                                                                                        think China and the U.S.
                                                                                        are on a collision course
                                                                                        because both sides hew
                                                                                        closely to
                                                                                        contradictory readings of
                                                                                        international law.</h3>
                                                                                </div>
                                                                                <div class="mkd-fullwidth-slider-item-button">
                                                                                    <a href="#" target="_self"
                                                                                       class="mkd-btn mkd-btn-medium mkd-btn-solid mkd-btn-icon">
                                                                                        <span class="mkd-btn-text">Contact us</span><span
                                                                                                class="mkd-btn-icon-holder">            <span
                                                                                                    aria-hidden="true"
                                                                                                    class="mkd-icon-font-elegant arrow_triangle-right mkd-btn-icon-elem"></span>            <span
                                                                                                    aria-hidden="true"
                                                                                                    class="mkd-icon-font-elegant arrow_triangle-right mkd-btn-icon-elem"></span>        </span>
                                                                                    </a></div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="owl-item" style="width: 1349px;">
                                                        <div class="mkd-fullwidth-slider-item"
                                                             style="background-image: url(http://libero.mikado-themes.com/wp-content/uploads/2015/11/h-main-new-slide-2.jpg)">
                                                            <div class="mkd-fullwidth-slider-item-image-holder-wrapper">
        <span class="mkd-fullwidth-slider-item-image-holder">
            <img src="/image/h-main-new-slide-2.jpg"
                 class="attachment-full" alt="a" width="1920" height="540">        </span>
                                                            </div>
                                                            <div class="mkd-fullwidth-slider-item-content-holder">
                                                                <div class="mkd-fullwidth-slider-item-content-holder-inner">
                                                                    <div class="mkd-fullwidth-slider-item-content-wrapper">
                                                                        <div class="mkd-fullwidth-slider-item-wrapper-inner">
                                                                            <div class="mkd-fullwidth-slider-item-elements-holder">
                                                                                <div class="mkd-fullwidth-slider-item-title">
                                                                                    <h1>Banking and Finance</h1>
                                                                                </div>
                                                                                <div class="mkd-fullwidth-slider-item-text">
                                                                                    <h3>Maybe it won’t get that far,
                                                                                        but those
                                                                                        who care about these
                                                                                        international law disputes
                                                                                        think China and the U.S.
                                                                                        are on a collision course
                                                                                        because both sides hew
                                                                                        closely to
                                                                                        contradictory readings of
                                                                                        international law.</h3>
                                                                                </div>
                                                                                <div class="mkd-fullwidth-slider-item-button">
                                                                                    <a href="#" target="_self"
                                                                                       class="mkd-btn mkd-btn-medium mkd-btn-solid mkd-btn-icon">
                                                                                        <span class="mkd-btn-text">Contact us</span><span
                                                                                                class="mkd-btn-icon-holder">            <span
                                                                                                    aria-hidden="true"
                                                                                                    class="mkd-icon-font-elegant arrow_triangle-right mkd-btn-icon-elem"></span>            <span
                                                                                                    aria-hidden="true"
                                                                                                    class="mkd-icon-font-elegant arrow_triangle-right mkd-btn-icon-elem"></span>        </span>
                                                                                    </a></div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="owl-item active" style="width: 1349px;">
                                                        <div class="mkd-fullwidth-slider-item"
                                                             style="background-image: url(http://libero.mikado-themes.com/wp-content/uploads/2015/11/h-main-new-slide-4.jpg)">
                                                            <div class="mkd-fullwidth-slider-item-image-holder-wrapper">
        <span class="mkd-fullwidth-slider-item-image-holder">
            <img src="/image/h-main-new-slide-4.jpg"
                 class="attachment-full" alt="a" width="1920" height="540">        </span>
                                                            </div>
                                                            <div class="mkd-fullwidth-slider-item-content-holder">
                                                                <div class="mkd-fullwidth-slider-item-content-holder-inner">
                                                                    <div class="mkd-fullwidth-slider-item-content-wrapper">
                                                                        <div class="mkd-fullwidth-slider-item-wrapper-inner">
                                                                            <div class="mkd-fullwidth-slider-item-elements-holder">
                                                                                <div class="mkd-fullwidth-slider-item-title">
                                                                                    <h1>Corporate Lawsuits</h1>
                                                                                </div>
                                                                                <div class="mkd-fullwidth-slider-item-text">
                                                                                    <h3>Maybe it won’t get that far,
                                                                                        but those
                                                                                        who care about these
                                                                                        international law disputes
                                                                                        think China and the U.S.
                                                                                        are on a collision course
                                                                                        because both sides hew
                                                                                        closely to
                                                                                        contradictory readings of
                                                                                        international law.</h3>
                                                                                </div>
                                                                                <div class="mkd-fullwidth-slider-item-button">
                                                                                    <a href="#" target="_self"
                                                                                       class="mkd-btn mkd-btn-medium mkd-btn-solid mkd-btn-icon">
                                                                                        <span class="mkd-btn-text">Contact us</span><span
                                                                                                class="mkd-btn-icon-holder">            <span
                                                                                                    aria-hidden="true"
                                                                                                    class="mkd-icon-font-elegant arrow_triangle-right mkd-btn-icon-elem"></span>            <span
                                                                                                    aria-hidden="true"
                                                                                                    class="mkd-icon-font-elegant arrow_triangle-right mkd-btn-icon-elem"></span>        </span>
                                                                                    </a></div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>


                                            <div class="owl-controls clickable">
                                                <div class="owl-pagination">
                                                    <div class="owl-page"><span class=""></span></div>
                                                    <div class="owl-page"><span class=""></span></div>
                                                    <div class="owl-page"><span class=""></span></div>
                                                    <div class="owl-page active"><span class=""></span></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div data-mkd-parallax-speed="1"
                         class="vc_row wpb_row vc_row-fluid mkd-section vc_custom_1450197389208 mkd-content-aligment-center mkd-grid-section"
                         style="">
                        <div class="clearfix mkd-section-inner">
                            <div class="mkd-section-inner-margin clearfix">
                                <div class="wpb_column vc_column_container vc_col-sm-12">
                                    <div class="wpb_wrapper">
                                        <div class="mkd-separator-holder clearfix  mkd-separator-center mkd-separator-with-icon mkd-animate"
                                             style="margin-top: 20px; margin-bottom: 25px">
                                            <div class="mkd-separator"
                                                 style="border-color: #c18f59;border-style: solid;width: 97.5px"></div>
                                            <div class="mkd-separator-icon">
                                                <img src="/image/h1-separator-custom-icon-1.png"
                                                     class="attachment-full" alt="a" width="34" height="23"></div>
                                            <div class="mkd-separator"
                                                 style="border-color: #c18f59;border-style: solid;width: 97.5px"></div>
                                        </div>

                                        <div class="wpb_text_column wpb_content_element ">
                                            <div class="wpb_wrapper">
                                                <h1><span style="color: #c18f59;">What Our Clients</span> Say About
                                                    Our Services</h1>

                                            </div>
                                        </div>
                                        <div class="vc_empty_space" style="height: 27px"><span
                                                    class="vc_empty_space_inner"></span></div>

                                        <div class="wpb_text_column wpb_content_element ">
                                            <div class="wpb_wrapper">
                                                <h3>Our&nbsp;lawyers will also represent you in civil litigation
                                                    cases such as&nbsp;divorce, child and spouse maintenance.</h3>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div data-mkd-parallax-speed="1"
                         class="vc_row wpb_row vc_row-fluid mkd-section vc_custom_1449145319025 mkd-content-aligment-left mkd-grid-section"
                         style="">
                        <div class="clearfix mkd-section-inner">
                            <div class="mkd-section-inner-margin clearfix">
                                <div class="wpb_column vc_column_container vc_col-sm-12 vc_col-lg-6 vc_col-md-12">
                                    <div class="wpb_wrapper">
                                        <div class="mkd-video-box">
                                            <a class="mkd-video-image"
                                               href="https://www.youtube.com/watch?v=k6rglSvoQgw"
                                               data-rel="prettyPhoto">
                                                <img src="/image/video-box-image-new.jpg"
                                                     class="attachment-full" alt="a" width="800" height="485">        <span
                                                        class="mkd-video-box-button-holder mkd-video-has-desc">
            <span class="mkd-video-box-button">
            	<span class="mkd-video-box-button-arrow"></span>
        	</span>
        </span>
                                            </a>
                                            <div class="mkd-video-box-text mkd-vtext-appear">
                                                <span class="mkd-video-box-title">The Functioning of The Organization</span>
                                                <p>Comparison between various civil law and private law
                                                    institutions.</p>
                                            </div>
                                        </div>
                                        <div class="vc_empty_space" style="height: 85px"><span
                                                    class="vc_empty_space_inner"></span></div>
                                    </div>
                                </div>
                                <div class="wpb_column vc_column_container vc_col-sm-12 vc_col-lg-6 vc_col-md-12">
                                    <div class="wpb_wrapper">
                                        <div class="mkd-testimonials-holder clearfix">
                                            <div class="mkd-testimonials owl-carousel owl-theme"
                                                 style="opacity: 1; display: block;">
                                                <div class="owl-wrapper-outer autoHeight" style="height: 351px;">
                                                    <div class="owl-wrapper"
                                                         style="width: 5350px; left: 0px; display: block; transition: all 0ms ease 0s; transform: translate3d(0px, 0px, 0px); transform-origin: 267.5px 50% 0px; perspective-origin: 267.5px 50%;">
                                                        <div class="owl-item active" style="width: 535px;">
                                                            <div class="item-inner">
                                                                <div id="mkd-testimonials321"
                                                                     class="mkd-testimonial-content clearfix">
                                                                    <div class="mkd-testimonial-image-holder">
                                                                        <img src="/image/testimonials-3.png"
                                                                             class="attachment-321 wp-post-image"
                                                                             alt="a" width="100" height="100"></div>
                                                                    <div class="mkd-testimonial-content-inner">
                                                                        <div class="mkd-testimonial-text-holder">
                                                                            <div class="mkd-testimonial-text-inner">
                                                                                <div class="mkd-testimonial-quote">
                                                                                        <span aria-hidden="true"
                                                                                              class="icon_quotations"></span>
                                                                                </div>
                                                                                <p class="mkd-testimonial-text">
                                                                                    Every act, every deed of justice
                                                                                    and mercy and benevolence, makes
                                                                                    heavenly music in Heaven.</p>
                                                                                <div class="mkd-testimonial-author">
                                                                                    <p class="mkd-testimonial-author-text">
                                                                                        Ellen G. White <span
                                                                                                class="mkd-testimonials-job"> | Secret Service</span>
                                                                                    </p>
                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div id="mkd-testimonials320"
                                                                     class="mkd-testimonial-content clearfix">
                                                                    <div class="mkd-testimonial-image-holder">
                                                                        <img src="/image/testimonials-1.png"
                                                                             class="attachment-320 wp-post-image"
                                                                             alt="a" width="100" height="100"></div>
                                                                    <div class="mkd-testimonial-content-inner">
                                                                        <div class="mkd-testimonial-text-holder">
                                                                            <div class="mkd-testimonial-text-inner">
                                                                                <div class="mkd-testimonial-quote">
                                                                                        <span aria-hidden="true"
                                                                                              class="icon_quotations"></span>
                                                                                </div>
                                                                                <p class="mkd-testimonial-text">I
                                                                                    believe that religious duties
                                                                                    consist in doing justice, loving
                                                                                    mercy, and making others
                                                                                    happy.</p>
                                                                                <div class="mkd-testimonial-author">
                                                                                    <p class="mkd-testimonial-author-text">
                                                                                        Thomas Paine <span
                                                                                                class="mkd-testimonials-job"> | Penologist</span>
                                                                                    </p>
                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div id="mkd-testimonials319"
                                                                     class="mkd-testimonial-content clearfix">
                                                                    <div class="mkd-testimonial-image-holder">
                                                                        <img src="/image/testimonials-1.png"
                                                                             class="attachment-319 wp-post-image"
                                                                             alt="a" width="100" height="100"></div>
                                                                    <div class="mkd-testimonial-content-inner">
                                                                        <div class="mkd-testimonial-text-holder">
                                                                            <div class="mkd-testimonial-text-inner">
                                                                                <div class="mkd-testimonial-quote">
                                                                                        <span aria-hidden="true"
                                                                                              class="icon_quotations"></span>
                                                                                </div>
                                                                                <p class="mkd-testimonial-text">
                                                                                    There can be no justice without
                                                                                    truth. And there can be no
                                                                                    truth, unless someone rises up
                                                                                    to tell you the truth.</p>
                                                                                <div class="mkd-testimonial-author">
                                                                                    <p class="mkd-testimonial-author-text">
                                                                                        Louis Farrakhan <span
                                                                                                class="mkd-testimonials-job"> | Parole Officer</span>
                                                                                    </p>
                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="owl-item" style="width: 535px;">
                                                            <div class="item-inner">
                                                                <div id="mkd-testimonials317"
                                                                     class="mkd-testimonial-content clearfix">
                                                                    <div class="mkd-testimonial-image-holder">
                                                                        <img src="/image/testimonals-4.png"
                                                                             class="attachment-317 wp-post-image"
                                                                             alt="a" width="100" height="100"></div>
                                                                    <div class="mkd-testimonial-content-inner">
                                                                        <div class="mkd-testimonial-text-holder">
                                                                            <div class="mkd-testimonial-text-inner">
                                                                                <div class="mkd-testimonial-quote">
                                                                                        <span aria-hidden="true"
                                                                                              class="icon_quotations"></span>
                                                                                </div>
                                                                                <p class="mkd-testimonial-text">All
                                                                                    the great things are simple, and
                                                                                    many can be expressed in a
                                                                                    single word: freedom, justice,
                                                                                    honor.</p>
                                                                                <div class="mkd-testimonial-author">
                                                                                    <p class="mkd-testimonial-author-text">
                                                                                        Samuel Morris <span
                                                                                                class="mkd-testimonials-job"> | Paralegal</span>
                                                                                    </p>
                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div id="mkd-testimonials315"
                                                                     class="mkd-testimonial-content clearfix">
                                                                    <div class="mkd-testimonial-image-holder">
                                                                        <img src="/image/testimonials-2.png"
                                                                             class="attachment-315 wp-post-image"
                                                                             alt="a" width="100" height="100"></div>
                                                                    <div class="mkd-testimonial-content-inner">
                                                                        <div class="mkd-testimonial-text-holder">
                                                                            <div class="mkd-testimonial-text-inner">
                                                                                <div class="mkd-testimonial-quote">
                                                                                        <span aria-hidden="true"
                                                                                              class="icon_quotations"></span>
                                                                                </div>
                                                                                <p class="mkd-testimonial-text">We
                                                                                    must weed out corruption and
                                                                                    build a strong system of justice
                                                                                    that the people can trust.</p>
                                                                                <div class="mkd-testimonial-author">
                                                                                    <p class="mkd-testimonial-author-text">
                                                                                        Gloria Macapagal <span
                                                                                                class="mkd-testimonials-job"> | Secretary</span>
                                                                                    </p>
                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div id="mkd-testimonials314"
                                                                     class="mkd-testimonial-content clearfix">
                                                                    <div class="mkd-testimonial-image-holder">
                                                                        <img src="/image/testimonials-3.png"
                                                                             class="attachment-314 wp-post-image"
                                                                             alt="a" width="100" height="100"></div>
                                                                    <div class="mkd-testimonial-content-inner">
                                                                        <div class="mkd-testimonial-text-holder">
                                                                            <div class="mkd-testimonial-text-inner">
                                                                                <div class="mkd-testimonial-quote">
                                                                                        <span aria-hidden="true"
                                                                                              class="icon_quotations"></span>
                                                                                </div>
                                                                                <p class="mkd-testimonial-text">
                                                                                    Equal rights, fair play,
                                                                                    justice, are all like the air:
                                                                                    we all have it, or none of us
                                                                                    has it. That is the truth of
                                                                                    it.</p>
                                                                                <div class="mkd-testimonial-author">
                                                                                    <p class="mkd-testimonial-author-text">
                                                                                        Maya Angelou <span
                                                                                                class="mkd-testimonials-job"> | Law Clerk</span>
                                                                                    </p>
                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="owl-item" style="width: 535px;">
                                                            <div class="item-inner">
                                                                <div id="mkd-testimonials313"
                                                                     class="mkd-testimonial-content clearfix">
                                                                    <div class="mkd-testimonial-image-holder">
                                                                        <img src="/image/testimonials-1.png"
                                                                             class="attachment-313 wp-post-image"
                                                                             alt="a" width="100" height="100"></div>
                                                                    <div class="mkd-testimonial-content-inner">
                                                                        <div class="mkd-testimonial-text-holder">
                                                                            <div class="mkd-testimonial-text-inner">
                                                                                <div class="mkd-testimonial-quote">
                                                                                        <span aria-hidden="true"
                                                                                              class="icon_quotations"></span>
                                                                                </div>
                                                                                <p class="mkd-testimonial-text">
                                                                                    There is a higher court than
                                                                                    courts of justice and that is
                                                                                    the court of conscience. It
                                                                                    supercedes all other courts.</p>
                                                                                <div class="mkd-testimonial-author">
                                                                                    <p class="mkd-testimonial-author-text">
                                                                                        Jimmy Spense <span
                                                                                                class="mkd-testimonials-job"> | U.S. Marshal</span>
                                                                                    </p>
                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div id="mkd-testimonials311"
                                                                     class="mkd-testimonial-content clearfix">
                                                                    <div class="mkd-testimonial-image-holder">
                                                                        <img src="/image/testimonials-2.png"
                                                                             class="attachment-311 wp-post-image"
                                                                             alt="a" width="100" height="100"></div>
                                                                    <div class="mkd-testimonial-content-inner">
                                                                        <div class="mkd-testimonial-text-holder">
                                                                            <div class="mkd-testimonial-text-inner">
                                                                                <div class="mkd-testimonial-quote">
                                                                                        <span aria-hidden="true"
                                                                                              class="icon_quotations"></span>
                                                                                </div>
                                                                                <p class="mkd-testimonial-text">At
                                                                                    his best, man is the noblest of
                                                                                    all animals; separated from law
                                                                                    and justice he is the worst.</p>
                                                                                <div class="mkd-testimonial-author">
                                                                                    <p class="mkd-testimonial-author-text">
                                                                                        Monica Sheets <span
                                                                                                class="mkd-testimonials-job"> | Customs Agent</span>
                                                                                    </p>
                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div id="mkd-testimonials310"
                                                                     class="mkd-testimonial-content clearfix">
                                                                    <div class="mkd-testimonial-image-holder">
                                                                        <img src="/image/testimonals-4.png"
                                                                             class="attachment-310 wp-post-image"
                                                                             alt="a" width="100" height="100"></div>
                                                                    <div class="mkd-testimonial-content-inner">
                                                                        <div class="mkd-testimonial-text-holder">
                                                                            <div class="mkd-testimonial-text-inner">
                                                                                <div class="mkd-testimonial-quote">
                                                                                        <span aria-hidden="true"
                                                                                              class="icon_quotations"></span>
                                                                                </div>
                                                                                <p class="mkd-testimonial-text">
                                                                                    Every step toward justice
                                                                                    requires suffering and struggle;
                                                                                    the tireless concern of
                                                                                    dedicated individuals.</p>
                                                                                <div class="mkd-testimonial-author">
                                                                                    <p class="mkd-testimonial-author-text">
                                                                                        Martin Crane <span
                                                                                                class="mkd-testimonials-job"> | Investigator</span>
                                                                                    </p>
                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="owl-item" style="width: 535px;">
                                                            <div class="item-inner">
                                                                <div id="mkd-testimonials307"
                                                                     class="mkd-testimonial-content clearfix">
                                                                    <div class="mkd-testimonial-image-holder">
                                                                        <img src="/image/testimonials-3.png"
                                                                             class="attachment-307 wp-post-image"
                                                                             alt="a" width="100" height="100"></div>
                                                                    <div class="mkd-testimonial-content-inner">
                                                                        <div class="mkd-testimonial-text-holder">
                                                                            <div class="mkd-testimonial-text-inner">
                                                                                <div class="mkd-testimonial-quote">
                                                                                        <span aria-hidden="true"
                                                                                              class="icon_quotations"></span>
                                                                                </div>
                                                                                <p class="mkd-testimonial-text">I
                                                                                    have been surrounded by the most
                                                                                    caring lawyers, by agents who
                                                                                    are willing to risk their lives
                                                                                    for others.</p>
                                                                                <div class="mkd-testimonial-author">
                                                                                    <p class="mkd-testimonial-author-text">
                                                                                        Janet Reno <span
                                                                                                class="mkd-testimonials-job"> | Court Administrator</span>
                                                                                    </p>
                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div id="mkd-testimonials305"
                                                                     class="mkd-testimonial-content clearfix">
                                                                    <div class="mkd-testimonial-image-holder">
                                                                        <img src="/image/testimonials-1.png"
                                                                             class="attachment-305 wp-post-image"
                                                                             alt="a" width="100" height="100"></div>
                                                                    <div class="mkd-testimonial-content-inner">
                                                                        <div class="mkd-testimonial-text-holder">
                                                                            <div class="mkd-testimonial-text-inner">
                                                                                <div class="mkd-testimonial-quote">
                                                                                        <span aria-hidden="true"
                                                                                              class="icon_quotations"></span>
                                                                                </div>
                                                                                <p class="mkd-testimonial-text">
                                                                                    Justice consists in doing no
                                                                                    injury to men; decency in giving
                                                                                    them no offense.</p>
                                                                                <div class="mkd-testimonial-author">
                                                                                    <p class="mkd-testimonial-author-text">
                                                                                        Marcus Thompson <span
                                                                                                class="mkd-testimonials-job"> | Coroner</span>
                                                                                    </p>
                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div id="mkd-testimonials304"
                                                                     class="mkd-testimonial-content clearfix">
                                                                    <div class="mkd-testimonial-image-holder">
                                                                        <img src="/image/testimonials-2.png"
                                                                             class="attachment-304 wp-post-image"
                                                                             alt="a" width="100" height="100"></div>
                                                                    <div class="mkd-testimonial-content-inner">
                                                                        <div class="mkd-testimonial-text-holder">
                                                                            <div class="mkd-testimonial-text-inner">
                                                                                <div class="mkd-testimonial-quote">
                                                                                        <span aria-hidden="true"
                                                                                              class="icon_quotations"></span>
                                                                                </div>
                                                                                <p class="mkd-testimonial-text">I
                                                                                    realized in law school is that
                                                                                    I'd never think the same again -
                                                                                    being a lawyer is a part of who
                                                                                    I am now.</p>
                                                                                <div class="mkd-testimonial-author">
                                                                                    <p class="mkd-testimonial-author-text">
                                                                                        Anita Hill <span
                                                                                                class="mkd-testimonials-job"> | Correctional Officer</span>
                                                                                    </p>
                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="owl-item" style="width: 535px;">
                                                            <div class="item-inner">
                                                                <div id="mkd-testimonials299"
                                                                     class="mkd-testimonial-content clearfix">
                                                                    <div class="mkd-testimonial-image-holder">
                                                                        <img src="/image/testimonals-4.png"
                                                                             class="attachment-299 wp-post-image"
                                                                             alt="a" width="100" height="100"></div>
                                                                    <div class="mkd-testimonial-content-inner">
                                                                        <div class="mkd-testimonial-text-holder">
                                                                            <div class="mkd-testimonial-text-inner">
                                                                                <div class="mkd-testimonial-quote">
                                                                                        <span aria-hidden="true"
                                                                                              class="icon_quotations"></span>
                                                                                </div>
                                                                                <p class="mkd-testimonial-text">It
                                                                                    is not what a lawyer tells me I
                                                                                    may do; but what humanity,
                                                                                    reason, and justice tell me I
                                                                                    ought to do.</p>
                                                                                <div class="mkd-testimonial-author">
                                                                                    <p class="mkd-testimonial-author-text">
                                                                                        Edmund Burke <span
                                                                                                class="mkd-testimonials-job"> | Border Patroler</span>
                                                                                    </p>
                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div id="mkd-testimonials298"
                                                                     class="mkd-testimonial-content clearfix">
                                                                    <div class="mkd-testimonial-image-holder">
                                                                        <img src="/image/testimonials-3.png"
                                                                             class="attachment-298 wp-post-image"
                                                                             alt="a" width="100" height="100"></div>
                                                                    <div class="mkd-testimonial-content-inner">
                                                                        <div class="mkd-testimonial-text-holder">
                                                                            <div class="mkd-testimonial-text-inner">
                                                                                <div class="mkd-testimonial-quote">
                                                                                        <span aria-hidden="true"
                                                                                              class="icon_quotations"></span>
                                                                                </div>
                                                                                <p class="mkd-testimonial-text">
                                                                                    Justice in the life and conduct
                                                                                    of the State is possible only as
                                                                                    first it resides in the hearts
                                                                                    of the citizens.</p>
                                                                                <div class="mkd-testimonial-author">
                                                                                    <p class="mkd-testimonial-author-text">
                                                                                        Anita Christian <span
                                                                                                class="mkd-testimonials-job"> | Attorney</span>
                                                                                    </p>
                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div id="mkd-testimonials291"
                                                                     class="mkd-testimonial-content clearfix">
                                                                    <div class="mkd-testimonial-image-holder">
                                                                        <img src="/image/testimonials-1.png"
                                                                             class="attachment-291 wp-post-image"
                                                                             alt="a" width="100" height="100"></div>
                                                                    <div class="mkd-testimonial-content-inner">
                                                                        <div class="mkd-testimonial-text-holder">
                                                                            <div class="mkd-testimonial-text-inner">
                                                                                <div class="mkd-testimonial-quote">
                                                                                        <span aria-hidden="true"
                                                                                              class="icon_quotations"></span>
                                                                                </div>
                                                                                <p class="mkd-testimonial-text">
                                                                                    Ethics is knowing the difference
                                                                                    between what you have a right to
                                                                                    do and what is right to do.</p>
                                                                                <div class="mkd-testimonial-author">
                                                                                    <p class="mkd-testimonial-author-text">
                                                                                        Potter Stewart <span
                                                                                                class="mkd-testimonials-job"> | Judge</span>
                                                                                    </p>
                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>


                                                <div class="owl-controls clickable">
                                                    <div class="owl-pagination">
                                                        <div class="owl-page active"><span class=""></span></div>
                                                        <div class="owl-page"><span class=""></span></div>
                                                        <div class="owl-page"><span class=""></span></div>
                                                        <div class="owl-page"><span class=""></span></div>
                                                        <div class="owl-page"><span class=""></span></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="vc_empty_space" style="height: 85px"><span
                                                    class="vc_empty_space_inner"></span></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div data-mkd-parallax-speed="1"
                         class="vc_row wpb_row vc_row-fluid mkd-section mkd-content-aligment-left" style="">
                        <div class="clearfix mkd-full-section-inner">
                            <div class="wpb_column vc_column_container vc_col-sm-12">
                                <div class="wpb_wrapper">
                                    <div class="mkd-image-gallery">
                                        <div class="mkd-image-gallery-grid mkd-gallery-columns-4 mkd-grayscale mkd-image-no-space">
                                            <div class="mkd-gallery-image">
                                                <a href="http://libero.mikado-themes.com/wp-content/uploads/2015/11/h-main-img-gallery-1.jpg"
                                                   data-rel="prettyPhoto[single_pretty_photo]"
                                                   title="h-main-img-gallery-1">
                                                    <img src="/image/h-main-img-gallery-1.jpg"
                                                         alt="h-main-img-gallery-1" width="480" height="480">
                                                </a>
                                            </div>
                                            <div class="mkd-gallery-image">
                                                <a href="http://libero.mikado-themes.com/wp-content/uploads/2015/11/h-main-img-gallery-2.jpg"
                                                   data-rel="prettyPhoto[single_pretty_photo]"
                                                   title="h-main-img-gallery-2">
                                                    <img src="/image/h-main-img-gallery-2.jpg"
                                                         alt="h-main-img-gallery-2" width="480" height="480">
                                                </a>
                                            </div>
                                            <div class="mkd-gallery-image">
                                                <a href="http://libero.mikado-themes.com/wp-content/uploads/2015/11/h-main-img-gallery-3.jpg"
                                                   data-rel="prettyPhoto[single_pretty_photo]"
                                                   title="h-main-img-gallery-3">
                                                    <img src="/image/h-main-img-gallery-3.jpg"
                                                         alt="h-main-img-gallery-3" width="480" height="480">
                                                </a>
                                            </div>
                                            <div class="mkd-gallery-image">
                                                <a href="http://libero.mikado-themes.com/wp-content/uploads/2015/11/h-main-img-gallery-4.jpg"
                                                   data-rel="prettyPhoto[single_pretty_photo]"
                                                   title="h-main-img-gallery-4">
                                                    <img src="/image/h-main-img-gallery-4.jpg"
                                                         alt="h-main-img-gallery-4" width="480" height="480">
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div data-mkd-parallax-speed="1"
                         class="vc_row wpb_row vc_row-fluid mkd-section vc_custom_1450194926053 mkd-content-aligment-center mkd-grid-section"
                         style="">
                        <div class="clearfix mkd-section-inner">
                            <div class="mkd-section-inner-margin clearfix">
                                <div class="wpb_column vc_column_container vc_col-sm-12">
                                    <div class="wpb_wrapper">
                                        <div class="wpb_text_column wpb_content_element ">
                                            <div class="wpb_wrapper">
                                                <h3><span style="color: #ffffff;">Our&nbsp;lawyers will also represent you in civil litigation cases such as&nbsp;divorce.</span>
                                                </h3>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div data-mkd-parallax-speed="1"
                         class="vc_row wpb_row vc_row-fluid mkd-section vc_custom_1450194795605 mkd-content-aligment-center mkd-grid-section"
                         style="">
                        <div class="mkd-row-triangle mkd-row-triangle-top mkd-triangle-bkg"
                             style="border-color:#353c4e;"></div>
                        <div class="clearfix mkd-section-inner">
                            <div class="mkd-section-inner-margin clearfix">
                                <div class="wpb_column vc_column_container vc_col-sm-12">
                                    <div class="wpb_wrapper">
                                        <div class="mkd-separator-holder clearfix  mkd-separator-center mkd-separator-with-icon mkd-animate"
                                             style="margin-top: 20px; margin-bottom: 30px">
                                            <div class="mkd-separator"
                                                 style="border-color: #c18f59;border-style: solid;width: 97.5px"></div>
                                            <div class="mkd-separator-icon">
                                                <img src="/image/h1-separator-custom-icon-1.png"
                                                     class="attachment-full" alt="a" width="34" height="23"></div>
                                            <div class="mkd-separator"
                                                 style="border-color: #c18f59;border-style: solid;width: 97.5px"></div>
                                        </div>

                                        <div class="wpb_text_column wpb_content_element ">
                                            <div class="wpb_wrapper">
                                                <h1><span style="color: #c18f59;">Toughest Defense Lawyers</span>
                                                    with Best Results</h1>

                                            </div>
                                        </div>
                                        <div class="vc_empty_space" style="height: 23px"><span
                                                    class="vc_empty_space_inner"></span></div>

                                        <div class="wpb_text_column wpb_content_element ">
                                            <div class="wpb_wrapper">
                                                <h3>Our&nbsp;lawyers will also represent you in civil litigation
                                                    cases such as&nbsp;divorce, child and spouse maintenance.</h3>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div data-mkd-parallax-speed="1"
                         class="vc_row wpb_row vc_row-fluid mkd-section vc_custom_1450197418142 mkd-content-aligment-center mkd-grid-section"
                         style="">
                        <div class="clearfix mkd-section-inner">
                            <div class="mkd-section-inner-margin clearfix">
                                <div class="wpb_column vc_column_container vc_col-sm-6 vc_col-lg-3 vc_col-md-6">
                                    <div class="wpb_wrapper">
                                        <div class="mkd-service-table mkd-service-has-icon">
                                            <div class="mkd-service-table-icon">

    <span class="mkd-icon-shortcode circle mkd-icon-small">

        <i class="mkd-icon-simple-line-icon icon-trophy mkd-icon-element" style=""></i>
                <span class="mkd-background"></span>
    </span>

                                            </div>
                                            <div class="mkd-service-table-inner">
                                                <div class="mkd-service-titles-holder">
                                                    <h4>Immigration Law</h4>
                                                    <h5>what we are best at</h5>
                                                </div>
                                                <div class="mkd-service-table-content">
                                                    <ul>
                                                        <li>Criminal Defense</li>
                                                        <li>Family Disputes</li>
                                                        <li>Broker Fraud</li>
                                                        <li>Domestic Violence</li>
                                                        <li>Medical Malpractice</li>
                                                        <li>Intellectual Property</li>
                                                    </ul>
                                                </div>
                                                <div class="mkd-service-link">
                                                    <a href="http://libero.mikado-themes.com/our-services/"
                                                       target="_self">
                                                        <span> See success rates </span>

                                                        <span class="mkd-service-link-icon arrow_carrot-right_alt2"></span>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="vc_empty_space" style="height: 40px"><span
                                                    class="vc_empty_space_inner"></span></div>
                                    </div>
                                </div>
                                <div class="wpb_column vc_column_container vc_col-sm-6 vc_col-lg-3 vc_col-md-6">
                                    <div class="wpb_wrapper">
                                        <div class="mkd-service-table mkd-service-has-icon">
                                            <div class="mkd-service-table-icon">

    <span class="mkd-icon-shortcode circle mkd-icon-small">

        <i class="mkd-icon-simple-line-icon icon-graduation mkd-icon-element" style=""></i>
                <span class="mkd-background"></span>
    </span>

                                            </div>
                                            <div class="mkd-service-table-inner">
                                                <div class="mkd-service-titles-holder">
                                                    <h4>Banking &amp; Finance</h4>
                                                    <h5>outstanding service</h5>
                                                </div>
                                                <div class="mkd-service-table-content">
                                                    <ul>
                                                        <li>Criminal Defense</li>
                                                        <li>Family Disputes</li>
                                                        <li>Broker Fraud</li>
                                                        <li>Domestic Violence</li>
                                                        <li>Medical Malpractice</li>
                                                        <li>Intellectual Property</li>
                                                    </ul>
                                                </div>
                                                <div class="mkd-service-link">
                                                    <a href="http://libero.mikado-themes.com/our-services/"
                                                       target="_self">
                                                        <span> See success rates </span>

                                                        <span class="mkd-service-link-icon arrow_carrot-right_alt2"></span>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="vc_empty_space" style="height: 40px"><span
                                                    class="vc_empty_space_inner"></span></div>
                                    </div>
                                </div>
                                <div class="wpb_column vc_column_container vc_col-sm-6 vc_col-lg-3 vc_col-md-6">
                                    <div class="wpb_wrapper">
                                        <div class="mkd-service-table mkd-service-has-icon">
                                            <div class="mkd-service-table-icon">

    <span class="mkd-icon-shortcode circle mkd-icon-small">

        <i class="mkd-icon-simple-line-icon icon-badge mkd-icon-element" style=""></i>
                <span class="mkd-background"></span>
    </span>

                                            </div>
                                            <div class="mkd-service-table-inner">
                                                <div class="mkd-service-titles-holder">
                                                    <h4>Employment Law</h4>
                                                    <h5>personal attitude</h5>
                                                </div>
                                                <div class="mkd-service-table-content">
                                                    <ul>
                                                        <li>Criminal Defense</li>
                                                        <li>Family Disputes</li>
                                                        <li>Broker Fraud</li>
                                                        <li>Domestic Violence</li>
                                                        <li>Medical Malpractice</li>
                                                        <li>Intellectual Property</li>
                                                    </ul>
                                                </div>
                                                <div class="mkd-service-link">
                                                    <a href="http://libero.mikado-themes.com/our-services/"
                                                       target="_self">
                                                        <span> See success rates </span>

                                                        <span class="mkd-service-link-icon arrow_carrot-right_alt2"></span>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="vc_empty_space" style="height: 40px"><span
                                                    class="vc_empty_space_inner"></span></div>
                                    </div>
                                </div>
                                <div class="wpb_column vc_column_container vc_col-sm-6 vc_col-lg-3 vc_col-md-6">
                                    <div class="wpb_wrapper">
                                        <div class="mkd-service-table mkd-service-has-icon">
                                            <div class="mkd-service-table-icon">

    <span class="mkd-icon-shortcode circle mkd-icon-small">

        <i class="mkd-icon-simple-line-icon icon-people mkd-icon-element" style=""></i>
                <span class="mkd-background"></span>
    </span>

                                            </div>
                                            <div class="mkd-service-table-inner">
                                                <div class="mkd-service-titles-holder">
                                                    <h4>Foreclosure Defense</h4>
                                                    <h5>civil rights</h5>
                                                </div>
                                                <div class="mkd-service-table-content">
                                                    <ul>
                                                        <li>Criminal Defense</li>
                                                        <li>Family Disputes</li>
                                                        <li>Broker Fraud</li>
                                                        <li>Domestic Violence</li>
                                                        <li>Medical Malpractice</li>
                                                        <li>Intellectual Property</li>
                                                    </ul>
                                                </div>
                                                <div class="mkd-service-link">
                                                    <a href="http://libero.mikado-themes.com/our-services/"
                                                       target="_self">
                                                        <span> See success rates </span>

                                                        <span class="mkd-service-link-icon arrow_carrot-right_alt2"></span>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="vc_empty_space" style="height: 40px"><span
                                                    class="vc_empty_space_inner"></span></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div data-mkd-parallax-speed="1"
                         class="vc_row wpb_row vc_row-fluid mkd-section vc_custom_1449058472937 mkd-content-aligment-left mkd-grid-section mkd-video-background"
                         style="">
                        <div class="mkd-mobile-video-image"
                             style="background-image:url(http://libero.mikado-themes.com/wp-content/uploads/2015/12/video-img.jpg);"></div>
                        <div class="mkd-video-overlay mkd-video-overlay-active"
                             style="background-image:url(http://libero.mikado-themes.com/wp-content/uploads/2015/11/pattern.png);"></div>
                        <div class="mkd-video-wrap mkd-video-visible" style="width: 1379px; height: 583px;"><span
                                    class="mejs-offscreen">Video Player</span>
                            <div id="mep_0" class="mejs-container svg mkd-video mejs-video" tabindex="0"
                                 role="application" aria-label="Video Player" style="width: 1920px; height: 800px;">
                                <div class="mejs-inner">
                                    <div class="mejs-mediaelement">
                                        <video class="mkd-video"
                                               poster="http://libero.mikado-themes.com/wp-content/uploads/2015/12/video-img.jpg"
                                               preload="auto" loop="" autoplay="autoplay" muted="muted"
                                               src="/image/lawyer.webm"
                                               style="width: 1381px; height: 778px;" width="1920" height="800">
                                            <source type="video/webm"
                                                    src="/image/lawyer.webm">
                                            <source type="video/mp4"
                                                    src="/image/lawyer.mp4">
                                            <source type="video/ogg"
                                                    src="/image/lawyer.ogv">
                                            <object type="/flashmediaelement.htm"
                                                    width="320" height="240">
                                                <param name="movie"
                                                       value="http://libero.mikado-themes.com/wp-content/themes/libero/assets/js/flashmediaelement.swf">
                                                <param name="flashvars"
                                                       value="controls=true&amp;file=http://libero.mikado-themes.com/wp-content/uploads/2015/12/lawyer.mp4.mp4">
                                                <img src="/image/video-img.jpg"
                                                     title="No video playback capabilities" alt="Video thumb"
                                                     width="1920" height="800"></object>
                                        </video>
                                    </div>
                                    <div class="mejs-layers">
                                        <div class="mejs-poster mejs-layer"
                                             style="background-image: url(&quot;http://libero.mikado-themes.com/wp-content/uploads/2015/12/video-img.jpg&quot;); width: 1920px; height: 800px; display: none;">
                                            <img src="/image/video-img.jpg"
                                                 width="100%" height="100%"></div>
                                        <div class="mejs-overlay mejs-layer"
                                             style="width: 1920px; height: 800px; display: none;">
                                            <div class="mejs-overlay-loading"><span></span></div>
                                        </div>
                                        <div class="mejs-overlay mejs-layer"
                                             style="display: none; width: 1920px; height: 800px;">
                                            <div class="mejs-overlay-error"></div>
                                        </div>
                                        <div class="mejs-overlay mejs-layer mejs-overlay-play"
                                             style="width: 1920px; height: 0px; display: none;">
                                            <div class="mejs-overlay-button" style="margin-top: -20px;"></div>
                                        </div>
                                    </div>
                                    <div class="mejs-controls" style="visibility: hidden; display: block;">
                                        <div class="mejs-button mejs-playpause-button mejs-pause">
                                            <button type="button" aria-controls="mep_0" title="Pause"
                                                    aria-label="Pause"></button>
                                        </div>
                                        <div class="mejs-time mejs-currenttime-container" role="timer"
                                             aria-live="off"><span class="mejs-currenttime">00:00</span></div>
                                        <div class="mejs-time-rail"><span class="mejs-time-total mejs-time-slider"
                                                                          aria-label="Time Slider" aria-valuemin="0"
                                                                          aria-valuemax="6.007"
                                                                          aria-valuenow="0.491185"
                                                                          aria-valuetext="00:00" role="slider"
                                                                          tabindex="0"><span
                                                        class="mejs-time-buffering"
                                                        style="display: none;"></span><span
                                                        class="mejs-time-loaded"
                                                        style="width: 179.97px;"></span><span
                                                        class="mejs-time-current" style="width: 15px;"></span><span
                                                        class="mejs-time-handle" style="left: 8px;"></span><span
                                                        class="mejs-time-float"><span
                                                            class="mejs-time-float-current">00:00</span><span
                                                            class="mejs-time-float-corner"></span></span></span>
                                        </div>
                                        <div class="mejs-time mejs-duration-container"><span class="mejs-duration">00:06</span>
                                        </div>
                                        <div class="mejs-button mejs-volume-button mejs-mute">
                                            <button type="button" aria-controls="mep_0" title="Mute"
                                                    aria-label="Mute"></button>
                                            <a href="javascript:void(0);" class="mejs-volume-slider"
                                               style="display: none;"><span class="mejs-offscreen">Use Up/Down Arrow keys to increase or decrease volume.</span>
                                                <div class="mejs-volume-total"></div>
                                                <div class="mejs-volume-current"
                                                     style="height: 80px; top: 20px;"></div>
                                                <div class="mejs-volume-handle" style="top: 17px;"></div>
                                            </a></div>
                                        <div class="mejs-button mejs-fullscreen-button">
                                            <button type="button" aria-controls="mep_0" title="Fullscreen"
                                                    aria-label="Fullscreen"></button>
                                        </div>
                                    </div>
                                    <div class="mejs-clear"></div>
                                </div>
                            </div>
                        </div>
                        <div class="clearfix mkd-section-inner">
                            <div class="mkd-section-inner-margin clearfix">
                                <div class="wpb_column vc_column_container vc_col-sm-12 vc_col-lg-6 vc_col-md-12">
                                    <div class="wpb_wrapper">
                                        <div class="mkd-elements-holder mkd-responsive-mode-768">
                                            <div class="mkd-elements-holder-item mkd-horizontal-alignment-left">
                                                <div class="mkd-elements-holder-item-inner">
                                                    <div class="mkd-elements-holder-item-content mkd-elements-holder-custom-694031"
                                                         style="padding: 0px">

                                                        <div class="wpb_text_column wpb_content_element ">
                                                            <div class="wpb_wrapper">
                                                                <h1><span style="color: #ffffff;">Read our expertly written blog or follow us on social media</span>
                                                                </h1>

                                                            </div>
                                                        </div>
                                                        <div class="vc_empty_space" style="height: 20px"><span
                                                                    class="vc_empty_space_inner"></span></div>

                                                        <div class="wpb_text_column wpb_content_element ">
                                                            <div class="wpb_wrapper">
                                                                <p><span style="color: #ffffff;">Maybe it won’t get that far, but
those who care about these international law disputes think China and
the U.S. are on a collision course because both sides hew closely to
contradictory readings of international law. One would assume the
conflict won’t go nuclear.</span></p>

                                                            </div>
                                                        </div>
                                                        <div class="vc_empty_space" style="height: 33px"><span
                                                                    class="vc_empty_space_inner"></span></div>
                                                        <a href="#" target="_self"
                                                           class="mkd-btn mkd-btn-medium mkd-btn-solid mkd-btn-icon">
                                                            <span class="mkd-btn-text">Contact us</span><span
                                                                    class="mkd-btn-icon-holder">
            <span aria-hidden="true" class="mkd-icon-font-elegant arrow_carrot-right mkd-btn-icon-elem"></span>            <span
                                                                        aria-hidden="true"
                                                                        class="mkd-icon-font-elegant arrow_carrot-right mkd-btn-icon-elem"></span>        </span>
                                                        </a>
                                                        <div class="vc_empty_space" style="height: 45px"><span
                                                                    class="vc_empty_space_inner"></span></div>
                                                        <div class="mkd-social-share-holder mkd-list">
                                                            <ul>
                                                                <li class="mkd-facebook-share"
                                                                    style="border-color: rgba(255,255,255,0.1)">
                                                                    <a class="mkd-share-link" href="#"
                                                                       onclick="window.open('http://www.facebook.com/sharer.php?s=100&amp;p[title]=Home+1&amp;p[summary]=&amp;p[url]=http%3A%2F%2Flibero.mikado-themes.com%2F&amp;p[images][0]=', 'sharer', 'toolbar=0,status=0,width=620,height=280');">
                                                                            <span class="mkd-social-network-icon social_facebook"
                                                                                  style="color: #ffffff"
                                                                                  data-hover-color="#c18f59"></span>
                                                                            <span class="mkd-social-network-text"
                                                                                  style="color: #ffffff">Facebook</span>
                                                                    </a>
                                                                </li>
                                                                <li class="mkd-twitter-share"
                                                                    style="border-color: rgba(255,255,255,0.1)">
                                                                    <a class="mkd-share-link" href="#"
                                                                       onclick="window.open('http://twitter.com/home?status=http://libero.mikado-themes.com/', 'popupwindow', 'scrollbars=yes,width=800,height=400');popUp.focus();return false;">
                                                                            <span class="mkd-social-network-icon social_twitter"
                                                                                  style="color: #ffffff"
                                                                                  data-hover-color="#c18f59"></span>
                                                                            <span class="mkd-social-network-text"
                                                                                  style="color: #ffffff">Twitter</span>
                                                                    </a>
                                                                </li>
                                                                <li class="mkd-google_plus-share"
                                                                    style="border-color: rgba(255,255,255,0.1)">
                                                                    <a class="mkd-share-link" href="#"
                                                                       onclick="popUp=window.open('https://plus.google.com/share?url=http%3A%2F%2Flibero.mikado-themes.com%2F', 'popupwindow', 'scrollbars=yes,width=800,height=400');popUp.focus();return false;">
                                                                            <span class="mkd-social-network-icon social_googleplus"
                                                                                  style="color: #ffffff"
                                                                                  data-hover-color="#c18f59"></span>
                                                                            <span class="mkd-social-network-text"
                                                                                  style="color: #ffffff">Google+</span>
                                                                    </a>
                                                                </li>
                                                                <li class="mkd-linkedin-share"
                                                                    style="border-color: rgba(255,255,255,0.1)">
                                                                    <a class="mkd-share-link" href="#"
                                                                       onclick="popUp=window.open('http://linkedin.com/shareArticle?mini=true&amp;url=http%3A%2F%2Flibero.mikado-themes.com%2F&amp;title=Home+1', 'popupwindow', 'scrollbars=yes,width=800,height=400');popUp.focus();return false;">
                                                                            <span class="mkd-social-network-icon social_linkedin"
                                                                                  style="color: #ffffff"
                                                                                  data-hover-color="#c18f59"></span>
                                                                            <span class="mkd-social-network-text"
                                                                                  style="color: #ffffff">LinkedIn</span>
                                                                    </a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                        <div class="vc_empty_space" style="height: 60px"><span
                                                                    class="vc_empty_space_inner"></span></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="wpb_column vc_column_container vc_col-sm-12 vc_col-lg-6 vc_col-md-12">
                                    <div class="wpb_wrapper">
                                        <div class="mkd-elements-holder mkd-responsive-mode-768">
                                            <div class="mkd-elements-holder-item mkd-horizontal-alignment-left">
                                                <div class="mkd-elements-holder-item-inner">
                                                    <div class="mkd-elements-holder-item-content mkd-elements-holder-custom-549667"
                                                         style="padding: 0px">
                                                        <div class="mkd-separator-holder clearfix  mkd-separator-center mkd-separator-full-width"
                                                             style="margin-top: -10px; margin-bottom: 0px; height: 0px">
                                                            <div class="mkd-separator"
                                                                 style="border-color: rgba(255,255,255,0.01);border-bottom-width: 0px"></div>
                                                        </div>
                                                        <div class="vc_empty_space" style="height: 17px"><span
                                                                    class="vc_empty_space_inner"></span></div>
                                                        <div class="mkd-blog-list-holder mkd-minimal ">
                                                            <ul class="mkd-blog-list">
                                                                <li class="mkd-blog-list-item clearfix">
                                                                    <div class="mkd-blog-list-item-inner">
                                                                        <div class="mkd-item-date-holder">

                                                                            <div class="mkd-post-info-date">

                                                                                <span class="mkd-post-info-date-day">18</span>
                                                                                <span class="mkd-post-info-date-month">Jun</span>

                                                                            </div>
                                                                        </div>
                                                                        <div class="mkd-item-text-holder">
                                                                            <a class="mkd-item-minimal-link"
                                                                               href="http://libero.mikado-themes.com/training-in-the-law-in-order-to-become-a-domestic-or-international-legal-adviser/">
                                                                            </a>
                                                                            <h3 class="mkd-item-title">
                                                                                <a href="http://libero.mikado-themes.com/training-in-the-law-in-order-to-become-a-domestic-or-international-legal-adviser/">
                                                                                    Training in The Law in order to
                                                                                    become a Domestic or
                                                                                    International Legal Adviser </a>
                                                                            </h3>
                                                                            <div class="mkd-item-minimal-info">
                                                                                <div class="mkd-post-info-category">
                                                                                    <span class="mkd-post-info-icon icon-clock"></span>
                                                                                    in <a
                                                                                            href="http://libero.mikado-themes.com/category/pro-bono-work/"
                                                                                            rel="category tag">Pro
                                                                                        Bono
                                                                                        Work</a>, <a
                                                                                            href="http://libero.mikado-themes.com/category/training/"
                                                                                            rel="category tag">Training</a>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </li>
                                                                <li class="mkd-blog-list-item clearfix">
                                                                    <div class="mkd-blog-list-item-inner">
                                                                        <div class="mkd-item-date-holder">

                                                                            <div class="mkd-post-info-date">

                                                                                <span class="mkd-post-info-date-day">20</span>
                                                                                <span class="mkd-post-info-date-month">Aug</span>

                                                                            </div>
                                                                        </div>
                                                                        <div class="mkd-item-text-holder">
                                                                            <a class="mkd-item-minimal-link"
                                                                               href="http://libero.mikado-themes.com/how-to-deal-with-your-staff-executives-clients-and-the-board-of-directors/">
                                                                            </a>
                                                                            <h3 class="mkd-item-title">
                                                                                <a href="http://libero.mikado-themes.com/how-to-deal-with-your-staff-executives-clients-and-the-board-of-directors/">
                                                                                    How to deal with Your Staff,
                                                                                    Executives<br>and the Board of
                                                                                    Directors </a>
                                                                            </h3>
                                                                            <div class="mkd-item-minimal-info">
                                                                                <div class="mkd-post-info-category">
                                                                                    <span class="mkd-post-info-icon icon-clock"></span>
                                                                                    in <a
                                                                                            href="http://libero.mikado-themes.com/category/high-pressure/"
                                                                                            rel="category tag">High
                                                                                        Pressure</a>, <a
                                                                                            href="http://libero.mikado-themes.com/category/necessary-forms/"
                                                                                            rel="category tag">Necessary
                                                                                        Forms</a></div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </li>
                                                                <li class="mkd-blog-list-item clearfix">
                                                                    <div class="mkd-blog-list-item-inner">
                                                                        <div class="mkd-item-date-holder">

                                                                            <div class="mkd-post-info-date">

                                                                                <span class="mkd-post-info-date-day">23</span>
                                                                                <span class="mkd-post-info-date-month">Sep</span>

                                                                            </div>
                                                                        </div>
                                                                        <div class="mkd-item-text-holder">
                                                                            <a class="mkd-item-minimal-link"
                                                                               href="http://libero.mikado-themes.com/heading-committees-leading-corporate-meetings-and-making-powerful-presentations/">
                                                                            </a>
                                                                            <h3 class="mkd-item-title">
                                                                                <a href="http://libero.mikado-themes.com/heading-committees-leading-corporate-meetings-and-making-powerful-presentations/">
                                                                                    Heading Committees, Leading
                                                                                    Corporate Meetings and making
                                                                                    Powerful Presentations </a>
                                                                            </h3>
                                                                            <div class="mkd-item-minimal-info">
                                                                                <div class="mkd-post-info-category">
                                                                                    <span class="mkd-post-info-icon icon-clock"></span>
                                                                                    in <a
                                                                                            href="http://libero.mikado-themes.com/category/high-pressure/"
                                                                                            rel="category tag">High
                                                                                        Pressure</a>, <a
                                                                                            href="http://libero.mikado-themes.com/category/legal-advice/"
                                                                                            rel="category tag">Legal
                                                                                        Advice</a></div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                        <div class="vc_empty_space" style="height: 45px"><span
                                                                    class="vc_empty_space_inner"></span></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div data-mkd-parallax-speed="1"
                         class="vc_row wpb_row vc_row-fluid mkd-section vc_custom_1450195972481 mkd-content-aligment-center mkd-grid-section"
                         style="">
                        <div class="clearfix mkd-section-inner">
                            <div class="mkd-section-inner-margin clearfix">
                                <div class="wpb_column vc_column_container vc_col-sm-12">
                                    <div class="wpb_wrapper">
                                        <div class="mkd-separator-holder clearfix  mkd-separator-center mkd-separator-with-icon mkd-animate"
                                             style="margin-top: 20px; margin-bottom: 30px">
                                            <div class="mkd-separator"
                                                 style="border-color: #c18f59;border-style: solid;width: 97.5px"></div>
                                            <div class="mkd-separator-icon">
                                                <img src="/image/h1-separator-custom-icon-1.png"
                                                     class="attachment-full" alt="a" width="34" height="23"></div>
                                            <div class="mkd-separator"
                                                 style="border-color: #c18f59;border-style: solid;width: 97.5px"></div>
                                        </div>

                                        <div class="wpb_text_column wpb_content_element ">
                                            <div class="wpb_wrapper">
                                                <h1>We offer a<span style="color: #c18f59;"> Broad Range </span>of
                                                    Law Services</h1>

                                            </div>
                                        </div>
                                        <div class="vc_empty_space" style="height: 23px"><span
                                                    class="vc_empty_space_inner"></span></div>

                                        <div class="wpb_text_column wpb_content_element ">
                                            <div class="wpb_wrapper">
                                                <h3>Our&nbsp;lawyers will also represent you in civil litigation
                                                    cases such as&nbsp;divorce, child and spouse maintenance.</h3>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div data-mkd-parallax-speed="1"
                         class="vc_row wpb_row vc_row-fluid mkd-section vc_custom_1450197453742 mkd-content-aligment-center mkd-grid-section"
                         style="">
                        <div class="clearfix mkd-section-inner">
                            <div class="mkd-section-inner-margin clearfix">
                                <div class="mkd-row-animations-holder mkd-element-from-fade">
                                    <div>
                                        <div class="wpb_column vc_column_container vc_col-sm-6 vc_col-lg-3 vc_col-md-3">
                                            <div class="wpb_wrapper">
                                                <div class="mkd-interactive-image mkd-animate-image mkd-linked">

                                                    <a href="http://libero.mikado-themes.com/client-testimonials/"></a>
                                                    <img src="/image/h-main-circle-img-1.jpg"
                                                         class="attachment-full" alt="a" width="200" height="200">
                                                </div>
                                                <div class="vc_empty_space" style="height: 22px"><span
                                                            class="vc_empty_space_inner"></span></div>

                                                <div class="wpb_text_column wpb_content_element ">
                                                    <div class="wpb_wrapper">
                                                        <h4>In The Court of law</h4>

                                                    </div>
                                                </div>
                                                <div class="vc_empty_space" style="height: 12px"><span
                                                            class="vc_empty_space_inner"></span></div>

                                                <div class="wpb_text_column wpb_content_element ">
                                                    <div class="wpb_wrapper">
                                                        <p>In conjunction with his vast know-how, our company
                                                            leverages the robust legal expertise of working in
                                                            different courts.</p>

                                                    </div>
                                                </div>
                                                <div class="vc_empty_space" style="height: 40px"><span
                                                            class="vc_empty_space_inner"></span></div>
                                            </div>
                                        </div>
                                        <div class="wpb_column vc_column_container vc_col-sm-6 vc_col-lg-3 vc_col-md-3">
                                            <div class="wpb_wrapper">
                                                <div class="mkd-interactive-image mkd-animate-image mkd-linked">

                                                    <a href="http://libero.mikado-themes.com/about-our-company/"></a>
                                                    <img src="/image/h-main-circle-img-2.jpg"
                                                         class="attachment-full" alt="a" width="200" height="200">
                                                </div>
                                                <div class="vc_empty_space" style="height: 22px"><span
                                                            class="vc_empty_space_inner"></span></div>

                                                <div class="wpb_text_column wpb_content_element ">
                                                    <div class="wpb_wrapper">
                                                        <h4>Direct Way of Justice</h4>

                                                    </div>
                                                </div>
                                                <div class="vc_empty_space" style="height: 12px"><span
                                                            class="vc_empty_space_inner"></span></div>

                                                <div class="wpb_text_column wpb_content_element ">
                                                    <div class="wpb_wrapper">
                                                        <p>In conjunction with his vast know-how, our company
                                                            leverages the robust legal expertise of working in
                                                            different courts.</p>

                                                    </div>
                                                </div>
                                                <div class="vc_empty_space" style="height: 40px"><span
                                                            class="vc_empty_space_inner"></span></div>
                                            </div>
                                        </div>
                                        <div class="wpb_column vc_column_container vc_col-sm-6 vc_col-lg-3 vc_col-md-3">
                                            <div class="wpb_wrapper">
                                                <div class="mkd-interactive-image mkd-animate-image mkd-linked">

                                                    <a href="http://libero.mikado-themes.com/facts/"></a>
                                                    <img src="/image/h-main-circle-img-3.jpg"
                                                         class="attachment-full" alt="a" width="200" height="200">
                                                </div>
                                                <div class="vc_empty_space" style="height: 22px"><span
                                                            class="vc_empty_space_inner"></span></div>

                                                <div class="wpb_text_column wpb_content_element ">
                                                    <div class="wpb_wrapper">
                                                        <h4>Corporate Lawsuits</h4>

                                                    </div>
                                                </div>
                                                <div class="vc_empty_space" style="height: 12px"><span
                                                            class="vc_empty_space_inner"></span></div>

                                                <div class="wpb_text_column wpb_content_element ">
                                                    <div class="wpb_wrapper">
                                                        <p>In conjunction with his vast know-how, our company
                                                            leverages the robust legal expertise of working in
                                                            different courts.</p>

                                                    </div>
                                                </div>
                                                <div class="vc_empty_space" style="height: 40px"><span
                                                            class="vc_empty_space_inner"></span></div>
                                            </div>
                                        </div>
                                        <div class="wpb_column vc_column_container vc_col-sm-6 vc_col-lg-3 vc_col-md-3">
                                            <div class="wpb_wrapper">
                                                <div class="mkd-interactive-image mkd-animate-image mkd-linked">

                                                    <a href="http://libero.mikado-themes.com/our-services/"></a>
                                                    <img src="/image/h-main-circle-img-4.jpg"
                                                         class="attachment-full" alt="a" width="200" height="200">
                                                </div>
                                                <div class="vc_empty_space" style="height: 22px"><span
                                                            class="vc_empty_space_inner"></span></div>

                                                <div class="wpb_text_column wpb_content_element ">
                                                    <div class="wpb_wrapper">
                                                        <h4>Protecting Business</h4>

                                                    </div>
                                                </div>
                                                <div class="vc_empty_space" style="height: 12px"><span
                                                            class="vc_empty_space_inner"></span></div>

                                                <div class="wpb_text_column wpb_content_element ">
                                                    <div class="wpb_wrapper">
                                                        <p>In conjunction with his vast know-how, our company
                                                            leverages the robust legal expertise of working in
                                                            different courts.</p>

                                                    </div>
                                                </div>
                                                <div class="vc_empty_space" style="height: 40px"><span
                                                            class="vc_empty_space_inner"></span></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div data-mkd-parallax-speed="1"
                         class="vc_row wpb_row vc_row-fluid mkd-section vc_custom_1450196350853 mkd-content-aligment-left mkd-grid-section"
                         style="">
                        <div class="clearfix mkd-section-inner">
                            <div class="mkd-section-inner-margin clearfix">
                                <div class="wpb_column vc_column_container vc_col-sm-12 vc_col-lg-6 vc_col-md-12">
                                    <div class="wpb_wrapper">
                                        <div class="mkd-elements-holder mkd-responsive-mode-768">
                                            <div class="mkd-elements-holder-item mkd-horizontal-alignment-left">
                                                <div class="mkd-elements-holder-item-inner">
                                                    <div class="mkd-elements-holder-item-content mkd-elements-holder-custom-776274"
                                                         style="padding: 3% 0 0 0">
                                                        <style type="text/css"
                                                               data-type="mkd-elements-custom-padding" scoped="">
                                                            @media  only screen and (min-width: 1024px) and (max-width: 1280px) {
                                                                .mkd-elements-holder .mkd-elements-holder-item-content.mkd-elements-holder-custom-776274 {
                                                                    padding: 0 !important;
                                                                }
                                                            }

                                                            @media  only screen and (min-width: 768px) and (max-width: 1024px) {
                                                                .mkd-elements-holder .mkd-elements-holder-item-content.mkd-elements-holder-custom-776274 {
                                                                    padding: 0 !important;
                                                                }
                                                            }

                                                            @media  only screen and (min-width: 600px) and (max-width: 768px) {
                                                                .mkd-elements-holder .mkd-elements-holder-item-content.mkd-elements-holder-custom-776274 {
                                                                    padding: 0 !important;
                                                                }
                                                            }

                                                            @media  only screen and (min-width: 480px) and (max-width: 600px) {
                                                                .mkd-elements-holder .mkd-elements-holder-item-content.mkd-elements-holder-custom-776274 {
                                                                    padding: 0 !important;
                                                                }
                                                            }

                                                            @media  only screen and (max-width: 480px) {
                                                                .mkd-elements-holder .mkd-elements-holder-item-content.mkd-elements-holder-custom-776274 {
                                                                    padding: 0 !important;
                                                                }
                                                            }
                                                        </style>

                                                        <div class="wpb_text_column wpb_content_element ">
                                                            <div class="wpb_wrapper">
                                                                <h1><span style="color: #ffffff;">Our experts have been featured in press numerous times</span>
                                                                </h1>

                                                            </div>
                                                        </div>
                                                        <div class="vc_empty_space" style="height: 20px"><span
                                                                    class="vc_empty_space_inner"></span></div>

                                                        <div class="wpb_text_column wpb_content_element ">
                                                            <div class="wpb_wrapper">
                                                                <p><span style="color: #ffffff;">Acquire &nbsp;control of an
uninsured institution or retain, for more than one year after other than
 an insured institution or holding company thereof, the date any insured
 institution subsidiary becomes uninsured, control of such
institution.&nbsp;</span></p>

                                                            </div>
                                                        </div>
                                                        <div class="vc_empty_space" style="height: 30px"><span
                                                                    class="vc_empty_space_inner"></span></div>

                                                        <div class="wpb_single_image wpb_content_element vc_align_left">

                                                            <figure class="wpb_wrapper vc_figure">
                                                                <div class="vc_single_image-wrapper   vc_box_border_grey">
                                                                    <img src="/image/h-main-signature.png"
                                                                         class="vc_single_image-img attachment-full"
                                                                         alt="a" width="208" height="83"></div>
                                                            </figure>
                                                        </div>
                                                        <div class="vc_empty_space" style="height: 45px"><span
                                                                    class="vc_empty_space_inner"></span></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="wpb_column vc_column_container vc_col-sm-12 vc_col-lg-6 vc_col-md-12">
                                    <div class="wpb_wrapper">
                                        <div class="mkd-carousel-holder clearfix" style="opacity: 1;">
                                            <div class="mkd-carousel mkd-carousel-grid mkd-pag-right owl-carousel owl-theme"
                                                 data-autoplay="yes" style="opacity: 1; display: block;">
                                                <div class="owl-wrapper-outer">
                                                    <div class="owl-wrapper"
                                                         style="width: 5340px; left: 0px; display: block; transition: all 400ms ease 0s; transform: translate3d(-534px, 0px, 0px);">
                                                        <div class="owl-item" style="width: 178px;">
                                                            <div class="item-inner">
                                                                <div class="mkd-carousel-item-holder">
                                                                    <div class="mkd-carousel-item-holder-inner">
                                                                        <a href="#" target="_self">
									<span class="mkd-carousel-first-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-1.png"
                         alt="h2-client-1">
				</span>
										<span class="mkd-carousel-second-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-1.png"
                         alt="h2-client-1">
				</span>
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                                <div class="mkd-carousel-item-holder">
                                                                    <div class="mkd-carousel-item-holder-inner">
                                                                        <a href="#" target="_self">
									<span class="mkd-carousel-first-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-4.png"
                         alt="h2-client-10">
				</span>
										<span class="mkd-carousel-second-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-4.png"
                         alt="h2-client-10">
				</span>
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="owl-item" style="width: 178px;">
                                                            <div class="item-inner">
                                                                <div class="mkd-carousel-item-holder">
                                                                    <div class="mkd-carousel-item-holder-inner">
                                                                        <a href="#" target="_self">
									<span class="mkd-carousel-first-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-5.png"
                         alt="h2-client-11">
				</span>
										<span class="mkd-carousel-second-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-5.png"
                         alt="h2-client-11">
				</span>
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                                <div class="mkd-carousel-item-holder">
                                                                    <div class="mkd-carousel-item-holder-inner">
                                                                        <a href="#" target="_self">
									<span class="mkd-carousel-first-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-6.png"
                         alt="h2-client-12">
				</span>
										<span class="mkd-carousel-second-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-6.png"
                         alt="h2-client-12">
				</span>
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="owl-item" style="width: 178px;">
                                                            <div class="item-inner">
                                                                <div class="mkd-carousel-item-holder">
                                                                    <div class="mkd-carousel-item-holder-inner">
                                                                        <a href="#" target="_self">
									<span class="mkd-carousel-first-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-1.png"
                         alt="h2-client-13">
				</span>
										<span class="mkd-carousel-second-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-1.png"
                         alt="h2-client-13">
				</span>
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                                <div class="mkd-carousel-item-holder">
                                                                    <div class="mkd-carousel-item-holder-inner">
                                                                        <a href="#" target="_self">
									<span class="mkd-carousel-first-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-2.png"
                         alt="h2-client-14">
				</span>
										<span class="mkd-carousel-second-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-2.png"
                         alt="h2-client-14">
				</span>
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="owl-item active" style="width: 178px;">
                                                            <div class="item-inner">
                                                                <div class="mkd-carousel-item-holder">
                                                                    <div class="mkd-carousel-item-holder-inner">
                                                                        <a href="#" target="_self">
									<span class="mkd-carousel-first-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-3.png"
                         alt="h2-client-15">
				</span>
										<span class="mkd-carousel-second-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-3.png"
                         alt="h2-client-15">
				</span>
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                                <div class="mkd-carousel-item-holder">
                                                                    <div class="mkd-carousel-item-holder-inner">
                                                                        <a href="#" target="_self">
									<span class="mkd-carousel-first-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-4.png"
                         alt="h2-client-16">
				</span>
										<span class="mkd-carousel-second-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-4.png"
                         alt="h2-client-16">
				</span>
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="owl-item active" style="width: 178px;">
                                                            <div class="item-inner">
                                                                <div class="mkd-carousel-item-holder">
                                                                    <div class="mkd-carousel-item-holder-inner">
                                                                        <a href="#" target="_self">
									<span class="mkd-carousel-first-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-5.png"
                         alt="h2-client-17">
				</span>
										<span class="mkd-carousel-second-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-5.png"
                         alt="h2-client-17">
				</span>
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                                <div class="mkd-carousel-item-holder">
                                                                    <div class="mkd-carousel-item-holder-inner">
                                                                        <a href="#" target="_self">
									<span class="mkd-carousel-first-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-6.png"
                         alt="h2-client-18">
				</span>
										<span class="mkd-carousel-second-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-6.png"
                         alt="h2-client-18">
				</span>
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="owl-item active" style="width: 178px;">
                                                            <div class="item-inner">
                                                                <div class="mkd-carousel-item-holder">
                                                                    <div class="mkd-carousel-item-holder-inner">
                                                                        <a href="#" target="_self">
									<span class="mkd-carousel-first-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-1.png"
                         alt="h2-client-19">
				</span>
										<span class="mkd-carousel-second-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-1.png"
                         alt="h2-client-19">
				</span>
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                                <div class="mkd-carousel-item-holder">
                                                                    <div class="mkd-carousel-item-holder-inner">
                                                                        <a href="#" target="_self">
									<span class="mkd-carousel-first-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-2.png"
                         alt="h2-client-2">
				</span>
										<span class="mkd-carousel-second-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-2.png"
                         alt="h2-client-2">
				</span>
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="owl-item" style="width: 178px;">
                                                            <div class="item-inner">
                                                                <div class="mkd-carousel-item-holder">
                                                                    <div class="mkd-carousel-item-holder-inner">
                                                                        <a href="#" target="_self">
									<span class="mkd-carousel-first-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-2.png"
                         alt="h2-client-20">
				</span>
										<span class="mkd-carousel-second-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-2.png"
                         alt="h2-client-20">
				</span>
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                                <div class="mkd-carousel-item-holder">
                                                                    <div class="mkd-carousel-item-holder-inner">
                                                                        <a href="#" target="_self">
									<span class="mkd-carousel-first-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-3.png"
                         alt="h2-client-21">
				</span>
										<span class="mkd-carousel-second-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-3.png"
                         alt="h2-client-21">
				</span>
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="owl-item" style="width: 178px;">
                                                            <div class="item-inner">
                                                                <div class="mkd-carousel-item-holder">
                                                                    <div class="mkd-carousel-item-holder-inner">
                                                                        <a href="#" target="_self">
									<span class="mkd-carousel-first-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-4.png"
                         alt="h2-client-22">
				</span>
										<span class="mkd-carousel-second-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-4.png"
                         alt="h2-client-22">
				</span>
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                                <div class="mkd-carousel-item-holder">
                                                                    <div class="mkd-carousel-item-holder-inner">
                                                                        <a href="#" target="_self">
									<span class="mkd-carousel-first-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-5.png"
                         alt="h2-client-23">
				</span>
										<span class="mkd-carousel-second-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-5.png"
                         alt="h2-client-23">
				</span>
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="owl-item" style="width: 178px;">
                                                            <div class="item-inner">
                                                                <div class="mkd-carousel-item-holder">
                                                                    <div class="mkd-carousel-item-holder-inner">
                                                                        <a href="#" target="_self">
									<span class="mkd-carousel-first-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-6.png"
                         alt="h2-client-24">
				</span>
										<span class="mkd-carousel-second-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-6.png"
                         alt="h2-client-24">
				</span>
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                                <div class="mkd-carousel-item-holder">
                                                                    <div class="mkd-carousel-item-holder-inner">
                                                                        <a href="#" target="_self">
									<span class="mkd-carousel-first-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-1.png"
                         alt="h2-client-25">
				</span>
										<span class="mkd-carousel-second-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-1.png"
                         alt="h2-client-25">
				</span>
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="owl-item" style="width: 178px;">
                                                            <div class="item-inner">
                                                                <div class="mkd-carousel-item-holder">
                                                                    <div class="mkd-carousel-item-holder-inner">
                                                                        <a href="#" target="_self">
									<span class="mkd-carousel-first-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-2.png"
                         alt="h2-client-26">
				</span>
										<span class="mkd-carousel-second-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-2.png"
                         alt="h2-client-26">
				</span>
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                                <div class="mkd-carousel-item-holder">
                                                                    <div class="mkd-carousel-item-holder-inner">
                                                                        <a href="#" target="_self">
									<span class="mkd-carousel-first-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-3.png"
                         alt="h2-client-27">
				</span>
										<span class="mkd-carousel-second-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-3.png"
                         alt="h2-client-27">
				</span>
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="owl-item" style="width: 178px;">
                                                            <div class="item-inner">
                                                                <div class="mkd-carousel-item-holder">
                                                                    <div class="mkd-carousel-item-holder-inner">
                                                                        <a href="#" target="_self">
									<span class="mkd-carousel-first-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-4.png"
                         alt="h2-client-28">
				</span>
										<span class="mkd-carousel-second-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-4.png"
                         alt="h2-client-28">
				</span>
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                                <div class="mkd-carousel-item-holder">
                                                                    <div class="mkd-carousel-item-holder-inner">
                                                                        <a href="#" target="_self">
									<span class="mkd-carousel-first-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-5.png"
                         alt="h2-client-29">
				</span>
										<span class="mkd-carousel-second-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-5.png"
                         alt="h2-client-29">
				</span>
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="owl-item" style="width: 178px;">
                                                            <div class="item-inner">
                                                                <div class="mkd-carousel-item-holder">
                                                                    <div class="mkd-carousel-item-holder-inner">
                                                                        <a href="#" target="_self">
									<span class="mkd-carousel-first-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-3.png"
                         alt="h2-client-3">
				</span>
										<span class="mkd-carousel-second-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-3.png"
                         alt="h2-client-3">
				</span>
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                                <div class="mkd-carousel-item-holder">
                                                                    <div class="mkd-carousel-item-holder-inner">
                                                                        <a href="#" target="_self">
									<span class="mkd-carousel-first-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-6.png"
                         alt="h2-client-30">
				</span>
										<span class="mkd-carousel-second-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-6.png"
                         alt="h2-client-30">
				</span>
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="owl-item" style="width: 178px;">
                                                            <div class="item-inner">
                                                                <div class="mkd-carousel-item-holder">
                                                                    <div class="mkd-carousel-item-holder-inner">
                                                                        <a href="#" target="_self">
									<span class="mkd-carousel-first-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-4.png"
                         alt="h2-client-4">
				</span>
										<span class="mkd-carousel-second-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-4.png"
                         alt="h2-client-4">
				</span>
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                                <div class="mkd-carousel-item-holder">
                                                                    <div class="mkd-carousel-item-holder-inner">
                                                                        <a href="#" target="_self">
									<span class="mkd-carousel-first-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-5.png"
                         alt="h2-client-5">
				</span>
										<span class="mkd-carousel-second-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-5.png"
                         alt="h2-client-5">
				</span>
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="owl-item" style="width: 178px;">
                                                            <div class="item-inner">
                                                                <div class="mkd-carousel-item-holder">
                                                                    <div class="mkd-carousel-item-holder-inner">
                                                                        <a href="#" target="_self">
									<span class="mkd-carousel-first-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-6.png"
                         alt="h2-client-6">
				</span>
										<span class="mkd-carousel-second-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-6.png"
                         alt="h2-client-6">
				</span>
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                                <div class="mkd-carousel-item-holder">
                                                                    <div class="mkd-carousel-item-holder-inner">
                                                                        <a href="#" target="_self">
									<span class="mkd-carousel-first-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-1.png"
                         alt="h2-client-7">
				</span>
										<span class="mkd-carousel-second-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-1.png"
                         alt="h2-client-7">
				</span>
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="owl-item" style="width: 178px;">
                                                            <div class="item-inner">
                                                                <div class="mkd-carousel-item-holder">
                                                                    <div class="mkd-carousel-item-holder-inner">
                                                                        <a href="#" target="_self">
									<span class="mkd-carousel-first-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-2.png"
                         alt="h2-client-8">
				</span>
										<span class="mkd-carousel-second-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-2.png"
                         alt="h2-client-8">
				</span>
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                                <div class="mkd-carousel-item-holder">
                                                                    <div class="mkd-carousel-item-holder-inner">
                                                                        <a href="#" target="_self">
									<span class="mkd-carousel-first-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-3.png"
                         alt="h2-client-9">
				</span>
										<span class="mkd-carousel-second-image-holder mkd-has-hover-image mkd-image-change">
					<img src="/image/client-3.png"
                         alt="h2-client-9">
				</span>
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="owl-controls clickable">
                                                    <div class="owl-pagination">
                                                        <div class="owl-page"><span class=""></span></div>
                                                        <div class="owl-page active"><span class=""></span></div>
                                                        <div class="owl-page"><span class=""></span></div>
                                                        <div class="owl-page"><span class=""></span></div>
                                                        <div class="owl-page"><span class=""></span></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="vc_empty_space" style="height: 45px"><span
                                                    class="vc_empty_space_inner"></span></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div data-mkd-parallax-speed="1"
                         class="vc_row wpb_row vc_row-fluid mkd-section vc_custom_1447328421692 mkd-content-aligment-left mkd-grid-section"
                         style="">
                        <div class="clearfix mkd-section-inner">
                            <div class="mkd-section-inner-margin clearfix">
                                <div class="wpb_column vc_column_container vc_col-sm-12">
                                    <div class="wpb_wrapper">

                                        <div class="mkd-call-to-action normal" style="background-color: #f2f2f2">

                                            <div class="mkd-container-inner">
                                                <div class="mkd-call-to-action-row-66-33 clearfix"
                                                     style="padding: 45px 0% 45px 16%;">

                                                    <div class="mkd-text-wrapper mkd-call-to-action-column1 mkd-call-to-action-cell">


                                                        <div class="mkd-call-to-action-text">
                                                            <h3>Our&nbsp;lawyers will also represent you in civil
                                                                litigation cases such as&nbsp;divorce.</h3>
                                                        </div>

                                                    </div>


                                                    <div class="mkd-button-wrapper mkd-call-to-action-column2 mkd-call-to-action-cell"
                                                         style="text-align: left ;">

                                                        <a href="#" target="_self"
                                                           class="mkd-btn mkd-btn-medium mkd-btn-solid mkd-btn-icon">
                                                            <span class="mkd-btn-text">Contact us</span><span
                                                                    class="mkd-btn-icon-holder">            <span
                                                                        aria-hidden="true"
                                                                        class="mkd-icon-font-elegant arrow_carrot-right mkd-btn-icon-elem"></span>            <span
                                                                        aria-hidden="true"
                                                                        class="mkd-icon-font-elegant arrow_carrot-right mkd-btn-icon-elem"></span>        </span>
                                                        </a>
                                                    </div>


                                                </div>

                                            </div>

                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div> <!-- close div.content_inner -->
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('index.layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>