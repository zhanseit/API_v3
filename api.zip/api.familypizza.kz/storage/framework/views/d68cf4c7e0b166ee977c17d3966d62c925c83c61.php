<?php $__env->startSection('content'); ?>

    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="container">
                    <h2 class="main-title"><?php echo e(Lang::get('app.edit_vacancy')); ?></h2>

                    <div class="row ">

                        <div class="col-md-6 col-sm-6 form-regis">
                            <span><?php echo e(Lang::get('app.find_who')); ?></span>
                            <select class="selectpicker" data-live-search="true" id="speciality_id">

                                <?php $__currentLoopData = $speciality_row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

                                    <option <?php if($row->speciality_id == $item->speciality_id): ?> selected <?php endif; ?> value="<?php echo e($item->speciality_id); ?>"><?php echo e($item['speciality_name_'.$lang]); ?></option>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                            </select>
                        </div>

                        <div class="col-md-6 col-sm-6 form-regis">
                            <span><?php echo e(Lang::get('app.work_date')); ?></span>
                            <input class="date-mask" type="text" value="<?php echo e($row->deadline); ?>" id="deadline">
                        </div>

                        <div class="col-md-12">
                            <h3><b><?php echo e(Lang::get('app.pay')); ?></b></h3>
                        </div>

                        <div class="col-md-6 col-sm-6 form-regis">
                            <span><?php echo e(Lang::get('app.during')); ?></span>
                            <select id="pay_duration">
                                <option value="час" <?php if(strtolower($row->pay_duration) == 'час'): ?> selected <?php endif; ?>><?php echo e(Lang::get('app.hour')); ?></option>
                                <option value="неделя" <?php if(strtolower($row->pay_duration) == 'неделя'): ?> selected <?php endif; ?>><?php echo e(Lang::get('app.week')); ?></option>
                                <option value="месяц" <?php if(strtolower($row->pay_duration) == 'месяц'): ?> selected <?php endif; ?>><?php echo e(Lang::get('app.month')); ?></option>
                            </select>
                        </div>

                        <div class="col-md-6 col-sm-6 form-regis">
                            <span><?php echo e(Lang::get('app.money_tenge')); ?></span>
                            <input type="number" value="<?php echo e($row->salary); ?>" id="salary">
                        </div>

                        <div class="col-md-6 col-sm-6 form-regis">
                            <span><?php echo e(Lang::get('app.work_count')); ?></span>
                            <input type="number" value="<?php echo e($row->work_count); ?>" id="work_count">
                        </div>

                        <div class="col-md-6 col-sm-6 form-regis">
                            <span><?php echo e(Lang::get('app.address_work')); ?></span>
                            <input type="text" value="<?php echo e($row->address); ?>" id="address">
                        </div>

                        <div class="col-md-12 col-sm-12 form-regis">
                            <span><?php echo e(Lang::get('app.vacancy_desc')); ?></span>
                            <textarea id="vacancy_desc"><?php echo e($row->vacancy_desc); ?></textarea>
                        </div>

                        <div class="col-md-12">
                            <div class="btn-vacancy">
                                <button class="btns-yellow" onclick="editVacancy('<?php echo e($row->vacancy_id); ?>')"><?php echo e(Lang::get('app.save')); ?></button>
                                <a href="/profile/vacancy"><button class="btn-grey"><?php echo e(Lang::get('app.cancel')); ?></button></a>
                            </div>
                        </div>

                    </div>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('index.layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>