<div class="mkd-logo-area">
    <div class="mkd-grid">
        <div class="mkd-vertical-align-containers mkd-25-75">
            <div class="mkd-position-left">
                <div class="mkd-position-left-inner">
                    <div class="mkd-logo-wrapper">
                        <a href="/" style="">
                            <img class="mkd-normal-logo" src="/image/logo.png" alt="logo" style="width: 270px">
                        </a>
                    </div>
                </div>
            </div>

            <div class="mkd-position-right">
                <div class="mkd-position-right-inner">
                    <div id="text-10" class="widget widget_text mkd-right-from-logo-widget">
                        <div class="textwidget">
                            <div class="mkd-icon-list-item">
                                <div class="mkd-icon-list-icon-holder">
                                    <div class="mkd-icon-list-icon-holder-inner clearfix" data-icon-size="25">
                                        <i class="mkd-icon-simple-line-icon icon-clock " style="color:#c18f59;font-size:25px"></i>
                                    </div>
                                </div>
                                <p class="mkd-icon-list-text" style="color:#ffffff;font-size:27px"
                                   data-title-size="27">09:00-21:00</p>
                            </div>
                            <div class="vc_empty_space" style="height: 2px">
                                <span class="vc_empty_space_inner"></span>
                            </div>
                            <p style="text-align:left; font-size:13px;">
                                <span style="color:#fff">Пн-пт 09:00-21:00, сб 10:00-15:00</span>
                            </p>
                        </div>
                    </div>
                    <div id="text-11" class="widget widget_text mkd-right-from-logo-widget">
                        <div class="textwidget">
                            <span class="mkd-vertical-separator" style="border-right-color: rgba(255,255,255,0.1);height: 48px;margin-left: 15px;margin-right: 15px"></span>
                        </div>
                    </div>
                    <div id="text-12" class="widget widget_text mkd-right-from-logo-widget">
                        <div class="textwidget">
                            <div class="mkd-icon-list-item">
                                <div class="mkd-icon-list-icon-holder">
                                    <div class="mkd-icon-list-icon-holder-inner clearfix"
                                         data-icon-size="25">
                                        <i class="mkd-icon-simple-line-icon icon-earphones-alt "
                                           style="color:#c18f59;font-size:25px"></i>
                                    </div>
                                </div>
                                <p class="mkd-icon-list-text" style="color:#ffffff;font-size:27px"
                                   data-title-size="27">+7(702)668-44-68</p>
                            </div>
                            <div class="vc_empty_space" style="height: 2px">
                                <span class="vc_empty_space_inner"></span>
                            </div>
                            <p style="text-align:left; font-size:13px;">
                                <span style="color:#fff">г. Алматы, ул. Наурызбай батыра 47 оф. 19</span>
                            </p>
                        </div>
                    </div>
                    <div id="text-13" class="widget widget_text mkd-right-from-logo-widget">
                        <div class="textwidget">
                                <span class="mkd-vertical-separator"
                                      style="border-right-color: rgba(255,255,255,0.1);height: 48px;margin-left: 15px;margin-right: 4px"></span>
                        </div>
                    </div>
                    <div id="text-14" class="widget widget_text mkd-right-from-logo-widget">
                        <div class="textwidget">
                            <div class="mkd-iwt clearfix mkd-iwt-icon-top mkd-iwt-icon-normal mkd-iwt-icon-small">
                                <div class="mkd-iwt-icon-holder">
                                        <span class="mkd-icon-shortcode normal mkd-icon-linked" data-hover-color="#c18f59" data-color="#ffffff">
                                                        <a href="https://www.facebook.com/mconsalt.kz" target="_blank">

                                            <span aria-hidden="true" class="mkd-icon-font-elegant social_facebook mkd-icon-element"
                                                  style="color: rgb(255, 255, 255); font-size: 23px;"></span>
                                                        </a>
                                                    <span class="mkd-background"></span>
                                        </span>
                                </div>
                                <div class="mkd-iwt-content-holder">
                                    <div class="mkd-iwt-title-holder">
                                    </div>
                                    <div class="mkd-iwt-text-holder">
                                        <p style="color: #ffffff">Facebook</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="text-15" class="widget widget_text mkd-right-from-logo-widget">
                        <div class="textwidget">
                                        <span class="mkd-vertical-separator"
                                              style="border-right-color: rgba(255,255,255,0.1);height: 48px;margin-left: 4px;margin-right: 13px"></span>
                        </div>
                    </div>
                    <div id="text-16" class="widget widget_text mkd-right-from-logo-widget">
                        <div class="textwidget">
                            <div class="mkd-iwt clearfix mkd-iwt-icon-top mkd-iwt-icon-normal mkd-iwt-icon-small">
                                <div class="mkd-iwt-icon-holder">
                                        <span class="mkd-icon-shortcode normal mkd-icon-linked" data-hover-color="#c18f59" data-color="#ffffff">
                                                        <a href="https://www.instagram.com/mconsult.kz/" target="_blank">
                                            <span aria-hidden="true" class="mkd-icon-font-elegant social_instagram mkd-icon-element"
                                                  style="color: rgb(255, 255, 255); font-size: 23px;"></span>
                                                        </a>
                                                    <span class="mkd-background"></span>
                                        </span>
                                </div>
                                <div class="mkd-iwt-content-holder">
                                    <div class="mkd-iwt-title-holder">
                                    </div>
                                    <div class="mkd-iwt-text-holder">
                                        <p style="color: #ffffff">Instagram</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div id="text-18" class="widget widget_text mkd-right-from-logo-widget">
                        <div class="textwidget">
                                        <span class="mkd-vertical-separator"
                                              style="border-right-color: rgba(255,255,255,0.1);height: 48px;margin-left: 0px;margin-right: 0px"></span>
                        </div>
                    </div>
                    <a class="mkd-side-menu-button-opener" href="javascript:void(0)">
           	<span class="mkd-lines-holder">
				<span class="mkd-lines-holder-inner">
					<span class="mkd-lines line-1"></span>
					<span class="mkd-lines line-2"></span>
					<span class="mkd-lines line-3"></span>
					<span class="mkd-lines line-4"></span>
                    <span class="mkd-lines line-5"></span>
				</span>
           	</span>
                        <span class="mkd-side-area-icon-text">Menu</span>
                    </a>

                    <div id="text-19" class="widget widget_text mkd-right-from-logo-widget">
                        <div class="textwidget">
                                        <span class="mkd-vertical-separator"
                                              style="border-right-color: rgba(255,255,255,0.1);height: 48px;margin-left: 0px;margin-right: 0px"></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>