<?php $__env->startSection('content'); ?>

    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="container">
                    <h2 class="main-title"><?php echo e(Lang::get('app.register_master')); ?></h2>

                    <div class="row">

                        <input type="hidden" value="3" id="role_id"/>

                        <div class="col-md-6 col-sm-6 form-regis">
                            <span><?php echo e(Lang::get('app.full_name')); ?></span>
                            <input type="text" value="" id="user_name">
                        </div>

                        <div class="col-md-6 col-sm-6 form-regis">
                            <span><?php echo e(Lang::get('app.your_age')); ?></span>
                            <input type="number" value="" id="age" placeholder="25">
                        </div>

                        <div class="col-md-6 col-sm-6 form-regis">
                            <span><?php echo e(Lang::get('app.iin')); ?></span>
                            <input type="text" value="" id="inn" placeholder="">
                        </div>

                        <div class="col-md-6 col-sm-6 form-regis">
                            <span><?php echo e(Lang::get('app.phone')); ?></span>
                            <input class="phone-mask" type="text" value="" id="phone" placeholder="+7 (ХХХ) ХХХ-ХХ-ХХ">
                        </div>

                        <div class="col-md-6 col-sm-6 form-regis">
                            <span><?php echo e(Lang::get('app.speciality_type')); ?></span>
                            <select id="speciality_id" class="selectpicker" data-live-search="true">

                                <?php $__currentLoopData = $speciality_row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

                                    <option value="<?php echo e($item->speciality_id); ?>"><?php echo e($item['speciality_name_'.$lang]); ?></option>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                            </select>
                        </div>

                        <div class="col-md-6 col-sm-6 form-regis">
                            <span><?php echo e(Lang::get('app.password')); ?></span>
                            <input type="password" value="" id="register_password" placeholder="">
                        </div>

                    </div>

                    <div class="row box-registration">
                        <div class="col-md-6 col-sm-6 form-regis">
                            <input type="checkbox" id="is_agree"> <span><?php echo Lang::get('app.agree_licence'); ?></span>
                        </div>

                        <div class="col-md-6 col-sm-6 form-regis">
                            <input type="button" value="<?php echo e(Lang::get('app.registered')); ?>" onclick="registerAjax()">
                        </div>
                    </div>

                    <h3 class="title-2"><?php echo e(Lang::get('app.if_you_are_registered')); ?></h3>
                    <div class="row">
                        <div class="col-md-6 col-sm-6 form-regis">
                            <span><?php echo e(Lang::get('app.phone')); ?></span>
                            <input class="phone-mask" type="text" id="login" placeholder="+7 (ХХХ) ХХХ-ХХ-ХХ" value="">
                            <span><?php echo e(Lang::get('app.password')); ?></span>
                            <input type="password" value="" id="password" class="login-input">
                            <input type="button" value="<?php echo e(Lang::get('app.sign_in')); ?>" onclick="loginAjax()">
                            <p class="text-center"><a href="/auth/reset-password"><?php echo e(Lang::get('app.forget_password')); ?></a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('index.layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>