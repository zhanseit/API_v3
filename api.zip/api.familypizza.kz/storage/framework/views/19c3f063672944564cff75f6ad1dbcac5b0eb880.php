<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-xs-12">
      <div class="box">
        <div class="box-header">
            <h3 class="box-title box-title-second" style="margin-bottom: 20px">
                <a class="menu-tab active-page">Отзывы пользователей</a>
            </h3>
          <div class="clear-float"></div>
           <div class="form-group col-md-3" >
              <label>Поиск</label>
              <input id="search_word" value="<?php echo e($request->search); ?>" type="text" class="form-control" name="search_word" placeholder="Введите">
           </div>
            <div class="form-group col-md-3 search-btn" >
                <a href="javascript:void(0)" onclick="searchBySort()">
                    <button type="button" class="btn btn-block btn-success">Поиск</button>
                </a>
            </div>
            <div class="form-group col-md-6" style="text-align: right; padding-top: 30px">
                <h4 class="box-title box-delete-click">
                    <a href="javascript:void(0)" onclick="deleteAll('review')">Удалить отмеченные</a>
                </h4>
            </div>
        </div>
        <div class="box-body">
          <table id="review_datatable" class="table table-bordered table-striped">
            <thead>
              <tr style="border: 1px">
                <th style="width: 30px">№</th>
                <th>Текст отзыва</th>
                <th>Оценка</th>
                <th>Автор отзыва</th>
                <th>Мастер</th>
                <th style="width: 15px"></th>
                <th class="no-sort" style="width: 0px; text-align: center; padding-right: 16px; padding-left: 14px;" >
                    <input onclick="selectAllCheckbox(this)" style="font-size: 15px" type="checkbox" value="1"/>
                </th>
              </tr>
            </thead>

            <tbody>

                  <?php $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

                     <tr>
                        <td> <?php echo e($key + 1); ?></td>
                        <td>
                            <?php echo e($val['review_text']); ?>

                        </td>
                         <td>
                             <?php echo e($val['rating']); ?>

                         </td>
                         <td>
                             <a class="object-name" href="/user/<?php echo e(\App\Http\Helpers::getTranslatedSlugRu($val->user_name)); ?>-u<?php echo e($val->user_id); ?>">
                                <?php echo e($val['user_name']); ?></br>
                                 <b style="color: #535353"><?php echo e(\App\Http\Helpers::getPhoneFormat($val['phone'])); ?></b>
                             </a>
                         </td>
                         <td>
                             <a class="object-name" href="/user/<?php echo e(\App\Http\Helpers::getTranslatedSlugRu($val->master_name)); ?>-u<?php echo e($val->master_id); ?>">
                                 <?php echo e($val['master_name']); ?></br>
                                 <b style="color: #535353"><?php echo e(\App\Http\Helpers::getPhoneFormat($val['master_phone'])); ?></b>
                             </a>
                         </td>
                         <td style="text-align: center">
                            <a href="javascript:void(0)" onclick="delItem(this,'<?php echo e($val->review_id); ?>','review')">
                                <li class="fa fa-trash-o" style="font-size: 20px; color: red;"></li>
                            </a>
                         </td>
                        <td style="text-align: center;">
                            <input class="select-all" style="font-size: 15px" type="checkbox" value="<?php echo e($val->review_id); ?>"/>
                        </td>
                     </tr>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

            </tbody>

          </table>

            <div style="text-align: center">
                <?php echo e($row->appends(\Illuminate\Support\Facades\Input::except('page'))->links()); ?>

            </div>

        </div>
      </div>
    </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>