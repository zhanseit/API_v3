<?php $__env->startSection('content'); ?>

    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="container page-vacancy not-found-page">
                    <h2>
                        404
                    </h2>
                    <h3>К сожалению, по Вашему запросу ничего не найдено</h3>
                    <a href="/">
                        <span class="mkd-btn-text">Перейти на главную страницу</span>
                    </a>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('index.layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>