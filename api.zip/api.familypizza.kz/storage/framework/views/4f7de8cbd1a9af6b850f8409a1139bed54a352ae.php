<?php $__env->startSection('content'); ?>

    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="container">
                    <div class="row">
                        <div class="col-md-offset-3 col-md-6 col-sm-6 form-regis">
                            <h2 class="main-title"><?php echo e(Lang::get('app.reset_password')); ?></h2>
                            <span><?php echo e(Lang::get('app.new_password')); ?></span>
                            <input type="hidden" value="<?php echo e(\App\Http\Helpers::changePhoneFormat($phone)); ?>" id="phone">
                            <input type="hidden" value="<?php echo e($sms_code); ?>" id="sms_code">
                            <input type="password" id="new_password" placeholder="<?php echo e(Lang::get('app.new_password')); ?>">
                            <input type="password" id="confirm_password" placeholder="<?php echo e(Lang::get('app.confirm_password')); ?>">
                            <input type="button" value="<?php echo e(Lang::get('app.save')); ?>" onclick="changePasswordAndReset()">
                            <p class="text-center"><a href="/"><?php echo e(Lang::get('app.home_page')); ?></a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('index.layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>