<?php $__currentLoopData = $response_row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

        <tr>
            <td>
                <a href="/profile/<?php echo e(\App\Http\Helpers::getTranslatedSlugRu($item['user_name']).'-u'.$item->user_id); ?>"><?php echo e($item->user_name); ?></a>
            </td>
            <td>
                <a href="/vacancy/<?php echo e(\App\Http\Helpers::getTranslatedSlugRu($item['speciality_name_'.$lang].'-'.$item->vacancy_desc)); ?>-u<?php echo e($item->vacancy_id); ?>"><?php echo e($item['speciality_name_'.$lang]); ?></a>
            </td>
            <td><?php echo e($item->deadline); ?></td>
            <td>
                <p class="<?php if($item->status_id == 1): ?> waiting-status <?php elseif($item->status_id == 2): ?> success-status <?php else: ?> warning-status <?php endif; ?> response-status"><?php echo e($item['status_name_'.$lang]); ?></p>
            </td>
            <td class="btns-table">

                <?php if($item->status_id == 1): ?>

                    <button class="btn-blue" onclick="cancelResponse('<?php echo e($item->vacancy_id); ?>',this)">Отменить отклик</button>

                <?php endif; ?>

            </td>
        </tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

