<?php $__env->startSection('content'); ?>

    <div class="content">
        <div class="container-fluid">

            <div class="row top-content">
                <div class="in-top-content text-center">
                    <h1><?php echo e(Lang::get('app.help_find_worker')); ?></h1>

                    <div class="main-btns">
                        <?php if(!Auth::check()): ?>

                            <a href="/auth/register/master">
                                <button class="btns-yellow"><?php echo e(Lang::get('app.find_work')); ?></button>
                            </a>
                            <a href="/auth/register/employer">
                                <button class="btns-yellow"><?php echo e(Lang::get('app.find_workers')); ?></button>
                            </a>

                        <?php else: ?>

                            <a href="/vacancy">
                                <button class="btns-yellow"><?php echo e(Lang::get('app.find_work')); ?></button>
                            </a>
                            <a href="/profile/vacancy">
                                <button class="btns-yellow"><?php echo e(Lang::get('app.find_workers')); ?></button>
                            </a>

                        <?php endif; ?>

                    </div>
                </div>
            </div>

            <div class="row">
                <div class="container">
                    <div class="text-mob-pred">
                        <div class="col-md-6">
                            <h2><?php echo e(Lang::get('app.download_our_mobile_applications')); ?></h2>
                            <p><?php echo e(Lang::get('app.work_will_be_your')); ?></p>

                            <div class="icon-mob">
                                <a target="_blank" href="https://itunes.apple.com/kz/app/czshymkent/id1210303985?mt=8">
                                    <img src="/images/app.png" alt="">
                                </a>
                                <a target="_blank" href="https://play.google.com/store/apps/details?id=com.den.vac&hl=ru">
                                    <img src="/images/google-play.png" alt="">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('index.layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>