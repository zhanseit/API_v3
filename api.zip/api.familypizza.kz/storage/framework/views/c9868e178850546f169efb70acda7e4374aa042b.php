<?php $__env->startSection('content'); ?>

    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="container page-vacancy">
                    <h2 class="main-title"><?php echo e($row['speciality_name_'.$lang]); ?></h2>
                    <table>
                        <tr>
                            <td><?php echo e(Lang::get('app.employer')); ?></td>
                            <td>
                                <b>
                                    <a class="price-job" href="/profile/<?php echo e(\App\Http\Helpers::getTranslatedSlugRu($row->user_name).'-u'.$row->user_id); ?>"><?php echo e($row->user_name); ?></a>
                                </b>
                            </td>
                        </tr>
                        <tr>
                            <td><?php echo e(Lang::get('app.pay')); ?></td>
                            <td><b><?php echo e($row->salary); ?> <?php echo e(Lang::get('app.tenge')); ?>/<?php echo e($row->pay_duration); ?></b></td>
                        </tr>
                        <tr>
                            <td><?php echo e(Lang::get('app.work_date')); ?></td>
                            <td><b><?php echo e($row->deadline); ?></b></td>
                        </tr>

                        <?php if($row->address != ''): ?>

                            <tr>
                                <td><?php echo e(Lang::get('app.address_work')); ?></td>
                                <td><b><?php echo e($row->address); ?></b></td>
                            </tr>

                        <?php endif; ?>

                        <tr>
                            <td><?php echo e(Lang::get('app.work_count')); ?></td>
                            <td><b><?php echo e($row->work_count); ?></b></td>
                        </tr>

                    </table>

                    <h4><?php echo e(Lang::get('app.vacancy_desc')); ?>:</h4>

                    <p><?php echo e($row->vacancy_desc); ?></p>

                    <div class="btn-vacancy">
                        <?php if(Auth::check() && $row->user_id == Auth::user()->user_id): ?>

                            <a href="/vacancy/edit/<?php echo e(\App\Http\Helpers::getTranslatedSlugRu($row->vacancy_desc).'-u'.$row->vacancy_id); ?>">
                                <button class="btns-yellow"><?php echo e(Lang::get('app.edit')); ?></button>
                            </a>

                            <button onclick="deleteVacancy('<?php echo e($row->vacancy_id); ?>')" class="btn-red"><?php echo e(Lang::get('app.delete')); ?></button>

                            <?php if($row->response_count > 0): ?>

                                <a href="/response/in?vacancy_id=<?php echo e($row->vacancy_id); ?>">
                                    <button class="btn-blue"><?php echo e(Lang::get('app.incoming_response')); ?>(<?php echo e($row->response_count); ?>)</button>
                                </a>

                            <?php endif; ?>

                        <?php else: ?>

                            <?php if(Auth::check() && Auth::user()->role_id == 3): ?>

                                <?php if($row->is_send_response == 1): ?>

                                    <button class="btn-blue" onclick="cancelResponse('<?php echo e($row->vacancy_id); ?>',this)"><?php echo e(Lang::get('app.cancel_response')); ?></button>

                                <?php else: ?>

                                    <button class="btns-yellow" onclick="sendResponse('<?php echo e($row->vacancy_id); ?>',this)"><?php echo e(Lang::get('app.send_response')); ?></button>

                                <?php endif; ?>

                            <?php elseif(!Auth::check()): ?>

                                <a href="/login?redirect_url=vacancy/<?php echo e(\App\Http\Helpers::getTranslatedSlugRu($row->vacancy_desc).'-u'.$row->vacancy_id); ?>">
                                    <button class="btns-yellow"><?php echo e(Lang::get('app.send_response')); ?></button>
                                </a>


                            <?php endif; ?>



                            <a href="/vacancy">
                                <button class="btn-blue"><?php echo e(Lang::get('app.back_vacancy')); ?></button>
                            </a>

                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" tabindex="-1" id="modal-5" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <h4 class="modal-title text-center"><?php echo e(Lang::get('app.success_response')); ?></h4>
                    <p class="pod-title"><?php echo e(Lang::get('app.employer_call_you')); ?></p>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('index.layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>