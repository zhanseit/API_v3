<?php $__env->startSection('content'); ?>

        <section class="content-header">
            <h1>
              <?php echo e($title); ?>

            </h1>
        </section>
        <section class="content">
            <div class="row">
                <div class="col-md-12">
                   <div class="col-md-8" style="padding-left: 0px">
                       <div class="box box-primary">
                           <?php if(isset($error)): ?>
                               <div class="alert alert-danger">
                                  <?php echo e($error); ?>

                               </div>
                           <?php endif; ?>
                               <?php if($row->user_id > 0): ?>
                                   <form action="/admin/user/<?php echo e($row->user_id); ?>" method="POST">
                                   <input type="hidden" name="_method" value="PUT">
                               <?php else: ?>
                                   <form action="/admin/user" method="POST">
                               <?php endif; ?>

                                   <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                   <input id="user_id" type="hidden" name="user_id" value="<?php echo e($row->user_id); ?>">
                                   <input type="hidden" id="avatar" name="avatar" value="<?php echo e($row->avatar); ?>"/>

                                   <div class="box-body">
                                       <div class="form-group">
                                           <label>ФИО</label>
                                           <input value="<?php echo e($row->name); ?>" type="text" class="form-control" name="name" placeholder="Введите">
                                       </div>
                                       <div class="form-group">
                                          <label>Email</label>
                                          <input value="<?php echo e($row->email); ?>" type="text" class="form-control" name="email" placeholder="Введите">
                                       </div>

                                    </div>

                                   <div class="box-footer">
                                       <button type="submit" class="btn btn-primary">Сохранить</button>
                                   </div>
                               </form>
                           </div>
                   </div>
                   <div class="col-md-4">
                       <div class="box box-primary" style="padding: 30px; text-align: center">
                           <div style="border-radius: 50%; padding: 20px; border: 1px solid #c2e2f0">
                               <?php if(strpos($row->avatar, 'http') !== false): ?>
                                   <img id="avatar_img" src="<?php echo e($row->avatar); ?>" style="width: 100%; border-radius: 50%;"/>
                               <?php else: ?>
                                   <img id="avatar_img" src="/image/avatar/<?php echo e($row->avatar); ?>" style="width: 100%; border-radius: 50%;"/>
                               <?php endif; ?>
                           </div>
                           <div style="background-color: #c2e2f0;height: 40px;margin: 0 auto;width: 2px;"></div>
                           <form id="avatar_form" enctype="multipart/form-data" method="post" class="avatar-form">
                               <i class="fa fa-plus"></i>
                               <input type="hidden" value="avatar" name="disk">
                               <input id="avatar-file" type="file" onchange="uploadAvatar()" name="image"/>
                           </form>
                       </div>
                   </div>
                </div>
            </div>
        </section>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>