<?php $__env->startSection('content'); ?>

    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="container">
                    <div class="row">
                        <div class="col-md-offset-3 col-md-6 col-sm-6 form-regis">
                            <h2 class="main-title"><?php echo e(Lang::get('app.reset_password')); ?></h2>
                            <span><?php echo e(Lang::get('app.write_phone')); ?></span>
                            <input type="text" id="phone" class="phone-mask" placeholder="+7 (ХХХ) ХХХ-ХХ-ХХ">
                            <input type="button" value="<?php echo e(Lang::get('app.send_code')); ?>" onclick="passwordResetAjax()">
                            <p class="text-center"><a href="/"><?php echo e(Lang::get('app.home_page')); ?></a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('index.layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>