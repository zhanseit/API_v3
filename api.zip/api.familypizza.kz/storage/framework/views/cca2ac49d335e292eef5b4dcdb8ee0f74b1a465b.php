<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-xs-12">
      <div class="box">
          <div class="box-header">
              <h3 class="box-title box-title-first">
                  <a href="/admin/company" class="menu-tab <?php if(!isset($request->is_ban) ||  $request->is_ban == '0'): ?> active-page <?php endif; ?>">Активные работодатели</a>
              </h3>
              <h3 class="box-title box-title-second" >
                  <a href="/admin/company?is_ban=1" class="menu-tab <?php if($request->is_ban == '1'): ?> active-page <?php endif; ?>">Неактивные работодатели</a>
              </h3>
              <a href="/admin/company/create" style="float: right">
                  <button class="btn btn-primary box-add-btn">Добавить работодателя</button>
              </a>
              <div class="clear-float"></div>
              <div class="form-group col-md-3" >
                  <label>Поиск</label>
                  <input id="search_word" value="<?php echo e($request->search); ?>" type="text" class="form-control" name="search_word" placeholder="Введите">
              </div>
              <div class="form-group col-md-3 search-btn" >
                  <a href="javascript:void(0)" onclick="searchBySort()">
                      <button type="button" class="btn btn-block btn-success">Поиск</button>
                  </a>
              </div>
          </div>
          <div>
              <div style="text-align: left" class="form-group col-md-6" >

                  <?php if($request->is_ban == '1'): ?>

                      <h4 class="box-title box-edit-click">
                          <a href="javascript:void(0)" onclick="isShowDisabledAll('company')">Разблокировать отмеченные</a>
                      </h4>

                  <?php else: ?>

                      <h4 class="box-title box-edit-click">
                          <a href="javascript:void(0)" onclick="isShowEnabledAll('company')">Заблокировать отмеченные</a>
                      </h4>

                  <?php endif; ?>


              </div>
              <div style="text-align: right" class="form-group col-md-6" >
                  <h4 class="box-title box-delete-click">
                      <a href="javascript:void(0)" onclick="deleteAll('company')">Удалить отмеченные</a>
                  </h4>
              </div>
          </div>
        <div class="box-body">
          <table id="news_datatable" class="table table-bordered table-striped">
            <thead>
              <tr style="border: 1px">
                <th style="width: 30px">№</th>
                <th>ФИО/Название и телефон</th>
                <th>Вид деятельности</th>
                <th>Юр.лицо/физ.лицо</th>
                <th>ИНН</th>
                <th>Дата регистрации</th>
                <th style="width: 30px"></th>
                <th style="width: 30px"></th>
                <th class="no-sort" style="width: 0px; text-align: center; padding-right: 16px; padding-left: 14px;" >
                  <input onclick="selectAllCheckbox(this)" style="font-size: 15px" type="checkbox" value="1"/>
                </th>
              </tr>
            </thead>

            <tbody>

                  <?php $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

                     <tr>
                        <td> <?php echo e($key + 1); ?></td>
                         <td class="arial-font">
                             <a class="object-name" href="/user/<?php echo e(\App\Http\Helpers::getTranslatedSlugRu($val->user_name)); ?>-u<?php echo e($val->user_id); ?>">
                                 <?php echo e($val['user_name']); ?></br>
                                 <b style="color: #535353"><?php echo e(\App\Http\Helpers::getPhoneFormat($val['phone'])); ?></b>
                             </a>
                         </td>
                        <td class="arial-font">
                            <?php echo e($val->work_type); ?>

                        </td>
                         <td class="arial-font">
                             <?php echo e($val->is_company > 0?'Юр. лицо':'Физ. лицо'); ?>

                         </td>
                         <td class="arial-font">
                             <?php echo e($val->inn); ?>

                         </td>
                         <td class="arial-font">
                             <?php echo e($val->date); ?>

                         </td>
                        <td style="text-align: center">
                            <a href="javascript:void(0)" onclick="delItem(this,'<?php echo e($val->user_id); ?>','company')">
                                <li class="fa fa-trash-o" style="font-size: 20px; color: red;"></li>
                            </a>
                        </td>
                        <td style="text-align: center">
                            <a href="/admin/company/<?php echo e($val->user_id); ?>/edit">
                                <li class="fa fa-pencil" style="font-size: 20px;"></li>
                            </a>
                        </td>
                        <td style="text-align: center;">
                             <input class="select-all" style="font-size: 15px" type="checkbox" value="<?php echo e($val->user_id); ?>"/>
                        </td>
                     </tr>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

            </tbody>

          </table>

            <div style="text-align: center">
                <?php echo e($row->appends(\Illuminate\Support\Facades\Input::except('page'))->links()); ?>

            </div>

        </div>
      </div>
    </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>