<?php $__env->startSection('content'); ?>

    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="container">
                    <h2 class="main-title"><?php echo e(Lang::get('app.my_vacancy')); ?>

                        <a href="/vacancy/add" class="pull-right r-box-top hidden-xs">
                            <button class="btns-yellow"><?php echo e(Lang::get('app.add_vacancy')); ?></button>
                        </a>
                    </h2>

                    <?php if($vacancy_row->count() > 0): ?>

                        <div class="table-style">
                            <table class="table table-responsive list-vacancy href-table">
                                <tr data-href="#">
                                    <th><?php echo e(Lang::get('app.vacancy')); ?></th>
                                    <th><?php echo e(Lang::get('app.work_date')); ?></th>
                                    <th><?php echo e(Lang::get('app.pay')); ?></th>
                                </tr>

                                <?php echo $__env->make('index.vacancy.vacancy-loop', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                            </table>
                        </div>

                        <div style="text-align: center">
                            <?php echo e($vacancy_row->appends(\Illuminate\Support\Facades\Input::except('page'))->links()); ?>

                        </div>

                        <div class="text-center">
                            <a href="/vacancy/add" class="in-top-span">
                                <button class="btns-yellow"><?php echo e(Lang::get('app.add_vacancy')); ?></button>
                            </a>
                        </div>

                    <?php else: ?>

                        <p class="empty-list-label"><?php echo e(Lang::get('app.empty_my_vacancy')); ?></p>

                    <?php endif; ?>



                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('index.layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>