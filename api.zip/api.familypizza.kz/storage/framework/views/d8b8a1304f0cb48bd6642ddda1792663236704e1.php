<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="UTF-8">

    <link rel="profile" href="http://gmpg.org/xfn/11">
    <meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no">

    <title>Libero | A Theme for Lawyers and Law Firms</title>
    <script async="" src="/js/analytics.js" style=""></script>
    <script type="application/javascript">var mkdCoreAjaxUrl = "http://libero.mikado-themes.com/wp-admin/admin-ajax.php"</script>
    <link rel="alternate" type="application/rss+xml" title="Libero » Feed" href="http://libero.mikado-themes.com/feed/">
    <link rel="alternate" type="application/rss+xml" title="Libero » Comments Feed"
          href="http://libero.mikado-themes.com/comments/feed/">
    <script type="text/javascript">
        window._wpemojiSettings = {
            "baseUrl": "http:\/\/s.w.org\/images\/core\/emoji\/72x72\/",
            "ext": ".png",
            "source": {"concatemoji": "http:\/\/libero.mikado-themes.com\/wp-includes\/js\/wp-emoji-release.min.js"}
        };
        !function (a, b, c) {
            function d(a) {
                var c = b.createElement("canvas"), d = c.getContext && c.getContext("2d");
                return d && d.fillText ? (d.textBaseline = "top", d.font = "600 32px Arial", "flag" === a ? (d.fillText(String.fromCharCode(55356, 56812, 55356, 56807), 0, 0), c.toDataURL().length > 3e3) : (d.fillText(String.fromCharCode(55357, 56835), 0, 0), 0 !== d.getImageData(16, 16, 1, 1).data[0])) : !1
            }

            function e(a) {
                var c = b.createElement("script");
                c.src = a, c.type = "text/javascript", b.getElementsByTagName("head")[0].appendChild(c)
            }

            var f, g;
            c.supports = {simple: d("simple"), flag: d("flag")}, c.DOMReady = !1, c.readyCallback = function () {
                c.DOMReady = !0
            }, c.supports.simple && c.supports.flag || (g = function () {
                c.readyCallback()
            }, b.addEventListener ? (b.addEventListener("DOMContentLoaded", g, !1), a.addEventListener("load", g, !1)) : (a.attachEvent("onload", g), b.attachEvent("onreadystatechange", function () {
                "complete" === b.readyState && c.readyCallback()
            })), f = c.source || {}, f.concatemoji ? e(f.concatemoji) : f.wpemoji && f.twemoji && (e(f.twemoji), e(f.wpemoji)))
        }(window, document, window._wpemojiSettings);
    </script>
    <script src="/js/wp-emoji-release.js"
            type="text/javascript"></script>
    <style type="text/css">
        img.wp-smiley,
        img.emoji {
            display: inline !important;
            border: none !important;
            box-shadow: none !important;
            height: 1em !important;
            width: 1em !important;
            margin: 0 .07em !important;
            vertical-align: -0.1em !important;
            background: none !important;
            padding: 0 !important;
        }
    </style>
    <link rel="stylesheet" id="dashicons-css"
          href="/css/dashicons.css" type="text/css"
          media="all">
    <link rel="stylesheet" id="wp-jquery-ui-dialog-css"
          href="/css/jquery-ui-dialog.css" type="text/css"
          media="all">
    <link rel="stylesheet" id="contact-form-7-css"
          href="/css/styles.css" type="text/css"
          media="all">
    <link rel="stylesheet" id="rs-plugin-settings-css"
          href="/css/settings.css" type="text/css"
          media="all">
    <style id="rs-plugin-settings-inline-css" type="text/css">
        #rs-demo-id {
        }

        .tp-caption.Title, .Title {
            color: rgba(255, 255, 255, 1.00);
            font-size: 103px;
            line-height: 103px;
            font-weight: 900;
            font-style: normal;
            font-family: Roboto;
            padding: 0px 0px 0px 0px;
            text-decoration: none;
            text-align: left;
            background-color: transparent;
            border-color: transparent;
            border-style: none;
            border-width: 0px;
            border-radius: 0px 0px 0px 0px
        }

        .tp-caption.Button-Style, .Button-Style {
            color: rgba(255, 255, 255, 1.00);
            font-size: 11px;
            line-height: 17px;
            font-weight: 900;
            font-style: normal;
            font-family: roboto;
            padding: 0px 0px 0px 0px;
            text-decoration: none;
            text-align: left;
            background-color: transparent;
            border-color: transparent;
            border-style: none;
            border-width: 0px;
            border-radius: 0px 0px 0px 0px
        }

        .tp-caption.Small-Subtitle, .Small-Subtitle {
            color: rgba(255, 255, 255, 1.00);
            font-size: 16px;
            line-height: 26px;
            font-weight: 900;
            font-style: normal;
            font-family: Roboto;
            padding: 0px 0px 0px 0px;
            text-decoration: none;
            text-align: left;
            background-color: transparent;
            border-color: transparent;
            border-style: none;
            border-width: 0px;
            border-radius: 0px 0px 0px 0px
        }</style>
    <link rel="stylesheet" id="libero_mikado_default_style-css"
          href="/css/style.css" type="text/css" media="all">
    <link rel="stylesheet" id="libero_mikado_modules_plugins-css"
          href="/css/plugins.css" type="text/css"
          media="all">
    <link rel="stylesheet" id="libero_mikado_modules-css"
          href="/css/modules.css" type="text/css"
          media="all">
    <link rel="stylesheet" id="libero_mikado_print-css"
          href="/css/print.css" type="text/css" media="all">
    <link rel="stylesheet" id="mkd_font_awesome-css"
          href="/css/font-awesome.css" type="text/css"
          media="all">
    <link rel="stylesheet" id="mkd_font_elegant-css"
          href="/css/style_002.css" type="text/css"
          media="all">
    <link rel="stylesheet" id="mkd_ion_icons-css"
          href="/css/ionicons.css" type="text/css"
          media="all">
    <link rel="stylesheet" id="mkd_linea_icons-css"
          href="/css/style_003.css" type="text/css"
          media="all">
    <link rel="stylesheet" id="mkd_simple_line_icons-css"
          href="/css/simple-line-icons.css" type="text/css"
          media="all">
    <link rel="stylesheet" id="mkd_dripicons-css"
          href="/css/dripicons.css" type="text/css"
          media="all">
    <link rel="stylesheet" id="libero_mikado_blog-css"
          href="/css/blog.css" type="text/css" media="all">
    <link rel="stylesheet" id="mediaelement-css"
          href="/css/mediaelementplayer.css" type="text/css"
          media="all">
    <link rel="stylesheet" id="wp-mediaelement-css"
          href="/css/wp-mediaelement.css" type="text/css"
          media="all">
    <link rel="stylesheet" id="mkd_woocommerce-css"
          href="/css/woocommerce.css" type="text/css"
          media="all">
    <link rel="stylesheet" id="mkd_woocommerce_responsive-css"
          href="/css/woocommerce-responsive.css"
          type="text/css" media="all">
    <link rel="stylesheet" id="libero_mikado_style_dynamic-css"
          href="/css/style_dynamic.css" type="text/css"
          media="all">
    <link rel="stylesheet" id="libero_mikado_modules_responsive-css"
          href="/css/modules-responsive.css" type="text/css"
          media="all">
    <link rel="stylesheet" id="libero_mikado_blog_responsive-css"
          href="/css/blog-responsive.css" type="text/css"
          media="all">
    <link rel="stylesheet" id="libero_mikado_style_dynamic_responsive-css"
          href="/css/style_dynamic_responsive.css"
          type="text/css" media="all">
    <link rel="stylesheet" id="js_composer_front-css"
          href="/css/js_composer.css" type="text/css"
          media="all">
    <link rel="stylesheet" id="libero_mikado_google_fonts-css"
          href="/css/css.css" type="text/css" media="all">

    <script type="text/javascript"
            src="/js/jquery_003.js"></script>
    <script type="text/javascript"
            src="/js/jquery-migrate.js"></script>
    <script type="text/javascript"
            src="/js/jquery_005.js"></script>
    <script type="text/javascript"
            src="/js/jquery.js"></script>
    <script type="text/javascript">
        /* <![CDATA[ */
        var wc_add_to_cart_params = {
            "ajax_url": "\/wp-admin\/admin-ajax.php",
            "wc_ajax_url": "\/?wc-ajax=%%endpoint%%",
            "i18n_view_cart": "View Cart",
            "cart_url": "http:\/\/libero.mikado-themes.com\/cart\/",
            "is_cart": "",
            "cart_redirect_after_add": "no"
        };
        /* ]]> */
    </script>
    <script type="text/javascript"
            src="/js/add-to-cart.js"></script>
    <script type="text/javascript"
            src="/js/woocommerce-add-to-cart.js"></script>
    <link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://libero.mikado-themes.com/xmlrpc.php?rsd">
    <link rel="wlwmanifest" type="application/wlwmanifest+xml"
          href="http://libero.mikado-themes.com/wp-includes/wlwmanifest.xml">
    <meta name="generator" content="WordPress 4.3.8">
    <meta name="generator" content="WooCommerce 2.4.10">
    <link rel="canonical" href="http://libero.mikado-themes.com/">
    <link rel="shortlink" href="http://libero.mikado-themes.com/">
    <meta name="generator" content="Powered by Visual Composer - drag and drop page builder for WordPress.">
    <!--[if lte IE 9]>
    <link rel="stylesheet" type="text/css"
          href="http://libero.mikado-themes.com/wp-content/plugins/js_composer/assets/css/vc_lte_ie9.min.css"
          media="screen"><![endif]--><!--[if IE  8]>
    <link rel="stylesheet" type="text/css"
          href="http://libero.mikado-themes.com/wp-content/plugins/js_composer/assets/css/vc-ie8.min.css"
          media="screen"><![endif]-->
    <meta name="generator"
          content="Powered by Slider Revolution 5.1.4 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface.">
    <link rel="icon" href="http://libero.mikado-themes.com/wp-content/uploads/2015/12/cropped-favicon-32x32.png"
          sizes="32x32">
    <link rel="icon" href="http://libero.mikado-themes.com/wp-content/uploads/2015/12/cropped-favicon-192x192.png"
          sizes="192x192">
    <link rel="apple-touch-icon-precomposed"
          href="http://libero.mikado-themes.com/wp-content/uploads/2015/12/cropped-favicon-180x180.png">
    <meta name="msapplication-TileImage"
          content="http://libero.mikado-themes.com/wp-content/uploads/2015/12/cropped-favicon-270x270.png">
    <style type="text/css" data-type="vc_shortcodes-custom-css">.vc_custom_1449053863566 {
            padding-top: 38px !important;
            padding-bottom: 38px !important;
            background-color: #282e3f !important;
        }

        .vc_custom_1450197220155 {
            padding-top: 70px !important;
            padding-bottom: 10px !important;
            background-image: url(http://libero.mikado-themes.com/wp-content/uploads/2015/11/h-main-background-1.jpg?id=2405) !important;
            background-position: center !important;
            background-repeat: no-repeat !important;
            background-size: cover !important;
        }

        .vc_custom_1450176712252 {
            background-color: #f2f2f2 !important;
        }

        .vc_custom_1449053902261 {
            padding-top: 70px !important;
        }

        .vc_custom_1450197352911 {
            padding-top: 70px !important;
            padding-bottom: 45px !important;
        }

        .vc_custom_1450197389208 {
            padding-top: 70px !important;
            padding-bottom: 45px !important;
            background-color: #f2f2f2 !important;
        }

        .vc_custom_1449145319025 {
            background-color: #f2f2f2 !important;
        }

        .vc_custom_1450194926053 {
            padding-top: 35px !important;
            padding-bottom: 35px !important;
            background-color: #353c4e !important;
        }

        .vc_custom_1450194795605 {
            padding-top: 70px !important;
        }

        .vc_custom_1450197418142 {
            padding-top: 37px !important;
            padding-bottom: 50px !important;
        }

        .vc_custom_1449058472937 {
            padding-top: 90px !important;
            padding-bottom: 50px !important;
            background-position: center !important;
            background-repeat: no-repeat !important;
            background-size: cover !important;
        }

        .vc_custom_1450195972481 {
            padding-top: 70px !important;
        }

        .vc_custom_1450197453742 {
            padding-top: 40px !important;
            padding-bottom: 45px !important;
        }

        .vc_custom_1450196350853 {
            padding-top: 105px !important;
            padding-bottom: 65px !important;
            background-image: url(http://libero.mikado-themes.com/wp-content/uploads/2015/11/h-main-background-2.jpg?id=2429) !important;
            background-position: center !important;
            background-repeat: no-repeat !important;
            background-size: cover !important;
        }

        .vc_custom_1447328421692 {
            background-color: #f2f2f2 !important;
        }

        .vc_custom_1447665617658 {
            padding-right: 0px !important;
            padding-left: 0px !important;
        }

        .vc_custom_1447665628867 {
            padding-right: 0px !important;
            padding-left: 0px !important;
        }

        .vc_custom_1447665635018 {
            padding-right: 0px !important;
            padding-left: 0px !important;
        }

        .vc_custom_1447665667284 {
            padding-right: 0px !important;
            padding-left: 0px !important;
        }

        .vc_custom_1447665660344 {
            padding-right: 0px !important;
            padding-left: 0px !important;
        }

        .vc_custom_1447665676106 {
            padding-right: 0px !important;
            padding-left: 0px !important;
        }

        .vc_custom_1450192780703 {
            padding-top: 45px !important;
            padding-bottom: 60px !important;
        }</style>
    <noscript>
        <style type="text/css"> .wpb_animate_when_almost_visible {
                opacity: 1;
            }</style>
    </noscript>
    <style>.fluidvids {
            width: 100%;
            max-width: 100%;
            position: relative;
        }

        .fluidvids-item {
            position: absolute;
            top: 0px;
            left: 0px;
            width: 100%;
            height: 100%;
        }</style>
    <script type="text/javascript" charset="UTF-8"
            src="/js/common.js"></script>
    <script type="text/javascript" charset="UTF-8"
            src="/js/util.js"></script>
    <script type="text/javascript" charset="UTF-8"
            src="/js/stats.js"></script>

    <link rel="stylesheet" id="dashicons-css" href="/custom/css/main.css" type="text/css">
</head>