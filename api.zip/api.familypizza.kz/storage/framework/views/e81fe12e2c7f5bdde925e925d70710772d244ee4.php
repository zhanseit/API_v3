<?php $__currentLoopData = $review; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

    <div class="item-review">
        <div class="rate-reviews clearfix">
            <p class="pull-left">
                <a href="/profile/<?php echo e(\App\Http\Helpers::getTranslatedSlugRu($item->user_name)); ?>-u<?php echo e($item->user_id); ?>">
                    <i class="icon-profile"></i><?php echo e($item->user_name); ?>

                </a>
            </p>
            <span>

                <? $user['rating'] = $item->rating; ?>

                <?php echo $__env->make('index.profile.rating-part', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            </span>
        </div>
        <div class="text-review"><?php echo e($item->review_text); ?></div>
    </div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

<div style="text-align: center">
    <?php echo e($review->appends(\Illuminate\Support\Facades\Input::except('page'))->links()); ?>

</div>
