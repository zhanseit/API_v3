<!DOCTYPE html>
<html class="js flexbox flexboxlegacy canvas canvastext no-touch hashchange history draganddrop rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients no-cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio svg inlinesvg svgclippaths js_active  vc_desktop  vc_transform  vc_transform  vc_transform "
      lang="en-US">

<?php echo $__env->make('index.layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<body class="home page page-id-388 page-template page-template-full-width page-template-full-width-php mkd-core-1.0 libero-ver-1.0  mkd-grid-1300 mkd-blog-installed mkd-header-standard mkd-sticky-header-on-scroll-up mkd-default-mobile-header mkd-sticky-up-mobile-header mkd-menu-item-first-level-bg-color mkd-dropdown-default mkd-search-covers-header mkd-side-menu-slide-from-right wpb-js-composer js-comp-ver-4.8.1 vc_responsive"  cz-shortcut-listen="true">

<?php echo $__env->make('index.layout.mobile-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="mkd-wrapper">
    <div class="mkd-cover"></div>
    <div class="mkd-wrapper-inner">

        <?php echo $__env->make('index.layout.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <a id="mkd-back-to-top" href="#" class="on">
                <span class="mkd-icon-stack">
                     <span aria-hidden="true"
                           class="mkd-icon-font-elegant arrow_carrot-up "></span>                </span>
        </a>

        <?php echo $__env->yieldContent('content'); ?>

        <footer class="mkd-footer-uncover">
            <div class="mkd-footer-inner clearfix">
                <div class="mkd-footer-bottom-holder">
                    <div class="mkd-footer-bottom-holder-inner">
                        <div class="mkd-two-columns-50-50 clearfix">
                            <div class="mkd-two-columns-50-50-inner">
                                <div class="mkd-footer-btm-table-holder">
                                    <div class="mkd-column">
                                        <div class="mkd-column-inner">
                                            <div id="nav_menu-3" class="widget mkd-footer-bottom-left widget_nav_menu">
                                                <div class="menu-footer_bottom_menu-container">
                                                    <ul id="menu-footer_bottom_menu" class="menu">
                                                        <li id="menu-item-2270"
                                                            class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-388 current_page_item menu-item-2270">
                                                            <a href="http://libero.mikado-themes.com/">Home</a></li>
                                                        <li id="menu-item-1623"
                                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1623">
                                                            <a href="http://libero.mikado-themes.com/our-services/">Services</a>
                                                        </li>
                                                        <li id="menu-item-1624"
                                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1624">
                                                            <a href="http://libero.mikado-themes.com/company-history/">Offices</a>
                                                        </li>
                                                        <li id="menu-item-1625"
                                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1625">
                                                            <a href="http://libero.mikado-themes.com/our-team-of-lawyers/">Careers</a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="mkd-column">
                                        <div class="mkd-column-inner">
                                            <div id="text-9" class="widget mkd-footer-bottom-left widget_text">
                                                <div class="textwidget">Copyright 2015 <span style="color:#c18f59;">Your Company Name Here</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </footer>

    </div> <!-- close div.mkd-wrapper-inner  -->
</div> <!-- close div.mkd-wrapper -->
<script type="text/javascript" src="/js/core.js"></script>
<script type="text/javascript"
        src="/js/widget.js"></script>
<script type="text/javascript" src="/js/mouse.js"></script>
<script type="text/javascript"
        src="/js/resizable.js"></script>
<script type="text/javascript"
        src="/js/draggable.js"></script>
<script type="text/javascript"
        src="/js/button.js"></script>
<script type="text/javascript"
        src="/js/position.js"></script>
<script type="text/javascript"
        src="/js/dialog.js"></script>
<script type="text/javascript"
        src="/js/wpdialog.js"></script>
<script type="text/javascript"
        src="/js/jquery_004.js"></script>
<script type="text/javascript">
    /* <![CDATA[ */
    var _wpcf7 = {
        "loaderUrl": "http:\/\/libero.mikado-themes.com\/wp-content\/plugins\/contact-form-7\/images\/ajax-loader.gif",
        "sending": "Sending ..."
    };
    /* ]]> */
</script>
<script type="text/javascript"
        src="/js/scripts.js"></script>
<script type="text/javascript"
        src="/js/jquery_006.js"></script>
<script type="text/javascript">
    /* <![CDATA[ */
    var woocommerce_params = {"ajax_url": "\/wp-admin\/admin-ajax.php", "wc_ajax_url": "\/?wc-ajax=%%endpoint%%"};
    /* ]]> */
</script>
<script type="text/javascript"
        src="/js/woocommerce.js"></script>
<script type="text/javascript"
        src="/js/jquery_002.js"></script>
<script type="text/javascript">
    /* <![CDATA[ */
    var wc_cart_fragments_params = {
        "ajax_url": "\/wp-admin\/admin-ajax.php",
        "wc_ajax_url": "\/?wc-ajax=%%endpoint%%",
        "fragment_name": "wc_fragments"
    };
    /* ]]> */
</script>
<script type="text/javascript"
        src="/js/cart-fragments.js"></script>
<script type="text/javascript" src="/js/tabs.js"></script>
<script type="text/javascript"
        src="/js/accordion.js"></script>
<script type="text/javascript">
    /* <![CDATA[ */
    var mejsL10n = {
        "language": "en-US",
        "strings": {
            "Close": "Close",
            "Fullscreen": "Fullscreen",
            "Download File": "Download File",
            "Download Video": "Download Video",
            "Play\/Pause": "Play\/Pause",
            "Mute Toggle": "Mute Toggle",
            "None": "None",
            "Turn off Fullscreen": "Turn off Fullscreen",
            "Go Fullscreen": "Go Fullscreen",
            "Unmute": "Unmute",
            "Mute": "Mute",
            "Captions\/Subtitles": "Captions\/Subtitles"
        }
    };
    var _wpmejsSettings = {"pluginPath": "\/wp-includes\/js\/mediaelement\/"};
    /* ]]> */
</script>
<script type="text/javascript"
        src="/js/mediaelement-and-player.js"></script>
<script type="text/javascript"
        src="/js/wp-mediaelement.js"></script>
<script type="text/javascript"
        src="/js/third-party.js"></script>
<script type="text/javascript"
        src="/js/isotope.js"></script>
<script type="text/javascript" src="/js/js"></script>
<script type="text/javascript">
    /* <![CDATA[ */
    var mkdGlobalVars = {
        "vars": {
            "mkdAddForAdminBar": 0,
            "mkdElementAppearAmount": -150,
            "mkdFirstMainColor": "#c18f59",
            "mkdMessage": "Loading new posts...",
            "mkdTopBarHeight": 0,
            "mkdStickyHeaderHeight": 60,
            "mkdStickyHeaderTransparencyHeight": 60,
            "mkdLogoAreaHeight": 0,
            "mkdMenuAreaHeight": 152,
            "mkdStickyHeight": 60
        }
    };
    var mkdPerPageVars = {"vars": {"mkdStickyScrollAmount": 0, "mkdHeaderTransparencyHeight": 0}};
    /* ]]> */
</script>
<script type="text/javascript"
        src="/js/modules.js"></script>
<script type="text/javascript" src="/js/blog.js"></script>
<script type="text/javascript"
        src="/js/comment-reply.js"></script>
<script type="text/javascript"
        src="/js/js_composer_front.js"></script>
<script type="text/javascript">
    /* <![CDATA[ */
    var mkdLike = {"ajaxurl": "http:\/\/libero.mikado-themes.com\/wp-admin\/admin-ajax.php"};
    /* ]]> */
</script>
<script type="text/javascript" src="/js/like.js"></script>

<div id="ascrail2000" class="nicescroll-rails nicescroll-rails-vr"
     style="width: 0px; z-index: 9999; cursor: default; position: fixed; top: 0px; left: 1754px; height: 657px; opacity: 1; display: none;">
    <div style="position: relative; top: 0px; float: right; width: 0px; height: 0px; background-color: transparent; border: 0px none; background-clip: padding-box; border-radius: 0px;"
         class="nicescroll-cursors"></div>
</div>
</body>
</html>