<div class="header">
    <div class="container-fluid">
        <div class="logo-box">
            <p>
                <a href="/">
                    <img src="/images/logo.jpg" alt="">
                </a>
                <span class="hidden-xs"><?php echo e(Lang::get('app.employment_road_map')); ?></span>
            </p>
        </div>

        <div class="link-profile prof-box">
            <p><a><img src="/images/img-ava-def@2x.png" class="mob-version" alt=""><span class="hidden-xs"><?php echo e(Lang::get('app.cabinet')); ?></span></a></p>

            <?php if(Auth::check()): ?>

                <ul class="info-prof">
                    <li><a href="/profile"><?php echo e(Lang::get('app.profile')); ?></a></li>
                    <li><a href="/profile/edit"><?php echo e(Lang::get('app.edit_profile')); ?></a></li>

                    <?php if(Auth::user()->role_id == 2): ?>
                        <li><a href="/profile/vacancy"><?php echo e(Lang::get('app.my_vacancy')); ?></a></li>

                        <?
                        $response_db = new \App\Models\Response();
                        $response_count = $response_db->getInResponseCount(Auth::user()->user_id);
                        ?>
                        <li><a href="/response/in"><?php echo e(Lang::get('app.incoming_response')); ?> <?php if($response_count > 0): ?><span class="count-notification"><?php echo e($response_count); ?></span><?php endif; ?></a></li>

                        <li><a href="/vacancy/add"><?php echo e(Lang::get('app.add_vacancy')); ?></a></li>
                    <?php elseif(Auth::user()->role_id == 3): ?>
                        <li><a href="/response/out"><?php echo e(Lang::get('app.my_response')); ?></a></li>
                        <li><a href="/vacancy"><?php echo e(Lang::get('app.find_work')); ?></a></li>
                    <?php endif; ?>

                    <li class="menu-logout-button"><a href="/logout"><?php echo e(Lang::get('app.logout')); ?></a></li>
                </ul>

            <?php else: ?>

                <ul class="info-prof">
                    <li><a href="/login"><?php echo e(Lang::get('app.sign_in')); ?></a></li>
                    <li><a href="/auth/register/employer"><?php echo e(Lang::get('app.register_employer')); ?></a></li>
                    <li><a href="/auth/register/master"><?php echo e(Lang::get('app.register_master')); ?></a></li>
                </ul>

            <?php endif; ?>

        </div>
        <div class="language">
            <a href="<?php echo e(\App\Http\Helpers::setSessionLang('kz',$request)); ?>" class="<?php if($lang == 'kz'): ?> active <?php endif; ?>">Қаз</a>
            <a href="<?php echo e(\App\Http\Helpers::setSessionLang('ru',$request)); ?>" class="<?php if($lang == 'ru'): ?> active <?php endif; ?>">Рус</a>
        </div>

        <div class="seach-main">
            <input id="search_word" value="<?php echo e(isset($_GET['search'])?$_GET['search']:''); ?>" type="text" placeholder="<?php echo e(Lang::get('app.search')); ?>...">
            <input type="button" class="btn-search" onclick="getVacancyListBySearch()">
        </div>

    </div>
</div>