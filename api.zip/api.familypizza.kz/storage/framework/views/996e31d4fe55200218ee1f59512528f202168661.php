<?php $__env->startSection('content'); ?>

        <section class="content-header">
            <h1>
              <?php echo e($title); ?>

            </h1>
        </section>
        <section class="content">
            <div class="row">
                <div class="col-md-12">
                   <div class="col-md-8" style="padding-left: 0px">
                       <div class="box box-primary">
                           <?php if(isset($error)): ?>
                               <div class="alert alert-danger">
                                  <?php echo e($error); ?>

                               </div>
                           <?php endif; ?>
                               <?php if($row->user_id > 0): ?>
                                   <form action="/admin/company/<?php echo e($row->user_id); ?>" method="POST">
                                   <input type="hidden" name="_method" value="PUT">
                               <?php else: ?>
                                   <form action="/admin/company" method="POST">
                               <?php endif; ?>

                                   <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                   <input id="user_id" type="hidden" name="user_id" value="<?php echo e($row->user_id); ?>">
                                   <input type="hidden" class="image-name" id="avatar" name="avatar" value="<?php echo e($row->avatar); ?>"/>

                                   <div class="box-body">
                                       <div class="form-group">
                                           <label>Юр. лицо или физ. лицо</label>
                                           <select name="is_company" data-placeholder="" class="form-control">

                                               <option <?if($row->is_company == 0) echo 'selected '; ?> value="0">Физ. лицо</option>
                                               <option <?if($row->is_company == 1) echo 'selected '; ?> value="0">Юр. лицо</option>

                                           </select>
                                       </div>
                                       <div class="form-group">
                                           <label>ФИО/Название компании</label>
                                           <input value="<?php echo e($row->user_name); ?>" type="text" class="form-control" name="user_name" placeholder="Введите">
                                       </div>
                                       <div class="form-group">
                                          <label>Номер телефона</label>
                                          <input value="<?php echo e(\App\Http\Helpers::getPhoneFormat($row->phone)); ?>" type="text" class="form-control phone-mask" name="phone" placeholder="Введите">
                                       </div>
                                       <div class="form-group">
                                           <label>Сфера деятельности</label>
                                           <input value="<?php echo e($row->work_type); ?>" type="text" class="form-control" name="work_type" placeholder="Введите">
                                       </div>
                                       <div class="form-group">
                                           <label>ИНН</label>
                                           <input value="<?php echo e($row->inn); ?>" type="text" class="form-control" name="inn" placeholder="Введите">
                                       </div>
                                    </div>

                                   <div class="box-footer">
                                       <button type="submit" class="btn btn-primary">Сохранить</button>
                                   </div>
                               </form>
                           </div>
                   </div>

                </div>
            </div>
        </section>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>