<ul class="sidebar-menu">
  <li class="header">МЕНЮ</li>
  <li class="treeview">
    <a href="/admin/news">
      <i class="fa fa-file-text"></i>
      <span>Статьи</span>
    </a>
  </li>
  <li class="treeview">
    <a href="/admin/service">
      <i class="fa fa-file-text"></i>
      <span>Услуги</span>
    </a>
  </li>
  <li class="treeview">
    <a href="/admin/price">
      <i class="fa fa-file-text"></i>
      <span>Прайс-лист</span>
    </a>
  </li>
  <li class="treeview">
    <a href="/admin/category">
      <i class="fa fa-file-text"></i>
      <span>Категория для цен</span>
    </a>
  </li>
  <li class="treeview">
    <a href="/admin/user">
      <i class="fa fa-user"></i>
      <span>Пользователи</span>
    </a>
  </li>
  <li class="treeview">
    <a href="/admin/password">
      <i class="fa fa-user"></i>
      <span>Сменить пароль</span>
    </a>
  </li>
</ul>