<?php $__env->startSection('content'); ?>

    <div class="mkd-content" style="margin-bottom: 529px; padding-top: 30px; padding-bottom: 30px">
        <div class="mkd-content-inner">
            <div data-mkd-parallax-speed="1" class="vc_row wpb_row vc_row-fluid mkd-section mkd-content-aligment-center mkd-grid-section" style="">
                <div class="clearfix mkd-section-inner">
                    <div class="mkd-section-inner-margin clearfix">
                        <div class="wpb_column vc_column_container vc_col-sm-12">
                            <div class="wpb_wrapper">
                                <div class="mkd-separator-holder clearfix  mkd-separator-center mkd-separator-with-icon mkd-animate"
                                     style="margin-top: 20px; margin-bottom: 30px">
                                    <div class="mkd-separator"
                                         style="border-color: #c18f59;border-style: solid;width: 97.5px"></div>
                                    <div class="mkd-separator-icon">
                                        <img src="/image/h1-separator-custom-icon-1.png"
                                             class="attachment-full" alt="a" width="34" height="23"></div>
                                    <div class="mkd-separator"
                                         style="border-color: #c18f59;border-style: solid;width: 97.5px"></div>
                                </div>

                                <div class="wpb_text_column wpb_content_element ">
                                    <div class="wpb_wrapper">
                                        <h1><?php echo e($parent->service_name_ru); ?></h1>
                                    </div>
                                </div>
                                <div class="vc_empty_space" style="height: 23px"><span class="vc_empty_space_inner"></span></div>

                                <div class="wpb_text_column wpb_content_element ">
                                    <div class="wpb_wrapper">
                                        <h3>Дополнительно оказываем услуги по получению лицензий и других разрешительных документов по договорной стоимости. Оплату можно производить как наличным, так и безналичным путем.</h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div data-mkd-parallax-speed="1"
                 class="vc_row wpb_row vc_row-fluid mkd-section vc_custom_1450197418142 mkd-content-aligment-center mkd-grid-section"
                 style="">
                <div class="clearfix mkd-section-inner">
                    <div class="mkd-section-inner-margin clearfix">
                        <div class="wpb_column vc_column_container vc_col-sm-6 vc_col-lg-3 vc_col-md-6">
                            <div class="wpb_wrapper">
                                <div class="mkd-service-table mkd-service-has-icon">
                                    <div class="mkd-service-table-icon">

    <span class="mkd-icon-shortcode circle mkd-icon-small">

        <i class="mkd-icon-simple-line-icon icon-trophy mkd-icon-element" style=""></i>
                <span class="mkd-background"></span>
    </span>

                                    </div>
                                    <div class="mkd-service-table-inner">
                                        <div class="mkd-service-titles-holder">
                                            <h4>Immigration Law</h4>
                                            <h5>what we are best at</h5>
                                        </div>
                                        <div class="mkd-service-table-content">
                                            <ul>
                                                <li>Criminal Defense</li>
                                                <li>Family Disputes</li>
                                                <li>Broker Fraud</li>
                                                <li>Domestic Violence</li>
                                                <li>Medical Malpractice</li>
                                                <li>Intellectual Property</li>
                                            </ul>
                                        </div>
                                        <div class="mkd-service-link">
                                            <a href="http://libero.mikado-themes.com/our-services/"
                                               target="_self">
                                                <span> See success rates </span>

                                                <span class="mkd-service-link-icon arrow_carrot-right_alt2"></span>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="vc_empty_space" style="height: 40px"><span
                                            class="vc_empty_space_inner"></span></div>
                            </div>
                        </div>
                        <div class="wpb_column vc_column_container vc_col-sm-6 vc_col-lg-3 vc_col-md-6">
                            <div class="wpb_wrapper">
                                <div class="mkd-service-table mkd-service-has-icon">
                                    <div class="mkd-service-table-icon">

    <span class="mkd-icon-shortcode circle mkd-icon-small">

        <i class="mkd-icon-simple-line-icon icon-graduation mkd-icon-element" style=""></i>
                <span class="mkd-background"></span>
    </span>

                                    </div>
                                    <div class="mkd-service-table-inner">
                                        <div class="mkd-service-titles-holder">
                                            <h4>Banking &amp; Finance</h4>
                                            <h5>outstanding service</h5>
                                        </div>
                                        <div class="mkd-service-table-content">
                                            <ul>
                                                <li>Criminal Defense</li>
                                                <li>Family Disputes</li>
                                                <li>Broker Fraud</li>
                                                <li>Domestic Violence</li>
                                                <li>Medical Malpractice</li>
                                                <li>Intellectual Property</li>
                                            </ul>
                                        </div>
                                        <div class="mkd-service-link">
                                            <a href="http://libero.mikado-themes.com/our-services/"
                                               target="_self">
                                                <span> See success rates </span>

                                                <span class="mkd-service-link-icon arrow_carrot-right_alt2"></span>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="vc_empty_space" style="height: 40px"><span
                                            class="vc_empty_space_inner"></span></div>
                            </div>
                        </div>
                        <div class="wpb_column vc_column_container vc_col-sm-6 vc_col-lg-3 vc_col-md-6">
                            <div class="wpb_wrapper">
                                <div class="mkd-service-table mkd-service-has-icon">
                                    <div class="mkd-service-table-icon">

    <span class="mkd-icon-shortcode circle mkd-icon-small">

        <i class="mkd-icon-simple-line-icon icon-badge mkd-icon-element" style=""></i>
                <span class="mkd-background"></span>
    </span>

                                    </div>
                                    <div class="mkd-service-table-inner">
                                        <div class="mkd-service-titles-holder">
                                            <h4>Employment Law</h4>
                                            <h5>personal attitude</h5>
                                        </div>
                                        <div class="mkd-service-table-content">
                                            <ul>
                                                <li>Criminal Defense</li>
                                                <li>Family Disputes</li>
                                                <li>Broker Fraud</li>
                                                <li>Domestic Violence</li>
                                                <li>Medical Malpractice</li>
                                                <li>Intellectual Property</li>
                                            </ul>
                                        </div>
                                        <div class="mkd-service-link">
                                            <a href="http://libero.mikado-themes.com/our-services/"
                                               target="_self">
                                                <span> See success rates </span>

                                                <span class="mkd-service-link-icon arrow_carrot-right_alt2"></span>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="vc_empty_space" style="height: 40px"><span
                                            class="vc_empty_space_inner"></span></div>
                            </div>
                        </div>
                        <div class="wpb_column vc_column_container vc_col-sm-6 vc_col-lg-3 vc_col-md-6">
                            <div class="wpb_wrapper">
                                <div class="mkd-service-table mkd-service-has-icon">
                                    <div class="mkd-service-table-icon">

    <span class="mkd-icon-shortcode circle mkd-icon-small">

        <i class="mkd-icon-simple-line-icon icon-people mkd-icon-element" style=""></i>
                <span class="mkd-background"></span>
    </span>

                                    </div>
                                    <div class="mkd-service-table-inner">
                                        <div class="mkd-service-titles-holder">
                                            <h4>Foreclosure Defense</h4>
                                            <h5>civil rights</h5>
                                        </div>
                                        <div class="mkd-service-table-content">
                                            <ul>
                                                <li>Criminal Defense</li>
                                                <li>Family Disputes</li>
                                                <li>Broker Fraud</li>
                                                <li>Domestic Violence</li>
                                                <li>Medical Malpractice</li>
                                                <li>Intellectual Property</li>
                                            </ul>
                                        </div>
                                        <div class="mkd-service-link">
                                            <a href="http://libero.mikado-themes.com/our-services/"
                                               target="_self">
                                                <span> See success rates </span>

                                                <span class="mkd-service-link-icon arrow_carrot-right_alt2"></span>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="vc_empty_space" style="height: 40px"><span
                                            class="vc_empty_space_inner"></span></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('index.layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>