
<form>
    <fieldset class="starability-basic">
        <input <?php if(floor($user->rating) == 5): ?> checked <?php endif; ?>  type="radio" name="rating" value="5" />
        <label for="s1-rate5" title="Amazing" aria-label="Amazing, 5 stars"></label>

        <input <?php if(floor($user->rating) == 4): ?> checked <?php endif; ?> type="radio" name="rating" value="4" />
        <label for="s1-rate4" title="Very good" aria-label="Very good, 4 stars"></label>

        <input <?php if(floor($user->rating) == 3): ?> checked <?php endif; ?> type="radio" name="rating" value="3" />
        <label for="s1-rate3" title="Average" aria-label="Average, 3 stars"></label>

        <input <?php if(floor($user->rating) == 2): ?> checked <?php endif; ?> type="radio" name="rating" value="2" />
        <label for="s1-rate2" title="Not good" aria-label="Not good, 2 stars"></label>

        <input <?php if(floor($user->rating) == 1): ?> checked <?php endif; ?> type="radio" name="rating" value="1" />
        <label for="s1-rate1" title="Terrible" aria-label="Terrible, 1 star"></label>
    </fieldset>
</form>
