<?php $__env->startSection('content'); ?>

    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="container">
                    <h2 class="main-title">Входящие отклики</h2>

                    <?php if($response_row->count() > 0): ?>

                        <table class="table table-responsive list-vacancy">
                            <tr>
                                <th>Соискатель</th>
                                <th>Вакансия</th>
                                <th>Дата работы</th>
                                <th>Статус</th>
                                <th>&nbsp;</th>
                            </tr>

                            <?php echo $__env->make('index.response.response-in-loop', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                        </table>

                        <div style="text-align: center">
                            <?php echo e($response_row->appends(\Illuminate\Support\Facades\Input::except('page'))->links()); ?>

                        </div>

                    <?php else: ?>

                        <p class="empty-list-label">У Вас пока нет входящих откликов</p>

                    <?php endif; ?>


                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('index.layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>