<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-xs-12">
      <div class="box">
          <div class="box-header">
            <h3 class="box-title" style="margin-top: 5px"><?php echo e($title); ?></h3>
            <a href="/admin/user/create" style="float: right">
                <button class="btn btn-primary" style="margin-bottom: 10px; ">Добавить пользователя</button>
            </a>
            <div style="clear: both"></div>
          </div>
          <div style="padding-top: 10px; border-top: 1px solid rgb(127, 127, 127);">
              <div class="form-group col-md-3" >
                  <label>Поиск</label>
                  <input id="search_word" value="<?php echo e($request->search); ?>" type="text" class="form-control" name="search_word" placeholder="Введите">
              </div>
              <div class="form-group col-md-3" style="padding-top: 25px" >
                  <a href="javascript:void(0)" onclick="searchBySort()">
                      <button type="button" class="btn btn-block btn-success">Поиск</button>
                  </a>
              </div>
          </div>
          <div style="clear: both"></div>
          <div>
              <div style="text-align: right" class="form-group col-md-12" >
                  <h4 class="box-title" style="margin-top: 5px; margin-bottom: 0px">
                      <a href="javascript:void(0)" onclick="deleteAll()" style="text-decoration: underline; font-size: 17px; color: rgb(248, 23, 23);">Удалить отмеченные</a>
                  </h4>
              </div>
          </div>
        <div class="box-body">
          <table id="news_datatable" class="table table-bordered table-striped">
            <thead>
              <tr style="border: 1px">
                <th style="width: 30px">№</th>
                <th>Пользователь</th>
                <th>Email</th>
                <th style="width: 30px"></th>
                <th style="width: 30px"></th>
                <th class="no-sort" style="width: 0px; text-align: center; padding-right: 16px; padding-left: 14px;" >
                  <input onclick="selectAllCheckbox(this)" style="font-size: 15px" type="checkbox" value="1"/>
                </th>
              </tr>
            </thead>

            <tbody>

                  <?php $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

                     <tr>
                        <td> <?php echo e($key + 1); ?></td>
                        <td>
                        <div class="user-avatar">

                            <?php if(strpos($val->avatar, 'http') !== false): ?>
                                <a href="<?php echo e($val->avatar); ?>" class="fancybox">
                                    <img src="<?php echo e($val->avatar); ?>" style="max-width: 300px"/>
                                </a>
                            <?php else: ?>
                                <a href="/image/avatar/<?php echo e($val->avatar); ?>" class="fancybox">
                                    <img src="/image/avatar/<?php echo e($val->avatar); ?>" style="max-width: 300px"/>
                                </a>
                            <?php endif; ?>

                        </div>
                        <div class="user-name">
                            <div>
                                <?php echo e($val->name); ?>

                            </div>
                        </div>
                        <div class="clear-float"></div>
                        </td>
                        <td class="arial-font">
                            <div>
                                <?php echo e($val->email); ?>

                            </div>
                        </td>
                        <td style="text-align: center">
                            <a href="javascript:void(0)" onclick="delItem(this,<?php echo e($val->user_id); ?>)">
                                <li class="fa fa-trash-o" style="font-size: 20px; color: red;"></li>
                            </a>
                        </td>
                        <td style="text-align: center">
                            <a href="/admin/user/<?php echo e($val->user_id); ?>/edit">
                                <li class="fa fa-pencil" style="font-size: 20px;"></li>
                            </a>
                        </td>
                        <td style="text-align: center;">
                             <input class="select-all" style="font-size: 15px" type="checkbox" value="<?php echo e($val->user_id); ?>"/>
                        </td>
                     </tr>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

            </tbody>

          </table>

            <?php if($row->lastPage() > 1): ?>

                <div class="page_number" style="text-align: center">
                    <ul class="pagination">
                        <li>
                            <a <?php if($row->currentPage() > 1): ?> href="?<?php echo e(preg_replace('~(\?|&)page=[^&]*~','',http_build_query($_GET))); ?>&page=<?php echo e($row->currentPage() - 1); ?>" <?php endif; ?> >&laquo;</a>
                        </li>
                        <?
                        $start = 1;
                        if($row->currentPage() >= 10){
                            $start = $row->currentPage();
                        }
                        $finish = $start + 9;
                        if($finish > $row->lastPage()){
                            $finish = $row->lastPage();
                            $start = $finish - 10;
                            if($start <= 0){
                                $start = 1;
                            }
                        }
                        ?>
                        <?php for($i = $start; $i <= $finish; $i++): ?>
                            <li class="<?php echo e(($row->currentPage() == $i) ? 'active-paginator' : ''); ?>">
                                <a href="?<?php echo e(preg_replace('~(\?|&)page=[^&]*~','',http_build_query($_GET))); ?>&page=<?php echo e($i); ?>"><?php echo e($i); ?></a>
                            </li>
                        <?php endfor; ?>
                        <li>
                            <a <?php if($row->currentPage() < $row->lastPage()): ?> href="?<?php echo e(preg_replace('~(\?|&)page=[^&]*~','',http_build_query($_GET))); ?>&page=<?php echo e($row->currentPage() + 1); ?>" <?php endif; ?>>&raquo;</a>
                        </li>
                    </ul>
                </div>

            <?php endif; ?>

        </div><!-- /.box-body -->
      </div><!-- /.box -->
    </div><!-- /.col -->
    </div><!-- /.row -->

    <script src="/admin/plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <link href="/fancybox/jquery.fancybox.css" type="text/css" rel="stylesheet">
    <script src="/fancybox/jquery.fancybox.pack.js" type="text/javascript"></script>

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

       <script>
           function delItem(ob,id){
               if(confirm('Действительно хотите удалить?')){
                   $(ob).closest('tr').remove();
                   $.ajax({
                       type: 'DELETE',
                       headers: {
                           'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                       },
                       url: "/admin/user/" + id,
                       success: function(data){

                       }
                   });
               }
           }

           function selectAllCheckbox(ob) {
               if ($(ob).is(':checked')) {
                   $('.select-all').prop('checked', true);
                   console.log('ok');
               }
               else {
                   $('.select-all').prop('checked', false);
                   console.log('ok1');
               }

           }

           function deleteAll() {
               if(confirm('Действительно хотите удалить?')){
                   $('.ajax-loader').fadeIn(100);
                   $('.select-all').each(function(){
                       if ($(this).is(':checked')) {
                           $.ajax({
                               type: 'DELETE',
                               headers: {
                                   'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                               },
                               url: "/admin/user/" + $(this).val(),
                               success: function(){

                               }
                           });
                           $(this).closest('tr').remove();
                       }
                   });
                   $('.ajax-loader').fadeOut(100);
               }
           }

           function isShowEnabledAll() {
               if(confirm('Действительно хотите блокировать?')){
                   $('.ajax-loader').fadeIn(100);
                   $('.select-all').each(function(){
                       if ($(this).is(':checked')) {
                           $.ajax({
                               type: 'POST',
                               headers: {
                                   'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                               },
                               data :{
                                   is_ban: 1,
                                   user_id: $(this).val()
                               },
                               url: "/admin/user/is_ban",
                               success: function(data){

                               }
                           });
                           $(this).closest('tr').remove();
                       }
                   });
                   $('.ajax-loader').fadeOut(100);
               }
           }

           function isShowDisabledAll() {
               if(confirm('Действительно хотите разблокировать?')){
                   $('.ajax-loader').fadeIn(100);
                   $('.select-all').each(function(){
                       if ($(this).is(':checked')) {
                           $.ajax({
                               type: 'POST',
                               headers: {
                                   'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                               },
                               data :{
                                   is_ban: 0,
                                   user_id: $(this).val()
                               },
                               url: "/admin/user/is_ban",
                               success: function(data){

                               }
                           });
                           $(this).closest('tr').remove();
                       }
                   });
                   $('.ajax-loader').fadeOut(100);
               }
           }

           $( "#search_word" ).keyup(function(event) {
               if (!event.ctrlKey && event.which == 13) {
                   searchBySort();
               }
           });

           function searchBySort() {
               href = '?<?php echo e(preg_replace('~(\?|&)search=[^&]*~','',http_build_query($_GET))); ?>&search=' + $('#search_word').val();
               window.location.href = href;
           }

       </script>

         <script type="text/javascript">
              $('a.fancybox').fancybox({
                  padding: 10
              });
        </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>