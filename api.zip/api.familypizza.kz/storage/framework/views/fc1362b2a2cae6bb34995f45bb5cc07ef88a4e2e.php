<?php $__env->startSection('content'); ?>

        <section class="content-header">
            <h1>
              <?php echo e($title); ?>

            </h1>
        </section>
        <section class="content">
            <div class="row">
                <div class="col-md-12">
                   <div class="col-md-8" style="padding-left: 0px">
                       <div class="box box-primary">
                               <div class="alert alert-danger" id="news_error" style="display: none">

                               </div>
                               <form id="news_form" method="POST">
                                   <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                   <input class="image-name" type="hidden" id="news_image" name="news_image" value="<?php echo e($row->news_image); ?>"/>
                                   <input type="hidden" id="news_id" name="news_id" value="<?php echo e($row->news_id); ?>"/>

                                   <div class="box-body">
                                       <div class="form-group" style="display: none">
                                           <label>Язык публикации</label>
                                           <select class="form-control news-lang" name="news_lang" id="news_lang">

                                               <option value="ru" <?php if($row->news_lang == 'ru'): ?> <?php echo e(' selected '); ?> <?php endif; ?>>Русский</option>
                                               <option value="kz" <?php if($row->news_lang == 'kz'): ?> <?php echo e(' selected '); ?> <?php endif; ?>>Қазақша</option>
                                               <option value="en" <?php if($row->news_lang == 'en'): ?> <?php echo e(' selected '); ?> <?php endif; ?>>English</option>

                                           </select>
                                       </div>
                                       <div class="lang-item" id="lang_ru" style="<?php if($row->news_name_ru == '' || $row->news_name_ru == null): ?><?php echo e('display:none'); ?><?php endif; ?> <?php if($row->news_id == 0): ?><?php echo e('display:block'); ?><?php endif; ?>">
                                           <div class="form-group">
                                               <label>Заголовок </label>
                                               <input id="news_name_ru" value="<?php echo e($row->news_name_ru); ?>" type="text" class="form-control" name="news_name_ru" placeholder="Введите">
                                           </div>
                                           <div class="form-group">
                                               <label>Текст </label>
                                               <textarea id="news_text_ru" name="news_text" class="form-control text_editor"><?=$row->news_text_ru?></textarea>
                                           </div>
                                       </div>
                                       <div class="lang-item" id="lang_kz" style="display: none; <?php if($row->news_name_kz == '' || $row->news_name_kz == null): ?><?php echo e('display:none'); ?><?php endif; ?>">
                                           <div class="form-group">
                                               <label>Заголовок (Каз)</label>
                                               <input id="news_name_kz" value="<?php echo e($row->news_name_kz); ?>" type="text" class="form-control " name="news_name_kz" placeholder="Введите">
                                           </div>
                                           <div class="form-group">
                                               <label>Текст (Каз)</label>
                                               <textarea id="news_text_kz" name="news_text_kz" class="form-control text_editor"><?=$row->news_text_kz?></textarea>
                                           </div>
                                       </div>
                                       <div class="lang-item" id="lang_en" style="display: none; <?php if($row->news_name_en == '' || $row->news_name_en == null): ?><?php echo e('display:none'); ?><?php endif; ?>">
                                           <div class="form-group">
                                               <label>Заголовок (Англ)</label>
                                               <input id="news_name_en" value="<?php echo e($row->news_name_en); ?>" type="text" class="form-control" name="news_name_en" placeholder="Введите">
                                           </div>
                                           <div class="form-group">
                                               <label>Текст (Англ)</label>
                                               <textarea id="news_text_en" name="news_text_en" class="form-control text_editor"><?=$row->news_text_en?></textarea>
                                           </div>
                                       </div>
                                       <div class="form-group" style="display: none;">
                                           <label>
                                               <a class="add-lang-item" id="add_lang_ru" href="javascript:void(0)" onclick="showLang('ru')" style="color: #3C8DBC; <?php if($row->news_name_ru != '' && $row->news_name_ru != null): ?><?php echo e('display:none'); ?><?php endif; ?> <?php if($row->news_id == 0): ?><?php echo e('display:none'); ?><?php endif; ?>">Добавить перевод (Рус) +</a></br>
                                               <a class="add-lang-item" id="add_lang_kz" href="javascript:void(0)" onclick="showLang('kz')" style="color: #3C8DBC; <?php if($row->news_name_kz != '' && $row->news_name_kz != null): ?><?php echo e('display:none'); ?><?php endif; ?>">Добавить перевод (Каз) +</a></br>
                                               <a class="add-lang-item" id="add_lang_en" href="javascript:void(0)" onclick="showLang('en')" style="color: #3C8DBC; <?php if($row->news_name_en != '' && $row->news_name_en != null): ?><?php echo e('display:none'); ?><?php endif; ?>">Добавить перевод (Англ) +</a>
                                           </label>
                                       </div>
                                       <div class="form-group" style="display: none">
                                          <label>Тэги (через запятую)</label>
                                          <textarea id="tag" name="tag" class="form-control"><?=$row->tag?></textarea>
                                       </div>
                                       <div class="form-group">
                                           <label>Ссылка на видео</label>
                                           <input id="video_url" value="<?php echo e($row->video_url); ?>" type="text" class="form-control" name="video_url" placeholder="Введите">
                                       </div>
                                       <div class="form-group">
                                           <label>Дата</label>
                                           <input id="news_date" value="<?php echo e($row->news_date); ?>" type="text" class="form-control datetimepicker-input" name="news_date" placeholder="Введите">
                                       </div>
                                       <div class="form-group">
                                          <label>Источник новости</label>
                                          <input id="source_name" value="<?php echo e($row->source_name); ?>" type="text" class="form-control" name="source_name" placeholder="Введите">
                                       </div>
                                       <div class="form-group">
                                          <label>Ссылка на источник</label>
                                          <input id="source_url" value="<?php echo e($row->source_url); ?>" type="text" class="form-control" name="source_url" placeholder="Введите">
                                       </div>
                                    </div>
                                   <div class="box-footer">
                                       <a href="javascript:void(0)" onclick="saveNews()">
                                          <button type="button" class="btn btn-primary">Сохранить</button>
                                       </a>
                                   </div>
                               </form>
                           </div>
                   </div>
                   <div class="col-md-4">
                       <div class="box box-primary" style="padding: 30px; text-align: center">
                           <div style="padding: 20px; border: 1px solid #c2e2f0">
                               <img class="image-src" src="<?php echo e($row->news_image); ?>" style="width: 100%; "/>
                           </div>
                           <div style="background-color: #c2e2f0;height: 40px;margin: 0 auto;width: 2px;"></div>
                           <form id="image_form" enctype="multipart/form-data" method="post" class="image-form">
                               <i class="fa fa-plus"></i>
                               <input id="avatar-file" type="file" onchange="uploadImage()" name="image"/>
                           </form>
                       </div>
                   </div>
                </div>
            </div>
        </section>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>