<?php $__env->startSection('content'); ?>

    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="container">
                    <h2 class="main-title"><?php echo e(Lang::get('app.register_employer')); ?></h2>

                    <div class="row">

                        <input type="hidden" value="2" id="role_id"/>

                        <div class="col-md-6 col-sm-6 form-regis">
                            <span><?php echo e(Lang::get('app.legal_entity_or_individual')); ?>?</span>
                            <select name="is_company" id="is_company">
                                <option value="0" selected><?php echo e(Lang::get('app.individual')); ?></option>
                                <option value="1"><?php echo e(Lang::get('app.legal_entity')); ?></option>
                            </select>
                        </div>

                        <div class="col-md-6 col-sm-6 form-regis">
                            <span><?php echo e(Lang::get('app.company_name_or_user_name')); ?></span>
                            <input type="text" value="" id="user_name">
                        </div>

                        <div class="col-md-6 col-sm-6 form-regis">
                            <span><?php echo e(Lang::get('app.work_type')); ?></span>
                            <input type="text" value="" id="work_type" placeholder="<?php echo e(Lang::get('app.organization_of_events')); ?>">
                        </div>

                        <div class="col-md-6 col-sm-6 form-regis">
                            <span><?php echo e(Lang::get('app.iin')); ?></span>
                            <input type="text" value="" id="inn" placeholder="">
                        </div>

                        <div class="col-md-6 col-sm-6 form-regis">
                            <span><?php echo e(Lang::get('app.phone')); ?></span>
                            <input class="phone-mask" type="text" value="" id="phone" placeholder="+7 (ХХХ) ХХХ-ХХ-ХХ">
                        </div>

                        <div class="col-md-6 col-sm-6 form-regis">
                            <span><?php echo e(Lang::get('app.password')); ?></span>
                            <input type="password" value="" id="register_password" placeholder="">
                        </div>

                    </div>

                    <div class="row box-registration">
                        <div class="col-md-6 col-sm-6 form-regis">
                            <input type="checkbox" id="is_agree"> <span><?php echo Lang::get('app.agree_licence'); ?></span>
                        </div>

                        <div class="col-md-6 col-sm-6 form-regis">
                            <input type="button" value="<?php echo e(Lang::get('app.registered')); ?>" onclick="registerAjax()">
                        </div>
                    </div>

                    <h3 class="title-2"><?php echo e(Lang::get('app.if_you_are_registered')); ?></h3>
                    <div class="row">
                        <div class="col-md-6 col-sm-6 form-regis">
                            <span><?php echo e(Lang::get('app.phone')); ?></span>
                            <input class="phone-mask" type="text" id="login" placeholder="+7 (ХХХ) ХХХ-ХХ-ХХ" value="">
                            <span><?php echo e(Lang::get('app.password')); ?></span>
                            <input type="password" value="" id="password" class="login-input">
                            <input type="button" value="<?php echo e(Lang::get('app.sign_in')); ?>" onclick="loginAjax()">
                            <p class="text-center"><a href="/auth/reset-password"><?php echo e(Lang::get('app.forget_password')); ?></a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('index.layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>