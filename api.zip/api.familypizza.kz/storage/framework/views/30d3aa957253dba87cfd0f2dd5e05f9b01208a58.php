<?php $__currentLoopData = $vacancy_row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

        <tr data-href="/vacancy/<?php echo e(\App\Http\Helpers::getTranslatedSlugRu($item['speciality_name_'.$lang].'-'.$item->vacancy_desc)); ?>-u<?php echo e($item->vacancy_id); ?>">
            <td><?php echo e($item['speciality_name_'.$lang]); ?></td>
            <td><?php echo e($item->deadline); ?></td>
            <td><b class="price-job"><?php echo e($item->salary); ?> тенге/<?php echo e($item->pay_duration); ?></b></td>
        </tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

