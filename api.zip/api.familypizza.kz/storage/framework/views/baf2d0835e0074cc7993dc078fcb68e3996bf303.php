<?php $__env->startSection('content'); ?>

    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="container">
                    <h2 class="main-title"><?php echo e(Lang::get('app.write_review')); ?></h2>

                    <div class="row">

                        <input type="hidden" value="<?php echo e($user->user_id); ?>" id="master_id">
                        <div class="col-md-6 col-sm-6 form-regis">
                            <span><?php if($user->role_id == 2): ?><?php echo e(Lang::get('app.worker_name')); ?><?php else: ?> <?php echo e(Lang::get('app.employer_name')); ?> <?php endif; ?></span>
                            <input type="text" value="<?php echo e($user->user_name); ?>">
                        </div>

                        <div class="col-md-6 col-sm-6 form-regis">
                            <span><?php echo e(Lang::get('app.review_mark')); ?></span>
                            <input type="hidden" value="" id="review_rating">
                            <fieldset class="starability-basic">
                                <input class="review-rating" type="radio" id="rate5" name="rating1" value="5" />
                                <label for="rate5" title="Amazing">5 stars</label>
                                <input class="review-rating" type="radio" id="rate4" name="rating1" value="4" />
                                <label for="rate4" title="Very good">4 stars</label>
                                <input class="review-rating" type="radio" id="rate3" name="rating1" value="3" />
                                <label for="rate3" title="Average">3 stars</label>
                                <input class="review-rating" type="radio" id="rate2" name="rating1" value="2" />
                                <label for="rate2" title="Not good">2 stars</label>
                                <input class="review-rating" type="radio" id="rate1" name="rating1" value="1" />
                                <label for="rate1" title="Terrible">1 star</label>
                            </fieldset>
                        </div>

                        <div class="col-md-12 col-sm-12 form-regis">
                            <span><?php echo e(Lang::get('app.review_text')); ?></span>
                            <textarea name="" id="review_text" ></textarea>
                        </div>

                        <div class="col-md-12">
                            <div class="btn-vacancy">
                                <button class="btn-blue" onclick="addReview()"><?php echo e(Lang::get('app.write_review')); ?></button>
                            </div>
                        </div>

                    </div>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('index.layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>