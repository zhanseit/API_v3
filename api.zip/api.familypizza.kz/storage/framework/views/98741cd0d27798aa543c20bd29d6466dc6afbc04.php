<?php $__env->startSection('content'); ?>

    <div class="mkd-content" style="margin-bottom: 529px; padding-top: 30px; padding-bottom: 30px">
        <div class="mkd-content-inner">
            <div data-mkd-parallax-speed="1"
                 class="vc_row wpb_row vc_row-fluid mkd-section vc_custom_1450198046093 mkd-content-aligment-center mkd-grid-section"
                 style="">
                <div class="clearfix mkd-section-inner">
                    <div class="mkd-section-inner-margin clearfix">
                        <div class="wpb_column vc_column_container vc_col-sm-12">
                            <div class="wpb_wrapper">
                                <div class="mkd-separator-holder clearfix  mkd-separator-center mkd-separator-with-icon"
                                     style="margin-top: 20px; margin-bottom: 25px">
                                    <div class="mkd-separator"
                                         style="border-color: #c18f59;border-style: solid;width: 97.5px"></div>
                                    <div class="mkd-separator-icon">
                                        <img src="/image/h1-separator-custom-icon-1.png"
                                             class="attachment-full" alt="a" width="34" height="23"></div>
                                    <div class="mkd-separator"
                                         style="border-color: #c18f59;border-style: solid;width: 97.5px"></div>
                                </div>
                                <div class="wpb_text_column wpb_content_element ">
                                    <div class="wpb_wrapper">
                                        <h1><span style="color: #c18f59;">Инструкция по оплате </span>через QIWI терминалы</h1>
                                    </div>
                                </div>
                                <div class="vc_empty_space" style="height: 25px"><span
                                            class="vc_empty_space_inner"></span></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div data-mkd-parallax-speed="1"
                 class="vc_row wpb_row vc_row-fluid mkd-section mkd-content-aligment-center mkd-grid-section" style="">
                <div class="clearfix mkd-section-inner">
                    <div class="mkd-section-inner-margin clearfix qiwi-instruction">
                        <div class="wpb_column vc_column_container vc_col-sm-6 vc_col-lg-3 vc_col-md-3">
                            <div class="wpb_wrapper">
                                <div class="mkd-interactive-image mkd-checkmark mkd-linked">
                                    <a href="#"></a>
                                    <img src="/image/qiwi/qiwi_instruction1.png" class="attachment-full" alt="a" width="200" height="200">
                                    <div class="tick" style="top: 80%; left: 40%; width: 53px;"></div>
                                </div>
                                <div class="vc_empty_space" style="height: 15px">
                                    <span class="vc_empty_space_inner"></span>
                                </div>
                                <div class="wpb_text_column wpb_content_element ">
                                    <div class="wpb_wrapper">
                                        <h4 style="font-size: 16px">Подойдите к терминалу с 3-мя большими кнопками</h4>
                                    </div>
                                </div>
                                <div class="vc_empty_space" style="height: 40px">
                                    <span class="vc_empty_space_inner"></span>
                                </div>
                            </div>
                        </div>
                        <div class="wpb_column vc_column_container vc_col-sm-6 vc_col-lg-3 vc_col-md-3">
                            <div class="wpb_wrapper">
                                <div class="mkd-interactive-image mkd-checkmark mkd-linked">
                                    <a href="#"></a>
                                    <img src="/image/qiwi/qiwi_instruction2.png" class="attachment-full" alt="a" width="200" height="200">
                                    <div class="tick" style="top: 80%; left: 40%; width: 53px;"></div>
                                </div>
                                <div class="vc_empty_space" style="height: 15px">
                                    <span class="vc_empty_space_inner"></span>
                                </div>
                                <div class="wpb_text_column wpb_content_element ">
                                    <div class="wpb_wrapper">
                                        <h4 style="font-size: 16px">Нажмите на кнопку оплата "Оплата услуг"</h4>
                                    </div>
                                </div>
                                <div class="vc_empty_space" style="height: 40px">
                                    <span class="vc_empty_space_inner"></span>
                                </div>
                            </div>
                        </div>
                        <div class="wpb_column vc_column_container vc_col-sm-6 vc_col-lg-3 vc_col-md-3">
                            <div class="wpb_wrapper">
                                <div class="mkd-interactive-image mkd-checkmark mkd-linked">
                                    <a href="#"></a>
                                    <img src="/image/qiwi/qiwi_instruction3.png" class="attachment-full" alt="a" width="200" height="200">
                                    <div class="tick" style="top: 80%; left: 40%; width: 53px;"></div>
                                </div>
                                <div class="vc_empty_space" style="height: 15px">
                                    <span class="vc_empty_space_inner"></span>
                                </div>
                                <div class="wpb_text_column wpb_content_element ">
                                    <div class="wpb_wrapper">
                                        <h4 style="font-size: 16px">Выберите "ДРУГИЕ УСЛУГИ"</h4>
                                    </div>
                                </div>
                                <div class="vc_empty_space" style="height: 40px">
                                    <span class="vc_empty_space_inner"></span>
                                </div>
                            </div>
                        </div>
                        <div class="wpb_column vc_column_container vc_col-sm-6 vc_col-lg-3 vc_col-md-3">
                            <div class="wpb_wrapper">
                                <div class="mkd-interactive-image mkd-checkmark mkd-linked">
                                    <a href="#"></a>
                                    <img src="/image/qiwi/qiwi_instruction4.png" class="attachment-full" alt="a" width="200" height="200">
                                    <div class="tick" style="top: 80%; left: 40%; width: 53px;"></div>
                                </div>
                                <div class="vc_empty_space" style="height: 15px">
                                    <span class="vc_empty_space_inner"></span>
                                </div>
                                <div class="wpb_text_column wpb_content_element ">
                                    <div class="wpb_wrapper">
                                        <h4 style="font-size: 16px">Нажмите кнопку "КОНСАЛТИНГ"</h4>
                                    </div>
                                </div>
                                <div class="vc_empty_space" style="height: 40px">
                                    <span class="vc_empty_space_inner"></span>
                                </div>
                            </div>
                        </div>
                        <div class="wpb_column vc_column_container vc_col-sm-6 vc_col-lg-3 vc_col-md-3">
                            <div class="wpb_wrapper">
                                <div class="mkd-interactive-image mkd-checkmark mkd-linked">
                                    <a href="#"></a>
                                    <img src="/image/qiwi/qiwi_instruction5.png" class="attachment-full" alt="a" width="200" height="200">
                                    <div class="tick" style="top: 80%; left: 40%; width: 53px;"></div>
                                </div>
                                <div class="vc_empty_space" style="height: 15px">
                                    <span class="vc_empty_space_inner"></span>
                                </div>
                                <div class="wpb_text_column wpb_content_element ">
                                    <div class="wpb_wrapper">
                                        <h4 style="font-size: 16px">Выберите ТОО "М-КОНСАЛТ"</h4>
                                    </div>
                                </div>
                                <div class="vc_empty_space" style="height: 40px">
                                    <span class="vc_empty_space_inner"></span>
                                </div>
                            </div>
                        </div>
                        <div class="wpb_column vc_column_container vc_col-sm-6 vc_col-lg-3 vc_col-md-3">
                            <div class="wpb_wrapper">
                                <div class="mkd-interactive-image mkd-checkmark mkd-linked">
                                    <a href="#"></a>
                                    <img src="/image/qiwi/qiwi_instruction6.png" class="attachment-full" alt="a" width="200" height="200">
                                    <div class="tick" style="top: 80%; left: 40%; width: 53px;"></div>
                                </div>
                                <div class="vc_empty_space" style="height: 15px">
                                    <span class="vc_empty_space_inner"></span>
                                </div>
                                <div class="wpb_text_column wpb_content_element ">
                                    <div class="wpb_wrapper">
                                        <h4 style="font-size: 16px">Введите номер телефона</h4>
                                    </div>
                                </div>
                                <div class="vc_empty_space" style="height: 40px">
                                    <span class="vc_empty_space_inner"></span>
                                </div>
                            </div>
                        </div>
                        <div class="wpb_column vc_column_container vc_col-sm-6 vc_col-lg-3 vc_col-md-3">
                            <div class="wpb_wrapper">
                                <div class="mkd-interactive-image mkd-checkmark mkd-linked">
                                    <a href="#"></a>
                                    <img src="/image/qiwi/qiwi_instruction7.png" class="attachment-full" alt="a" width="200" height="200">
                                    <div class="tick" style="top: 80%; left: 40%; width: 53px;"></div>
                                </div>
                                <div class="vc_empty_space" style="height: 15px">
                                    <span class="vc_empty_space_inner"></span>
                                </div>
                                <div class="wpb_text_column wpb_content_element ">
                                    <div class="wpb_wrapper">
                                        <h4 style="font-size: 16px">Проверьте и подтвердите правильность данных</h4>
                                    </div>
                                </div>
                                <div class="vc_empty_space" style="height: 40px">
                                    <span class="vc_empty_space_inner"></span>
                                </div>
                            </div>
                        </div>
                        <div class="wpb_column vc_column_container vc_col-sm-6 vc_col-lg-3 vc_col-md-3">
                            <div class="wpb_wrapper">
                                <div class="mkd-interactive-image mkd-checkmark mkd-linked">
                                    <a href="#"></a>
                                    <img src="/image/qiwi/qiwi_instruction8.png" class="attachment-full" alt="a" width="200" height="200">
                                    <div class="tick" style="top: 80%; left: 40%; width: 53px;"></div>
                                </div>
                                <div class="vc_empty_space" style="height: 15px">
                                    <span class="vc_empty_space_inner"></span>
                                </div>
                                <div class="wpb_text_column wpb_content_element ">
                                    <div class="wpb_wrapper">
                                        <h4 style="font-size: 16px">Внесите оплату, возмите чек</h4>
                                    </div>
                                </div>
                                <div class="vc_empty_space" style="height: 40px">
                                    <span class="vc_empty_space_inner"></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('index.layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>